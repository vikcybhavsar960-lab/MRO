import React, { useState, useEffect } from 'react';
import { useApp, AppProvider } from './context/AppContext';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { MobileShell } from './components/layout/MobileShell';
import { DashboardView } from './components/dashboard/DashboardView';
import { RequirementListAndDetail } from './components/workflow/RequirementListAndDetail';
import { RateComparisonView } from './components/workflow/RateComparisonView';
import { QuotationView } from './components/workflow/QuotationView';
import { CustomerMaster } from './components/masters/CustomerMaster';
import { CompanyMaster } from './components/masters/CompanyMaster';
import { PurchaseExecutiveMaster } from './components/masters/PurchaseExecutiveMaster';
import { VendorMaster } from './components/masters/VendorMaster';
import { BrandMaster } from './components/masters/BrandMaster';
import { CategoryMaster } from './components/masters/CategoryMaster';
import { ProductMaster } from './components/masters/ProductMaster';
import { ReportsView } from './components/reports/ReportsView';
import { CompanyExecutiveReportsView } from './components/reports/CompanyExecutiveReportsView';
import { DocumentCenter } from './components/documents/DocumentCenter';
import { AuditLogView } from './components/audit/AuditLogView';
import { BackupRecoveryView } from './components/settings/BackupRecoveryView';
import { UserManagementView } from './components/users/UserManagementView';
import { ApprovalDashboardView } from './components/workflow/ApprovalDashboardView';
import { SalesBillingView } from './components/sales/SalesBillingView';
import { PurchaseBillsView } from './components/purchase/PurchaseBillsView';
import { AccountingView } from './components/accounting/AccountingView';
import { EmailRfqInboxView } from './components/email/EmailRfqInboxView';
import { InventoryManagementView } from './components/inventory/InventoryManagementView';

// Modals
import { GlobalSearchModal } from './components/common/GlobalSearchModal';
import { LoginModal } from './components/auth/LoginModal';
import { LoginPage } from './components/auth/LoginPage';
import { GoogleSheetsModal } from './components/reports/GoogleSheetsModal';
import { OrderTimelineModal } from './components/workflow/OrderTimelineModal';
import { NewRequirementModal } from './components/workflow/NewRequirementModal';
import { VendorEnquiryModal } from './components/workflow/VendorEnquiryModal';
import { VendorRateSubmissionModal } from './components/workflow/VendorRateSubmissionModal';
import { DirectVendorRatesView } from './components/workflow/DirectVendorRatesView';
import { DirectVendorRateEntryModal } from './components/workflow/DirectVendorRateEntryModal';
import { NewQuotationModal } from './components/workflow/NewQuotationModal';
import { CustomerPOModal } from './components/workflow/CustomerPOModal';
import { VendorPOModal } from './components/workflow/VendorPOModal';
import { ProformaInvoiceModal } from './components/workflow/ProformaInvoiceModal';
import { PaymentModal } from './components/workflow/PaymentModal';
import { DispatchModal } from './components/workflow/DispatchModal';
import { DeliveryModal } from './components/workflow/DeliveryModal';
import { EarningRulesAndLockModal } from './components/workflow/EarningRulesAndLockModal';

// Dedicated stage list views for PO, PI, PAY, DSP
import { ShoppingCart, PackageCheck, Receipt, CreditCard, Truck, CheckCircle2, Plus } from 'lucide-react';

function AppContent() {
  const {
    activeTab,
    setActiveTab,
    selectedOrderId,
    setSelectedOrderId,
    isMobileView,
    customerPOs,
    vendorPOs,
    proformaInvoices,
    payments,
    dispatches,
    deliveries,
    vendorQuotes,
    rfqs,
    currentUser,
  } = useApp();

  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('mro_is_logged_out') !== 'true';
    }
    return true;
  });

  // Modals state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isGoogleSheetsOpen, setIsGoogleSheetsOpen] = useState(false);
  const [isNewReqOpen, setIsNewReqOpen] = useState(false);
  const [rfqReqId, setRfqReqId] = useState<string | null>(null);
  const [rateSubmissionEnquiryId, setRateSubmissionEnquiryId] = useState<string | null>(null);
  const [rateSubmissionReqId, setRateSubmissionReqId] = useState<string | null>(null);
  const [quotationParams, setQuotationParams] = useState<{ reqId?: string; quoteId?: string } | null>(null);
  const [cpoReqId, setCpoReqId] = useState<string | null>(null);
  const [vpoReqId, setVpoReqId] = useState<string | null>(null);
  const [piVpoId, setPiVpoId] = useState<string | null>(null);
  const [payPiId, setPayPiId] = useState<string | null>(null);
  const [dspReqId, setDspReqId] = useState<string | null>(null);
  const [delReqId, setDelReqId] = useState<string | null>(null);
  const [verifyOrderAuditId, setVerifyOrderAuditId] = useState<string | null>(null);

  // Check URL parameters for direct email verification links
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const verifyId = params.get('verifyOrder') || params.get('orderId');
      if (verifyId) {
        setVerifyOrderAuditId(verifyId);
      }
    }
  }, []);

  const renderTabContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardView
            onOpenNewReq={() => setIsNewReqOpen(true)}
            onOpenNewCustomer={() => setActiveTab('customers')}
            onOpenNewVendor={() => setActiveTab('vendors')}
            onOpenNewEnquiry={() => {
              setActiveTab('requirements');
            }}
            onOpenNewQuotation={() => setQuotationParams({})}
            onOpenGoogleSheets={() => setIsGoogleSheetsOpen(true)}
            onSelectOrder={(id) => setSelectedOrderId(id)}
          />
        );

      case 'requirements':
      case 'rfqs':
        return (
          <RequirementListAndDetail
            onOpenNewModal={() => setIsNewReqOpen(true)}
            onOpenRfqModal={(reqId) => setRfqReqId(reqId)}
            onOpenRateModal={(reqId) => setRateSubmissionReqId(reqId)}
            onSelectOrder={(id) => setSelectedOrderId(id)}
          />
        );

      case 'vendor-rates':
        return (
          <DirectVendorRatesView
            onOpenRateComparison={(_reqId) => {
              setActiveTab('rate-comparison');
            }}
            onSelectOrder={(id) => setSelectedOrderId(id)}
          />
        );

      case 'rate-comparison':
        return (
          <RateComparisonView
            onProceedToQuotation={(reqId, quoteId) => {
              setQuotationParams({ reqId, quoteId });
            }}
            onSelectOrder={(id) => setSelectedOrderId(id)}
          />
        );

      case 'quotations':
        return (
          <QuotationView
            onOpenNewQuotationModal={() => setQuotationParams({})}
            onSelectOrder={(id) => setSelectedOrderId(id)}
          />
        );

      case 'customer-pos':
        return (
          <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <ShoppingCart className="w-5 h-5 text-blue-600" />
                  <span>Customer Purchase Orders (CPO)</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Stage 6 of 12: Inward buyer purchase orders, delivery destination, and payment commitments
                </p>
              </div>

              {(currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'PROCUREMENT_EMPLOYEE') && (
                <button
                  onClick={() => setCpoReqId('REQ-2026-00003')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20"
                >
                  Record New Customer PO
                </button>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold text-slate-500 uppercase border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">PO Number</th>
                    <th className="py-3 px-4">Customer</th>
                    <th className="py-3 px-4">Requirement Ref</th>
                    <th className="py-3 px-4">PO Date</th>
                    <th className="py-3 px-4">Payment Terms</th>
                    <th className="py-3 px-4 text-right">PO Amount (INR)</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {customerPOs.map((cpo) => (
                    <tr key={cpo.id} className="hover:bg-slate-50">
                      <td className="py-3.5 px-4 font-mono font-bold text-blue-700">
                        {cpo.id} ({cpo.customerPoNumber})
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-900">{cpo.customerName}</td>
                      <td className="py-3.5 px-4 font-mono">{cpo.requirementId}</td>
                      <td className="py-3.5 px-4">{cpo.poDate}</td>
                      <td className="py-3.5 px-4">{cpo.paymentTerms}</td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900 text-right">
                        ₹{cpo.poAmount.toLocaleString('en-IN', { maximumFractionDigits: 2 })}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedOrderId(cpo.requirementId)}
                          className="px-3 py-1 bg-slate-900 hover:bg-black text-white rounded-md text-[11px] font-bold"
                        >
                          Trace
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'vendor-pos':
        return (
          <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <PackageCheck className="w-5 h-5 text-blue-600" />
                  <span>Vendor Purchase Orders (VPO)</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Stage 7 of 12: Binding procurement orders placed with authorized distributors
                </p>
              </div>

              {(currentUser.role === 'SUPER_ADMIN' || currentUser.role === 'PROCUREMENT_EMPLOYEE') && (
                <button
                  onClick={() => setVpoReqId('REQ-2026-00003')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20"
                >
                  Issue New Vendor PO
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {vendorPOs.map((vpo) => (
                <div key={vpo.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-mono font-bold text-xs text-indigo-700">{vpo.id}</span>
                      <h4 className="font-bold text-sm text-slate-900">{vpo.vendorName}</h4>
                    </div>
                    <span className="text-xs font-mono font-bold text-slate-500">{vpo.poDate}</span>
                  </div>

                  <div className="text-xs text-slate-600 space-y-1">
                    <div>Delivery To: <strong>{vpo.deliveryAddress}</strong></div>
                    <div>Payment: <strong>{vpo.paymentTerms}</strong></div>
                    <div>Linked Requirement: <strong className="font-mono text-blue-700">{vpo.requirementId}</strong></div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex justify-between items-center text-xs">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase font-bold block">Total Amount</span>
                      <span className="font-black text-slate-900 font-mono text-sm">
                        ₹{vpo.totalAmount.toLocaleString('en-IN')}
                      </span>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setPiVpoId(vpo.id)}
                        className="px-2.5 py-1 bg-purple-50 text-purple-700 border border-purple-200 rounded-md font-bold"
                      >
                        Upload PI
                      </button>
                      <button
                        onClick={() => setSelectedOrderId(vpo.requirementId)}
                        className="px-3 py-1 bg-slate-900 text-white rounded-md font-bold"
                      >
                        Timeline
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'pi':
        return (
          <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Receipt className="w-5 h-5 text-blue-600" />
                  <span>Vendor Proforma Invoices (PI)</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Stage 8 of 12: Tax breakdown, wire coordinates, and payment due schedules
                </p>
              </div>

              {(currentUser.role === 'VENDOR' || currentUser.role === 'SUPER_ADMIN') && (
                <button
                  onClick={() => setPiVpoId(vendorPOs[0]?.id || 'VPO-2026-00001')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20"
                >
                  Upload New Proforma Invoice
                </button>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold text-slate-500 uppercase border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">PI Identifier</th>
                    <th className="py-3 px-4">Vendor</th>
                    <th className="py-3 px-4">Date & Due Date</th>
                    <th className="py-3 px-4">Taxable Amount</th>
                    <th className="py-3 px-4">GST Tax</th>
                    <th className="py-3 px-4 text-right">Total PI Value (INR)</th>
                    <th className="py-3 px-4 text-right">Accounts Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {proformaInvoices.map((pi) => (
                    <tr key={pi.id} className="hover:bg-slate-50">
                      <td className="py-3.5 px-4 font-mono font-bold text-blue-700">
                        {pi.id} ({pi.piNumber})
                      </td>
                      <td className="py-3.5 px-4 font-bold text-slate-900">{pi.vendorName}</td>
                      <td className="py-3.5 px-4">{pi.piDate} • Due: {pi.paymentDueDate}</td>
                      <td className="py-3.5 px-4 font-mono">₹{pi.amount.toLocaleString('en-IN')}</td>
                      <td className="py-3.5 px-4 font-mono">₹{pi.gstAmount.toLocaleString('en-IN')}</td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900 text-right">
                        ₹{pi.totalAmount.toLocaleString('en-IN')}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setPayPiId(pi.id)}
                          className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-md text-[11px] font-bold"
                        >
                          Disburse
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'payments':
        return (
          <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-blue-600" />
                  <span>Accounts Payment Management (PAY)</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Stage 9 of 12: Wire remittances, bank UTR references, and vendor dispatch release
                </p>
              </div>

              {(currentUser.role === 'ACCOUNTS_USER' || currentUser.role === 'SUPER_ADMIN') && (
                <button
                  onClick={() => setPayPiId(proformaInvoices[0]?.id || 'PI-2026-00001')}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-500/20"
                >
                  Record Disbursal
                </button>
              )}
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold text-slate-500 uppercase border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Payment Ref</th>
                    <th className="py-3 px-4">Vendor Beneficiary</th>
                    <th className="py-3 px-4">Payment Date</th>
                    <th className="py-3 px-4">Mode & UTR Reference</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Amount Disbursed (INR)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {payments.map((p) => (
                    <tr key={p.id} className="hover:bg-slate-50">
                      <td className="py-3.5 px-4 font-mono font-bold text-emerald-700">{p.id}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-900">{p.vendorName}</td>
                      <td className="py-3.5 px-4">{p.paymentDate}</td>
                      <td className="py-3.5 px-4 font-mono">
                        <span className="font-bold text-slate-900">{p.paymentMode}</span> • {p.transactionReference}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                          {p.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900 text-right">
                        ₹{p.amountPaid.toLocaleString('en-IN')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'dispatch':
        return (
          <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <Truck className="w-5 h-5 text-blue-600" />
                  <span>Logistics & Dispatch Management (DSP)</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Stage 10 of 12: Transporter bilty, LR / AWB numbers, and transit tracking
                </p>
              </div>

              {(currentUser.role === 'VENDOR' || currentUser.role === 'SUPER_ADMIN') && (
                <button
                  onClick={() => setDspReqId('REQ-2026-00003')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold shadow-md shadow-blue-500/20"
                >
                  Create Consignment Dispatch
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {dispatches.map((d) => (
                <div key={d.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-mono font-bold text-xs text-cyan-700">{d.id}</span>
                      <h4 className="font-bold text-sm text-slate-900">{d.transporter}</h4>
                    </div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-50 text-cyan-800 border border-cyan-200">
                      LR: {d.lrNumber}
                    </span>
                  </div>

                  <div className="text-xs text-slate-600 space-y-1">
                    <div>Vendor Invoice: <strong>{d.vendorInvoiceNumber}</strong></div>
                    <div>Quantity & Crates: <strong>{d.quantityDispatched}</strong></div>
                    <div>ETA Delivery: <strong>{d.expectedDeliveryDate}</strong></div>
                    <div>Linked Requirement: <strong className="font-mono text-blue-700">{d.requirementId}</strong></div>
                  </div>

                  <div className="pt-3 border-t border-slate-100 flex justify-between items-center text-xs">
                    <button
                      onClick={() => setDelReqId(d.requirementId)}
                      className="px-3 py-1 bg-emerald-600 text-white rounded-md font-bold"
                    >
                      Update Tracking
                    </button>
                    <button
                      onClick={() => setSelectedOrderId(d.requirementId)}
                      className="px-3 py-1 bg-slate-900 text-white rounded-md font-bold"
                    >
                      View Timeline
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      case 'delivery':
        return (
          <div className="p-4 sm:p-6 space-y-6 max-w-7xl mx-auto">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-blue-600" />
                  <span>Shipment Delivery & Order Closure</span>
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  Stages 11 & 12: Customer receipt verification, POD inspection, and final closure
                </p>
              </div>

              <button
                onClick={() => setDelReqId('REQ-2026-00002')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-500/20"
              >
                Confirm Site Delivery
              </button>
            </div>

            <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs text-slate-700">
                <thead className="bg-slate-50 text-[11px] font-bold text-slate-500 uppercase border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-4">Delivery Ref</th>
                    <th className="py-3 px-4">Order Ref</th>
                    <th className="py-3 px-4">Delivery Date</th>
                    <th className="py-3 px-4">Receiver Incharge</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {deliveries.map((del) => (
                    <tr key={del.id} className="hover:bg-slate-50">
                      <td className="py-3.5 px-4 font-mono font-bold text-emerald-700">{del.id}</td>
                      <td className="py-3.5 px-4 font-mono font-bold">{del.requirementId}</td>
                      <td className="py-3.5 px-4">{del.deliveryDate}</td>
                      <td className="py-3.5 px-4">{del.receivedBy || 'Pending receipt'}</td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-100 text-emerald-800">
                          {del.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedOrderId(del.requirementId)}
                          className="px-3 py-1 bg-slate-900 text-white rounded-md text-[11px] font-bold"
                        >
                          Trace
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        );

      case 'companies':
        return <CompanyMaster />;

      case 'purchase-executives':
        return <PurchaseExecutiveMaster />;

      case 'customers':
        return <CustomerMaster />;

      case 'vendors':
        return <VendorMaster />;

      case 'brands':
        return <BrandMaster onNavigateToVendors={() => setActiveTab('vendors')} />;

      case 'categories':
        return <CategoryMaster />;

      case 'products':
        return <ProductMaster />;

      case 'reports':
        return <ReportsView />;

      case 'company-reports':
        return <CompanyExecutiveReportsView />;

      case 'documents':
        return <DocumentCenter />;

      case 'audit-log':
        return <AuditLogView />;

      case 'backup-recovery':
        return <BackupRecoveryView />;

      case 'sales-billing':
        return <SalesBillingView />;

      case 'purchase-bills':
        return <PurchaseBillsView />;

      case 'accounting':
        return <AccountingView />;

      case 'email-rfq':
        return (
          <EmailRfqInboxView
            onOpenRequirement={(reqId) => {
              setSelectedOrderId(reqId);
              setActiveTab('requirements');
            }}
          />
        );

      case 'inventory':
        return <InventoryManagementView />;

      case 'users':
        return <UserManagementView />;

      case 'approvals':
        return <ApprovalDashboardView />;

      default:
        return (
          <DashboardView
            onOpenNewReq={() => setIsNewReqOpen(true)}
            onOpenNewCustomer={() => setActiveTab('customers')}
            onOpenNewVendor={() => setActiveTab('vendors')}
            onOpenNewEnquiry={() => setActiveTab('requirements')}
            onOpenNewQuotation={() => setQuotationParams({})}
            onOpenGoogleSheets={() => setIsGoogleSheetsOpen(true)}
            onSelectOrder={(id) => setSelectedOrderId(id)}
          />
        );
    }
  };

  if (!isAuthenticated) {
    return <LoginPage onLoginSuccess={() => setIsAuthenticated(true)} />;
  }

  return (
    <>
      {isMobileView ? (
        <MobileShell
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenNewReqModal={() => setIsNewReqOpen(true)}
          onOpenLoginModal={() => setIsLoginOpen(true)}
          onSignOutToLogin={() => setIsAuthenticated(false)}
        >
          {renderTabContent()}
        </MobileShell>
      ) : (
        <div className="min-h-screen bg-slate-50 flex flex-col antialiased">
          <Navbar
            onOpenSearch={() => setIsSearchOpen(true)}
            onOpenLoginModal={() => setIsLoginOpen(true)}
            onOpenGoogleSheetsModal={() => setIsGoogleSheetsOpen(true)}
            onSignOutToLogin={() => setIsAuthenticated(false)}
          />

          <div className="flex-1 flex overflow-hidden">
            <Sidebar />
            <main className="flex-1 overflow-y-auto">{renderTabContent()}</main>
          </div>
        </div>
      )}

      {/* Modals */}
      <GlobalSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        onSelectOrder={(id) => setSelectedOrderId(id)}
      />

      <LoginModal
        isOpen={isLoginOpen}
        onClose={() => setIsLoginOpen(false)}
      />

      <GoogleSheetsModal
        isOpen={isGoogleSheetsOpen}
        onClose={() => setIsGoogleSheetsOpen(false)}
      />

      {selectedOrderId && (
        <OrderTimelineModal
          orderId={selectedOrderId}
          onClose={() => setSelectedOrderId(null)}
          onOpenRateEntry={(reqId) => {
            setRateSubmissionReqId(reqId);
          }}
          onOpenRateComparison={() => {
            setActiveTab('rate-comparison');
            setSelectedOrderId(null);
          }}
          onOpenQuotation={(reqId) => setQuotationParams({ reqId })}
          onOpenCustomerPo={(reqId) => setCpoReqId(reqId)}
          onOpenVendorPo={(reqId) => setVpoReqId(reqId)}
          onOpenVendorPi={(vpoId) => setPiVpoId(vpoId)}
          onOpenPayment={(piId) => setPayPiId(piId)}
          onOpenDispatch={(reqId) => setDspReqId(reqId)}
          onOpenDelivery={(reqId) => setDelReqId(reqId)}
        />
      )}

      {rateSubmissionReqId && (
        <DirectVendorRateEntryModal
          isOpen={true}
          defaultRequirementId={rateSubmissionReqId}
          onClose={() => setRateSubmissionReqId(null)}
          onSuccess={() => setRateSubmissionReqId(null)}
        />
      )}

      <NewRequirementModal
        isOpen={isNewReqOpen}
        onClose={() => setIsNewReqOpen(false)}
      />

      {rfqReqId && (
        <VendorEnquiryModal
          requirementId={rfqReqId}
          isOpen={true}
          onClose={() => setRfqReqId(null)}
        />
      )}

      {rateSubmissionEnquiryId && (
        <VendorRateSubmissionModal
          enquiryId={rateSubmissionEnquiryId}
          isOpen={true}
          onClose={() => setRateSubmissionEnquiryId(null)}
        />
      )}

      {quotationParams && (
        <NewQuotationModal
          requirementId={quotationParams.reqId}
          quoteId={quotationParams.quoteId}
          isOpen={true}
          onClose={() => setQuotationParams(null)}
        />
      )}

      {cpoReqId && (
        <CustomerPOModal
          requirementId={cpoReqId}
          isOpen={true}
          onClose={() => setCpoReqId(null)}
        />
      )}

      {vpoReqId && (
        <VendorPOModal
          requirementId={vpoReqId}
          isOpen={true}
          onClose={() => setVpoReqId(null)}
        />
      )}

      {piVpoId && (
        <ProformaInvoiceModal
          vendorPoId={piVpoId}
          isOpen={true}
          onClose={() => setPiVpoId(null)}
        />
      )}

      {payPiId && (
        <PaymentModal
          piId={payPiId}
          isOpen={true}
          onClose={() => setPayPiId(null)}
        />
      )}

      {dspReqId && (
        <DispatchModal
          requirementId={dspReqId}
          isOpen={true}
          onClose={() => setDspReqId(null)}
        />
      )}

      {delReqId && (
        <DeliveryModal
          requirementId={delReqId}
          isOpen={true}
          onClose={() => setDelReqId(null)}
        />
      )}

      {/* Direct Email Link Verification & Audit Modal */}
      {verifyOrderAuditId && (
        <EarningRulesAndLockModal
          isOpen={!!verifyOrderAuditId}
          onClose={() => setVerifyOrderAuditId(null)}
          requirementId={verifyOrderAuditId}
        />
      )}

      {/* Floating Chat Widget removed as requested */}
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
