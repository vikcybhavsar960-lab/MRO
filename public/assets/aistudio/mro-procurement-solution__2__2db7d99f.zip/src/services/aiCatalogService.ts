import {
  Vendor,
  VendorCatalogFile,
  VendorCatalogProduct,
  VendorMaterialCategory,
  AIActivityLog,
  CustomerRequirement,
} from '../types';
import { fetchApi } from '../utils/apiClient';

export interface VendorAnalysisResult {
  fileName: string;
  fileType: VendorCatalogFile['fileType'];
  products: Omit<VendorCatalogProduct, 'id'>[];
  suggestedCategories: Omit<VendorMaterialCategory, 'id'>[];
  vendorProfile?: {
    supplierName: string;
    categories: Array<{ category: string; subCategory?: string; brands: string[]; productCount: number }>;
    distinctBrands: string[];
    summaryMetrics: {
      totalProducts: number;
      distinctBrandsCount: number;
      distinctCategoriesCount: number;
      needsReviewCount: number;
    };
  };
  modelUsed: string;
}

/**
 * Standard MRO Categories and sub-categories
 */
export const STANDARDIZED_MRO_CATEGORIES: {
  category: string;
  subCategories: string[];
  commonBrands: string[];
}[] = [
  {
    category: 'Bearings',
    subCategories: [
      'Deep Groove Ball Bearings',
      'Spherical Roller Bearings',
      'Tapered Roller Bearings',
      'Pillow Block Bearings',
      'Cylindrical Roller Bearings',
      'Needle Roller Bearings',
      'Thrust Bearings',
    ],
    commonBrands: ['SKF', 'FAG', 'Timken', 'NSK', 'NTN', 'KOYO'],
  },
  {
    category: 'Belts & Power Transmission',
    subCategories: ['Timing Belts', 'V-Belts', 'Conveyor Belts', 'Roller Chains', 'Sprockets', 'Pulleys', 'Couplings'],
    commonBrands: ['Gates', 'Fenner', 'Continental', 'Bando', 'Optibelt', 'Megadyne'],
  },
  {
    category: 'Electrical',
    subCategories: ['Industrial Wiring', 'Terminals & Lugs', 'Transformers', 'Power Supplies', 'Enclosures'],
    commonBrands: ['Polycab', 'Havells', 'Finolex', 'L&T', 'Legrand'],
  },
  {
    category: 'Electrical Cables',
    subCategories: ['Armoured Power Cables', 'Flexible Multi-Core Cables', 'Control Cables', 'High Temp Silicone Cables', 'Solar Cables'],
    commonBrands: ['Polycab', 'Finolex', 'Lapp Group', 'RR Kabel', 'Havells'],
  },
  {
    category: 'Switchgear',
    subCategories: ['Miniature Circuit Breakers (MCB)', 'Molded Case Circuit Breakers (MCCB)', 'Power Contactors', 'Thermal Overload Relays', 'Air Circuit Breakers (ACB)'],
    commonBrands: ['Schneider Electric', 'Siemens', 'ABB', 'L&T', 'Eaton'],
  },
  {
    category: 'Automation',
    subCategories: ['Programmable Logic Controllers (PLC)', 'Human Machine Interfaces (HMI)', 'Variable Frequency Drives (VFD)', 'Servo Drives & Motors', 'SCADA Systems'],
    commonBrands: ['Siemens', 'Allen-Bradley', 'Mitsubishi', 'Delta', 'Omron', 'Schneider'],
  },
  {
    category: 'Sensors',
    subCategories: ['Inductive Proximity Sensors', 'Photoelectric Sensors', 'Pressure Transmitters', 'RTD / Thermocouples', 'Flow Meters', 'Level Transmitters'],
    commonBrands: ['IFM Electronic', 'Omron', 'Pepperl+Fuchs', 'Sick', 'Balluff', 'Autonics'],
  },
  {
    category: 'Motors',
    subCategories: ['Three Phase Induction Motors', 'Explosion Proof Flameproof Motors', 'Brake Motors', 'DC Motors', 'Geared Motors'],
    commonBrands: ['Siemens', 'ABB', 'Bharat Bijlee', 'Crompton', 'Kirloskar'],
  },
  {
    category: 'Pumps',
    subCategories: ['Centrifugal Pumps', 'Submersible Pumps', 'Positive Displacement Pumps', 'Diaphragm Chemical Pumps', 'Hydraulic Gear Pumps'],
    commonBrands: ['Grundfos', 'Kirloskar', 'KSB', 'WILO', 'Flowserve'],
  },
  {
    category: 'Valves',
    subCategories: ['Ball Valves', 'Butterfly Valves', 'Globe Valves', 'Check Valves', 'Solenoid Control Valves', 'Gate Valves'],
    commonBrands: ['Audco', 'L&T', 'Festo', 'Spirax Sarco', 'Bray'],
  },
  {
    category: 'Pneumatics',
    subCategories: ['Pneumatic Cylinders', 'Pneumatic Directional Solenoid Valves', 'FRL Units (Filter Regulator Lubricator)', 'PU Tubing & Quick Fittings', 'Air Manifolds'],
    commonBrands: ['Festo', 'SMC', 'Janatics', 'Parker', 'Airtac'],
  },
  {
    category: 'Hydraulics',
    subCategories: ['Hydraulic Cylinders', 'Directional Spool Valves', 'Hydraulic Power Packs', 'Pressure Relief Valves', 'Hydraulic Hoses & Adapters', 'Hydraulic Filters'],
    commonBrands: ['Bosch Rexroth', 'Parker', 'Eaton Vickers', 'Yuken', 'Danfoss'],
  },
  {
    category: 'Fasteners',
    subCategories: ['High Tensile Grade 8.8 / 10.9 Bolts', 'Stainless Steel SS304/SS316 Fasteners', 'Nyloc Nuts', 'Spring Washers', 'Threaded Rods'],
    commonBrands: ['Unbrako', 'TVS Fasteners', 'APL', 'Sundram Fasteners'],
  },
  {
    category: 'Tools',
    subCategories: ['Insulated Hand Tools', 'Pneumatic Impact Wrenches', 'Torque Wrenches', 'Drill Bits & Taps', 'Angle Grinders'],
    commonBrands: ['Bosch', 'Stanley', 'Taparia', 'Makita', 'DeWalt'],
  },
  {
    category: 'Safety Products',
    subCategories: ['Safety Shoes', 'Protective Eyewear & Goggles', 'Cut Resistant Gloves', 'Safety Helmets', 'Full Body Harnesses', 'Ear Muffs'],
    commonBrands: ['3M', 'Karam', 'Udyogi', 'Honeywell', 'Allen Cooper'],
  },
  {
    category: 'Lubricants & Greases',
    subCategories: ['High Temperature Bearing Grease', 'Synthetic Gear Oil ISO VG 220/320', 'Hydraulic Oil ISO VG 46/68', 'Food Grade Lubricants', 'Rust Preventive Sprays'],
    commonBrands: ['Mobil', 'Shell', 'Castrol', 'Kluber', 'Fuchs', 'Mosil'],
  },
  {
    category: 'Welding',
    subCategories: ['MIG/TIG Welding Machines', 'Mild Steel Electrodes', 'Argon Regulators', 'Welding Torches & Tips', 'Auto Darkening Helmets'],
    commonBrands: ['ESAB', 'Ador Welding', 'Lincoln Electric', 'Miller'],
  },
  {
    category: 'Packaging Materials',
    subCategories: ['BOPP Tapes', 'Stretch Wrap Films', 'HDPE Strapping Rolls', 'VCI Anti-Corrosion Bags', 'Corrugated Sheets'],
    commonBrands: ['Signode', '3M', 'Wonder Polymers'],
  },
  {
    category: 'HVAC',
    subCategories: ['AHU Blower Motors', 'Refrigerant Gases (R410A, R134A)', 'HEPA Air Filters', 'Compressor Spares', 'Cooling Tower Nozzles'],
    commonBrands: ['Daikin', 'Blue Star', 'Carrier', 'Copeland', 'Danfoss'],
  },
  {
    category: 'Instrumentation',
    subCategories: ['Digital Pressure Gauges', 'Temperature Controllers (PID)', 'Calibrators', 'Chart Recorders', 'Thermocouple Sensors'],
    commonBrands: ['WIKA', 'Yokogawa', 'Endress+Hauser', 'Honeywell', 'Baumer'],
  },
  {
    category: 'Mechanical Components',
    subCategories: ['Oil Seals & O-Rings', 'Spiral Wound Gaskets', 'Shaft Keys & Retaining Rings', 'Linear Bushings', 'Ball Screws'],
    commonBrands: ['Freudenberg', 'Simrit', 'Garlock', 'THK', 'Hiwin'],
  },
];

/**
 * Normalizes a product code or name for deduplication
 * e.g. "SKF 6205 2RS" => "skf:62052rs"
 * e.g. "6205-2RS SKF Bearing" => "skf:62052rs"
 */
export function normalizeProductKey(productName: string, brand?: string, partNumber?: string): string {
  const cleanBrand = (brand || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  const combined = `${brand || ''} ${productName} ${partNumber || ''}`.toLowerCase();

  // Extract core alphanumeric model/part token
  const cleaned = combined
    .replace(/deep groove ball bearing|roller bearing|bearing|valve|cylinder|motor|contactor|switchgear|cable|sensor|fastener/gi, '')
    .replace(/[^a-z0-9]/g, '');

  return `${cleanBrand}:${cleaned}`;
}

/**
 * Checks a product against an existing list to detect duplicate items
 */
export function detectDuplicateProduct(
  newProduct: Omit<VendorCatalogProduct, 'id'>,
  existingProducts: VendorCatalogProduct[]
): { isDuplicate: boolean; duplicateOf?: VendorCatalogProduct } {
  const targetKey = normalizeProductKey(newProduct.productName, newProduct.brand, newProduct.partNumber);

  for (const existing of existingProducts) {
    const existingKey = existing.normalizedKey || normalizeProductKey(existing.productName, existing.brand, existing.partNumber);
    if (existingKey === targetKey) {
      return { isDuplicate: true, duplicateOf: existing };
    }

    // Secondary check: exact part number match under the same brand
    if (
      newProduct.partNumber &&
      existing.partNumber &&
      newProduct.partNumber.trim().toLowerCase() === existing.partNumber.trim().toLowerCase() &&
      (!newProduct.brand || !existing.brand || newProduct.brand.toLowerCase() === existing.brand.toLowerCase())
    ) {
      return { isDuplicate: true, duplicateOf: existing };
    }
  }

  return { isDuplicate: false };
}

/**
 * Offline / Fallback Intelligent Industrial Parser
 * Used when network is unavailable or user selects instant sample catalog
 */
export function parseCatalogLocally(
  fileName: string,
  rawText: string,
  vendorId: string
): {
  products: Omit<VendorCatalogProduct, 'id'>[];
  suggestedCategories: Omit<VendorMaterialCategory, 'id'>[];
} {
  const lines = rawText.split('\n').map((l) => l.trim()).filter((l) => l.length > 5);
  const products: Omit<VendorCatalogProduct, 'id'>[] = [];
  const categoryMap = new Map<string, {
    subCategory?: string;
    brands: Set<string>;
    count: number;
    totalConfidence: number;
  }>();

  for (const line of lines) {
    let matchedCategory = 'Mechanical Components';
    let matchedSubCategory = 'General Industrial Spares';
    let matchedBrand = 'Generic Industrial';
    let partNum = '';
    let spec = '';
    let confidence = 88;

    const lower = line.toLowerCase();

    // Bearings
    if (lower.includes('bearing') || lower.includes('620') || lower.includes('630') || lower.includes('222') || lower.includes('skf') || lower.includes('fag')) {
      matchedCategory = 'Bearings';
      matchedSubCategory = lower.includes('spherical') || lower.includes('222')
        ? 'Spherical Roller Bearings'
        : lower.includes('pillow') || lower.includes('ucp')
        ? 'Pillow Block Bearings'
        : lower.includes('taper')
        ? 'Tapered Roller Bearings'
        : 'Deep Groove Ball Bearings';

      if (lower.includes('skf')) matchedBrand = 'SKF';
      else if (lower.includes('fag')) matchedBrand = 'FAG';
      else if (lower.includes('timken')) matchedBrand = 'Timken';
      else matchedBrand = 'SKF';

      const match = line.match(/\b([0-9]{4,5}[A-Z0-9\-\/]*)\b/i);
      if (match) partNum = match[1].toUpperCase();
      spec = 'C3 Clearance, Rubber / Steel Sealed, High Temp Grease';
      confidence = 96;
    }
    // Pneumatics
    else if (lower.includes('pneumatic') || lower.includes('festo') || lower.includes('cylinder') || lower.includes('solenoid') || lower.includes('smc')) {
      matchedCategory = 'Pneumatics';
      matchedSubCategory = lower.includes('cylinder')
        ? 'Pneumatic Cylinders'
        : lower.includes('solenoid') || lower.includes('valve')
        ? 'Pneumatic Directional Solenoid Valves'
        : 'FRL Units (Filter Regulator Lubricator)';

      matchedBrand = lower.includes('smc') ? 'SMC' : lower.includes('janatics') ? 'Janatics' : 'Festo';
      const match = line.match(/\b([A-Z]{2,4}[0-9\-\/]{3,10})\b/i);
      if (match) partNum = match ? match[1].toUpperCase() : 'ADN-32-50';
      spec = 'Working Pressure 1-10 Bar, ISO 15552, Double Acting';
      confidence = 94;
    }
    // Switchgear & Electrical
    else if (lower.includes('contactor') || lower.includes('mcb') || lower.includes('schneider') || lower.includes('siemens') || lower.includes('switchgear')) {
      matchedCategory = 'Switchgear';
      matchedSubCategory = lower.includes('mcb')
        ? 'Miniature Circuit Breakers (MCB)'
        : lower.includes('mccb')
        ? 'Molded Case Circuit Breakers (MCCB)'
        : 'Power Contactors';

      matchedBrand = lower.includes('siemens') ? 'Siemens' : lower.includes('abb') ? 'ABB' : 'Schneider Electric';
      const match = line.match(/\b(LC1[A-Z0-9]+|3RT[A-Z0-9]+|A9[A-Z0-9]+)\b/i);
      if (match) partNum = match ? match[1].toUpperCase() : 'LC1D25M7';
      spec = '415V AC, 3 Pole, 50/60 Hz, Auxiliary Contacts 1NO+1NC';
      confidence = 95;
    }
    // Cables
    else if (lower.includes('cable') || lower.includes('sqmm') || lower.includes('polycab') || lower.includes('armoured')) {
      matchedCategory = 'Electrical Cables';
      matchedSubCategory = lower.includes('armoured')
        ? 'Armoured Power Cables'
        : lower.includes('control')
        ? 'Control Cables'
        : 'Flexible Multi-Core Cables';

      matchedBrand = lower.includes('finolex') ? 'Finolex' : lower.includes('havells') ? 'Havells' : 'Polycab';
      const match = line.match(/([0-9]+\s*core\s*[0-9\.]+\s*sqmm)/i);
      if (match) partNum = match[1].toUpperCase();
      spec = '1100V Grade XLPE Insulated Aluminium / Copper Armoured';
      confidence = 92;
    }
    // Automation & Sensors
    else if (lower.includes('plc') || lower.includes('sensor') || lower.includes('proximity') || lower.includes('hmi') || lower.includes('omron')) {
      matchedCategory = lower.includes('sensor') ? 'Sensors' : 'Automation';
      matchedSubCategory = lower.includes('sensor') ? 'Inductive Proximity Sensors' : 'Programmable Logic Controllers (PLC)';
      matchedBrand = lower.includes('omron') ? 'Omron' : lower.includes('ifm') ? 'IFM Electronic' : 'Siemens';
      partNum = 'S7-1200 CPU 1214C';
      spec = '24V DC, PNP NO, IP67 Protection, M12 Connector';
      confidence = 93;
    }
    // Belts & Power Transmission
    else if (lower.includes('belt') || lower.includes('htd') || lower.includes('chain') || lower.includes('fenner') || lower.includes('gates')) {
      matchedCategory = 'Belts & Power Transmission';
      matchedSubCategory = lower.includes('timing') || lower.includes('htd') ? 'Timing Belts' : 'V-Belts';
      matchedBrand = lower.includes('gates') ? 'Gates' : lower.includes('continental') ? 'Continental' : 'Fenner';
      const match = line.match(/\b([A-Z0-9]{3,8}\-[0-9]{1,4}[A-Z0-9]*)\b/i);
      if (match) partNum = match ? match[1].toUpperCase() : 'HTD 8M-1040-20';
      spec = 'Curvilinear Tooth Profile, Fiberglass Cord, Neoprene Rubber';
      confidence = 91;
    }
    // Valves
    else if (lower.includes('valve') || lower.includes('ball valve') || lower.includes('butterfly')) {
      matchedCategory = 'Valves';
      matchedSubCategory = lower.includes('butterfly') ? 'Butterfly Valves' : 'Ball Valves';
      matchedBrand = 'Audco';
      partNum = 'VLV-DN50-PN16';
      spec = 'CF8M Stainless Steel Body, PTFE Seats, Class 150 Flanged';
      confidence = 90;
    }

    const normKey = normalizeProductKey(line, matchedBrand, partNum);

    const product: Omit<VendorCatalogProduct, 'id'> = {
      vendorId,
      catalogFileName: fileName,
      productName: line.slice(0, 70),
      description: `Industrial ${matchedCategory} - ${matchedSubCategory} (${matchedBrand})`,
      category: matchedCategory,
      subCategory: matchedSubCategory,
      brand: matchedBrand,
      manufacturer: matchedBrand,
      modelNumber: partNum || 'MRO-STD',
      partNumber: partNum || undefined,
      specification: spec,
      uom: matchedCategory === 'Electrical Cables' ? 'MTR' : 'NOS',
      keywords: [matchedCategory, matchedSubCategory, matchedBrand, partNum].filter(Boolean),
      catalogReference: `Line ${lines.indexOf(line) + 1}`,
      evidence: line.slice(0, 100),
      aiConfidence: confidence,
      confidenceLevel: confidence >= 90 ? 'High' : 'Medium',
      reviewStatus: matchedBrand !== 'Generic Industrial' && matchedBrand !== 'Unconfirmed' ? 'Verified' : 'Needs Review',
      approvalStatus: 'PENDING',
      normalizedKey: normKey,
    };

    products.push(product);

    // Aggregate category
    const catEntry = categoryMap.get(matchedCategory) || {
      subCategory: matchedSubCategory,
      brands: new Set<string>(),
      count: 0,
      totalConfidence: 0,
    };
    catEntry.brands.add(matchedBrand);
    catEntry.count += 1;
    catEntry.totalConfidence += confidence;
    categoryMap.set(matchedCategory, catEntry);
  }

  const suggestedCategories: Omit<VendorMaterialCategory, 'id'>[] = [];
  categoryMap.forEach((val, catKey) => {
    suggestedCategories.push({
      vendorId,
      category: catKey,
      subCategory: val.subCategory,
      brands: Array.from(val.brands),
      productsFoundCount: val.count,
      confidence: Math.round(val.totalConfidence / val.count),
      sourceDocument: fileName,
      status: 'PENDING_APPROVAL',
      isNewSuggestedCategory: false,
    });
  });

  return { products, suggestedCategories };
}

/**
 * Main AI Catalog Analysis Dispatcher
 * Calls /api/analyze-catalog on the server with seamless local fallback
 */
export async function analyzeVendorCatalog(params: {
  vendorId: string;
  vendorName: string;
  file: File | { name: string; type: string; size?: number; textContent?: string };
}): Promise<VendorAnalysisResult> {
  const { vendorId, vendorName, file } = params;
  const fileName = file.name;
  let fileType: VendorCatalogFile['fileType'] = 'PDF';

  const lowerName = fileName.toLowerCase();
  if (lowerName.endsWith('.xlsx') || lowerName.endsWith('.xls') || lowerName.endsWith('.csv')) fileType = 'EXCEL';
  else if (lowerName.endsWith('.doc') || lowerName.endsWith('.docx')) fileType = 'WORD';
  else if (lowerName.endsWith('.png') || lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg') || lowerName.endsWith('.webp')) fileType = 'IMAGE';
  else if (lowerName.includes('quote') || lowerName.includes('qtn')) fileType = 'QUOTATION';

  // Read text or file content
  let textContent = '';
  let fileData: string | undefined = undefined;
  let mimeType: string | undefined = undefined;

  if ('textContent' in file && file.textContent) {
    textContent = file.textContent;
  } else if (file instanceof File) {
    try {
      if (lowerName.endsWith('.xlsx') || lowerName.endsWith('.xls')) {
        const XLSX = await import('xlsx');
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'array' });
        let combinedSheets = '';
        for (const sheetName of workbook.SheetNames) {
          const sheet = workbook.Sheets[sheetName];
          if (sheet) {
            const csv = XLSX.utils.sheet_to_csv(sheet);
            if (csv.trim()) {
              combinedSheets += `\n--- SHEET: ${sheetName} ---\n${csv}\n`;
            }
          }
        }
        textContent = combinedSheets || `Excel Catalog: ${file.name}`;
      } else if (lowerName.endsWith('.csv') || file.type.includes('text') || file.type.includes('csv')) {
        textContent = await file.text();
      } else if (
        file.type.startsWith('image/') ||
        lowerName.endsWith('.pdf') ||
        lowerName.endsWith('.png') ||
        lowerName.endsWith('.jpg') ||
        lowerName.endsWith('.jpeg') ||
        lowerName.endsWith('.webp')
      ) {
        mimeType = file.type || (lowerName.endsWith('.pdf') ? 'application/pdf' : 'image/jpeg');
        // Fast, non-blocking native base64 conversion via FileReader
        fileData = await new Promise<string>((resolve, reject) => {
          const reader = new FileReader();
          reader.onload = () => {
            const res = reader.result as string;
            const b64 = res.includes(',') ? res.split(',')[1] : res;
            resolve(b64);
          };
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
        textContent = `Attached ${fileType} catalog: ${file.name}. Size: ${(file.size / 1024).toFixed(1)} KB.`;
      } else {
        textContent = await file.text().catch(() => `Vendor Catalog Document: ${file.name}. File size: ${file.size} bytes.`);
      }
    } catch (e) {
      console.warn('File reading error, using file name:', e);
      textContent = `Catalog Document: ${file.name}`;
    }
  }

  // Try calling server-side Gemini API
  try {
    const res = await fetchApi('/api/analyze-catalog', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        vendorId,
        vendorName,
        fileName,
        fileType,
        textContent,
        fileData,
        mimeType,
      }),
    });

    if (res.ok) {
      const data = await res.json();
      if (data.products && data.products.length > 0) {
        // Transform to Omit<VendorCatalogProduct, 'id'>
        const prods: Omit<VendorCatalogProduct, 'id'>[] = data.products.map((p: any) => ({
          vendorId,
          catalogFileName: fileName,
          productName: p.productName || 'Industrial Item',
          description: p.description || '',
          category: p.category || 'Mechanical Components',
          subCategory: p.subCategory || 'General Spares',
          brand: p.brand || 'Unconfirmed',
          manufacturer: p.manufacturer || p.brand || '',
          modelNumber: p.modelNumber || p.partNumber || '',
          partNumber: p.partNumber || p.modelNumber || '',
          specification: p.specification || p.size || '',
          size: p.size || '',
          uom: p.uom || 'NOS',
          keywords: Array.isArray(p.keywords) ? p.keywords : [p.category, p.brand].filter(Boolean),
          catalogReference: p.catalogReference || 'Catalog Document',
          evidence: p.evidence || `Extracted from ${fileName}`,
          aiConfidence: typeof p.aiConfidence === 'number' ? p.aiConfidence : 92,
          confidenceLevel: p.confidenceLevel || (p.aiConfidence && p.aiConfidence >= 85 ? 'High' : 'Medium'),
          reviewStatus: p.reviewStatus || (p.brand && p.brand !== 'Unconfirmed' ? 'Verified' : 'Needs Review'),
          approvalStatus: 'PENDING',
          normalizedKey: normalizeProductKey(p.productName, p.brand, p.partNumber),
        }));

        const cats: Omit<VendorMaterialCategory, 'id'>[] = (data.suggestedCategories || []).map((c: any) => ({
          vendorId,
          category: c.category,
          subCategory: c.subCategory,
          brands: c.brands || [],
          productsFoundCount: c.productsFoundCount || prods.filter((pr) => pr.category === c.category).length || 1,
          confidence: c.confidence || 94,
          sourceDocument: fileName,
          status: 'PENDING_APPROVAL',
          isNewSuggestedCategory: !!c.isNewSuggestedCategory,
        }));

        const distinctBrands = Array.from(new Set(prods.map((p) => p.brand).filter((b) => b && b !== 'Unconfirmed')));
        const distinctCategories = Array.from(new Set(prods.map((p) => p.category)));
        const needsReviewCount = prods.filter((p) => p.reviewStatus === 'Needs Review' || p.brand === 'Unconfirmed').length;

        const vendorProfile = data.vendorProfile || {
          supplierName: vendorName,
          categories: distinctCategories.map((cat) => ({
            category: cat,
            subCategory: prods.find((p) => p.category === cat)?.subCategory || '',
            brands: Array.from(new Set(prods.filter((p) => p.category === cat).map((p) => p.brand))),
            productCount: prods.filter((p) => p.category === cat).length,
          })),
          distinctBrands,
          summaryMetrics: {
            totalProducts: prods.length,
            distinctBrandsCount: distinctBrands.length,
            distinctCategoriesCount: distinctCategories.length,
            needsReviewCount,
          },
        };

        return {
          fileName,
          fileType,
          products: prods,
          suggestedCategories: cats,
          vendorProfile,
          modelUsed: data.modelUsed || 'gemini-3.8-flash',
        };
      }
    }
  } catch (err) {
    console.warn('Server catalog analysis fallback to local parser:', err);
  }

  // Fallback to local industrial heuristic parsing
  const fallbackSampleText = SAMPLE_CATALOG_TEMPLATES.find((t) => t.fileName === fileName)?.rawText || '';
  const localRes = parseCatalogLocally(fileName, textContent || fallbackSampleText, vendorId);

  const distinctBrands = Array.from(new Set(localRes.products.map((p) => p.brand).filter((b) => b && b !== 'Unconfirmed')));
  const distinctCategories = Array.from(new Set(localRes.products.map((p) => p.category)));
  const needsReviewCount = localRes.products.filter((p) => p.reviewStatus === 'Needs Review' || p.brand === 'Unconfirmed').length;

  return {
    fileName,
    fileType,
    products: localRes.products,
    suggestedCategories: localRes.suggestedCategories,
    vendorProfile: {
      supplierName: vendorName,
      categories: distinctCategories.map((cat) => ({
        category: cat,
        subCategory: localRes.products.find((p) => p.category === cat)?.subCategory || '',
        brands: Array.from(new Set(localRes.products.filter((p) => p.category === cat).map((p) => p.brand))),
        productCount: localRes.products.filter((p) => p.category === cat).length,
      })),
      distinctBrands,
      summaryMetrics: {
        totalProducts: localRes.products.length,
        distinctBrandsCount: distinctBrands.length,
        distinctCategoriesCount: distinctCategories.length,
        needsReviewCount,
      },
    },
    modelUsed: 'ProcureMRO Industrial Parser (Deterministic Heuristic Fallback)',
  };
}

/**
 * Pre-built sample catalog contents for instant 1-click testing
 */
export const SAMPLE_CATALOG_TEMPLATES: {
  title: string;
  fileName: string;
  fileType: VendorCatalogFile['fileType'];
  description: string;
  rawText: string;
}[] = [
  {
    title: 'SKF Industrial Bearings & Seals Price List',
    fileName: 'SKF_Industrial_Bearings_Master_PriceList_2026.pdf',
    fileType: 'PDF',
    description: '12 Line items: Deep groove ball bearings (6205, 6308), spherical roller bearings (22212), pillow blocks, Viton seals',
    rawText: `SKF Authorized Industrial Price List & Catalog - 2026
SKF 6205-2RS Deep Groove Ball Bearing 25x52x15mm Rubber Sealed C3
SKF 6206-2RS-C3 Deep Groove Ball Bearing 30x62x16mm Rubber Sealed High Clearance
SKF 6308-ZZ Shielded Deep Groove Ball Bearing 40x90x23mm Steel Shield
SKF 22212-EK Spherical Roller Bearing with Tapered Bore 60x110x28mm W33 Lube Groove
SKF 22216-E Spherical Roller Bearing Cylindrical Bore 80x140x33mm
SKF UCP-206 Pillow Block Housing Unit 30mm Shaft Cast Iron Housing
SKF 7206-BEP Angular Contact Ball Bearing 30x62x16mm Polyamide Cage
SKF 30206 Tapered Roller Bearing Metric 30x62x17.25mm
SKF 32208 Tapered Roller Bearing High Load Capacity 40x80x24.75mm
SKF Viton Double Lip Oil Seal 40x62x8mm HMSA10 V
SKF LGHP 2/0.4 High Performance Bearing Grease 400g Cartridge Polyurea Based
SKF Speedi-Sleeve 99177 Shaft Repair Sleeve 45mm Shaft`,
  },
  {
    title: 'Festo Pneumatics & Valve Automation Catalog',
    fileName: 'Festo_Pneumatic_Automation_Master_Catalog.xlsx',
    fileType: 'EXCEL',
    description: '10 Line items: Solenoid valves VUVS, Compact cylinders ADN, FRL filters MS4, Proximity sensors SMT-8M',
    rawText: `Festo Pneumatics & Solenoid Control Price List
Festo VUVS-L25-M52-MD-G14-F8 Solenoid Valve 5/2 Way 24V DC Internal Pilot
Festo VUVS-LK20-M52-AD-G18-1B2 5/2 Way Solenoid Valve G1/8 inch
Festo ADN-32-50-I-P-A Compact Pneumatic Cylinder Bore 32mm Stroke 50mm Double Acting
Festo DNC-50-100-PPV-A Standard ISO 15552 Pneumatic Cylinder Bore 50mm Stroke 100mm
Festo SMT-8M-A-PS-24V-E-2.5-OE Magnetic Proximity Sensor PNP Normally Open M8
Festo MS4-LFR-1/4-D7-ERM-AS Filter Regulator Lubricator Unit FRL 1/4 inch 7 Bar
Festo PUN-H-8x1.25-BL Polyurethane Air Hose Tubing Blue 8mm OD 100m Roll
Festo QS-1/4-8 Quick Star Push-in Fitting G1/4 Male Thread to 8mm Tubing
Festo VUVG-L10-T32C-AZT-M5-1P3 Compact Solenoid Valve Manifold Mount 24V DC
Festo DSNU-25-80-PPV-A Round Pneumatic Cylinder Stainless Steel Piston Bore 25mm Stroke 80mm`,
  },
  {
    title: 'Schneider Electric Switchgear & Contactor Quotation',
    fileName: 'Schneider_Switchgear_TeSys_Quotation_2026.docx',
    fileType: 'WORD',
    description: '9 Line items: TeSys contactors LC1D25, Acti9 MCBs 16A/32A, Thermal Overload Relays LRD, VFD Altivar 320',
    rawText: `Schneider Electric Industrial Switchgear & Motor Control Quotation
Schneider Electric TeSys Deca LC1D25M7 3-Pole Contactor 25A 415V AC-3 Coil 220V AC
Schneider Electric TeSys Deca LC1D09M7 Power Contactor 9A Coil 220V AC
Schneider Electric TeSys Deca LC1D32M7 Power Contactor 32A 15kW Motor Duty
Schneider Electric LRD32 TeSys Thermal Overload Relay 23-32A Class 10A
Schneider Electric Acti9 iC60N 4P 16A C Curve Miniature Circuit Breaker MCB 10kA
Schneider Electric Acti9 iC60N 4P 32A C Curve MCB 10kA
Schneider Electric Compact NSX100F 3P 100A 36kA Molded Case Circuit Breaker MCCB TMD Trip
Schneider Electric Altivar Machine ATV320 Variable Speed Drive VFD 5.5 kW 400V 3-Phase
Schneider Electric Harmony XB4 Flush Pushbutton 22mm Green 1NO Spring Return`,
  },
  {
    title: 'Polycab Industrial Cables & Finolex Wires List',
    fileName: 'Polycab_Industrial_Power_Control_Cables_Catalog.pdf',
    fileType: 'PDF',
    description: '8 Line items: 4 Core 4 Sqmm Armoured Cable, Control Cables 1.5 Sqmm, Multi-Core Flexible Copper Cables',
    rawText: `Polycab Wires & Cables Industrial Price Schedule
Polycab 4 Core 4 Sqmm XLPE Insulated Aluminium Armoured Cable 1.1 kV Grade
Polycab 4 Core 16 Sqmm XLPE Aluminium Armoured Power Cable Heavy Duty
Polycab 3.5 Core 70 Sqmm Aluminium Armoured Cable 1100V
Polycab 7 Core 1.5 Sqmm Copper Armoured Control Cable 1.1 kV Grade
Polycab 12 Core 1.5 Sqmm Flexible Copper Control Cable Unarmoured
Polycab 1 Core 95 Sqmm Flexible Copper Single Core Cable
Finolex 3 Core 2.5 Sqmm Submersible Flat Cable Heavy Duty PVC
Lapp Group OLFLEX CLASSIC 110 5G1.5 Flexible Control Cable Number Coded`,
  },
];

/**
 * Searches and matches vendors based on comprehensive multi-facet criteria:
 * Product, Category, Sub-category, Brand, Part Number, Keyword, Vendor Name
 */
export function searchVendorsMultiFacet(
  vendors: Vendor[],
  query: {
    text?: string;
    category?: string;
    subCategory?: string;
    brand?: string;
    partNumber?: string;
  }
): {
  vendor: Vendor;
  matchScore: number;
  matchedCategories: string[];
  matchedBrands: string[];
  matchedProductsCount: number;
  matchReasons: string[];
}[] {
  const cleanText = (query.text || '').toLowerCase().trim();
  const cleanCat = (query.category || '').toLowerCase().trim();
  const cleanSubCat = (query.subCategory || '').toLowerCase().trim();
  const cleanBrand = (query.brand || '').toLowerCase().trim();
  const cleanPart = (query.partNumber || '').toLowerCase().trim();

  const results: {
    vendor: Vendor;
    matchScore: number;
    matchedCategories: string[];
    matchedBrands: string[];
    matchedProductsCount: number;
    matchReasons: string[];
  }[] = [];

  for (const v of vendors) {
    let score = 0;
    const reasons: string[] = [];
    const matchedCategories: string[] = [];
    const matchedBrands: string[] = [];
    let matchedProductsCount = 0;

    const vendorCats = [
      ...(v.materialCategories || []),
      ...(v.productCategories || []),
      ...(v.aiMaterialCategories?.filter((c) => c.status === 'APPROVED').map((c) => c.category) || []),
    ];
    const vendorSubCats = [
      ...(v.subCategories || []),
      ...(v.aiMaterialCategories?.filter((c) => c.status === 'APPROVED' && c.subCategory).map((c) => c.subCategory!) || []),
    ];
    const vendorBrands = [
      ...(v.brandsSupplied || []),
      ...(v.aiMaterialCategories?.filter((c) => c.status === 'APPROVED').flatMap((c) => c.brands) || []),
    ];
    const catalogProducts = [
      ...(v.catalogProducts || []),
      ...(v.productsSupplied || []),
    ];

    // 1. Text Search across everything
    if (cleanText) {
      if (v.companyName.toLowerCase().includes(cleanText)) {
        score += 35;
        reasons.push(`Company name matches "${cleanText}"`);
      }

      // Check category match
      for (const cat of vendorCats) {
        if (cat.toLowerCase().includes(cleanText)) {
          score += 40;
          matchedCategories.push(cat);
          reasons.push(`Approved Category: ${cat}`);
        }
      }

      // Check sub-category match
      for (const sub of vendorSubCats) {
        if (sub.toLowerCase().includes(cleanText)) {
          score += 45;
          reasons.push(`Sub-Category: ${sub}`);
        }
      }

      // Check brand match
      for (const br of vendorBrands) {
        if (br.toLowerCase().includes(cleanText)) {
          score += 45;
          matchedBrands.push(br);
          reasons.push(`Authorized Brand: ${br}`);
        }
      }

      // Check catalog products
      for (const p of catalogProducts) {
        const itemKeywords = 'keywords' in p && Array.isArray((p as any).keywords) ? (p as any).keywords : [];
        if (
          p.productName.toLowerCase().includes(cleanText) ||
          (p.partNumber && p.partNumber.toLowerCase().includes(cleanText)) ||
          ((p as any).modelNumber && (p as any).modelNumber.toLowerCase().includes(cleanText)) ||
          ((p as any).specification && (p as any).specification.toLowerCase().includes(cleanText)) ||
          itemKeywords.some((k: string) => k.toLowerCase().includes(cleanText))
        ) {
          score += 30;
          matchedProductsCount++;
          if (p.brand && !matchedBrands.includes(p.brand)) matchedBrands.push(p.brand);
          if (p.category && !matchedCategories.includes(p.category)) matchedCategories.push(p.category);
        }
      }
    }

    // 2. Specific filter matching
    if (cleanCat && cleanCat !== 'all') {
      const catMatch = vendorCats.some((c) => c.toLowerCase() === cleanCat);
      if (catMatch) {
        score += 50;
        reasons.push(`Exact Category Match: ${cleanCat}`);
      } else {
        score -= 20;
      }
    }

    if (cleanSubCat && cleanSubCat !== 'all') {
      const subMatch = vendorSubCats.some((s) => s.toLowerCase() === cleanSubCat);
      if (subMatch) {
        score += 40;
        reasons.push(`Sub-Category Match: ${cleanSubCat}`);
      }
    }

    if (cleanBrand) {
      const brandMatch = vendorBrands.some((b) => b.toLowerCase().includes(cleanBrand));
      if (brandMatch) {
        score += 35;
        reasons.push(`Supplies Brand: ${cleanBrand}`);
      }
    }

    if (cleanPart) {
      const partMatch = catalogProducts.some(
        (p) =>
          (p.partNumber && p.partNumber.toLowerCase().includes(cleanPart)) ||
          ((p as any).modelNumber && (p as any).modelNumber.toLowerCase().includes(cleanPart)) ||
          p.productName.toLowerCase().includes(cleanPart)
      );
      if (partMatch) {
        score += 50;
        reasons.push(`Exact Part/Model match: ${cleanPart}`);
      }
    }

    // Previous supply history boost
    if (v.supplyHistory && v.supplyHistory.length > 0) {
      score += Math.min(v.supplyHistory.length * 3, 15);
      reasons.push(`${v.supplyHistory.length} previous supply orders completed`);
    }

    // Status check
    if (v.status === 'ACTIVE') score += 5;
    if (v.status === 'BLOCKED') score = 0;

    const finalMatchScore = Math.min(Math.max(score, 0), 99);

    // If query was empty or score is positive
    if ((!cleanText && !cleanCat && !cleanBrand && !cleanPart) || score > 0) {
      results.push({
        vendor: v,
        matchScore: cleanText || cleanCat || cleanBrand || cleanPart ? finalMatchScore : 70,
        matchedCategories: Array.from(new Set(matchedCategories)),
        matchedBrands: Array.from(new Set(matchedBrands)),
        matchedProductsCount,
        matchReasons: reasons.length > 0 ? reasons : ['Registered Industrial Supplier'],
      });
    }
  }

  // Sort descending by matchScore
  return results.sort((a, b) => b.matchScore - a.matchScore);
}

/**
 * Recommends vendors for a Customer Requirement using AI-approved catalog profiles
 */
export function recommendVendorsFromAiProfile(
  requirement: {
    category: string;
    subCategory?: string;
    itemName: string;
    brand?: string;
    description?: string;
  },
  vendors: Vendor[]
): {
  vendorId: string;
  vendorName: string;
  contactPerson: string;
  mobile: string;
  email: string;
  city: string;
  matchScore: number;
  matchLevel: 'High' | 'Medium' | 'Low';
  matchReasons: string[];
  matchedProductsCount: number;
  hasCatalogData: boolean;
}[] {
  const query = `${requirement.brand || ''} ${requirement.itemName} ${requirement.category} ${requirement.subCategory || ''}`;
  const matches = searchVendorsMultiFacet(vendors, {
    text: query,
    category: requirement.category,
    subCategory: requirement.subCategory,
    brand: requirement.brand,
  });

  return matches.map((m) => {
    let matchLevel: 'High' | 'Medium' | 'Low' = 'Low';
    if (m.matchScore >= 90) matchLevel = 'High';
    else if (m.matchScore >= 75) matchLevel = 'Medium';

    return {
      vendorId: m.vendor.id,
      vendorName: m.vendor.companyName,
      contactPerson: m.vendor.contactPerson,
      mobile: m.vendor.mobile,
      email: m.vendor.email,
      city: m.vendor.city,
      matchScore: m.matchScore,
      matchLevel,
      matchReasons: m.matchReasons,
      matchedProductsCount: m.matchedProductsCount,
      hasCatalogData: (m.vendor.catalogProducts || []).length > 0,
    };
  });
}
