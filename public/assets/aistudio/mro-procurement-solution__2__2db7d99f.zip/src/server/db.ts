import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { INITIAL_MATERIAL_CATEGORIES } from '../data/categoryMasterData';
import { INITIAL_BRANDS } from '../data/brandMasterData';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure data directory exists
const DATA_DIR = path.resolve(__dirname, '../../data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_FILE = path.join(DATA_DIR, 'erp_production.json');

// Security: Hash password using PBKDF2 with salt
export function hashPassword(password: string, salt?: string): { hash: string; salt: string } {
  const generatedSalt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, generatedSalt, 1000, 64, 'sha512').toString('hex');
  return { hash, salt: generatedSalt };
}

export function verifyPassword(password: string, hash: string, salt: string): boolean {
  const check = crypto.pbkdf2Sync(password, salt, 1000, 64, 'sha512').toString('hex');
  return check === hash;
}

// User & Role Definitions
export interface UserRecord {
  id: string;
  name: string;
  email: string;
  username: string;
  passwordHash: string;
  passwordSalt: string;
  role: string;
  department: string;
  mobile: string;
  status: 'ACTIVE' | 'INACTIVE';
  approvalAuthority: {
    canApproveRequirements: boolean;
    canApproveRfqs: boolean;
    canApprovePos: boolean;
    canApprovePayments: boolean;
    maxApprovalLimit: number; // 0 = unlimited, otherwise max amount in INR
  };
  permissions: {
    modules: {
      dashboard: boolean;
      requirements: boolean;
      rfqs: boolean;
      approvals: boolean;
      vendors: boolean;
      quotations: boolean;
      customerPos: boolean;
      vendorPos: boolean;
      payments: boolean;
      dispatch: boolean;
      reports: boolean;
      userManagement: boolean;
      auditTrail: boolean;
    };
    actions: {
      canView: boolean;
      canAdd: boolean;
      canEdit: boolean;
      canDelete: boolean;
      canApprove: boolean;
    };
  };
  createdAt: string;
  lastLogin?: string;
}

export interface RoleDefinition {
  id: string;
  name: string;
  description: string;
  defaultPermissions: UserRecord['permissions'];
  approvalLimit: number;
}

export interface ApprovalRecord {
  id: string;
  requestType: 'REQUIREMENT' | 'RFQ' | 'CUSTOMER_PO' | 'VENDOR_PO' | 'PAYMENT' | 'PRICE_OVERRIDE';
  requestNumber: string;
  requestDate: string;
  requestorId: string;
  requestorName: string;
  department: string;
  vendorOrCustomer: string;
  amount: number;
  currency: string;
  status: 'PENDING' | 'APPROVED' | 'REJECTED' | 'SENT_BACK';
  approvalLevel: 'LEVEL_1' | 'LEVEL_2' | 'FINAL';
  pendingSince: string;
  details: string;
  approverId?: string;
  approverName?: string;
  actionDate?: string;
  comments?: string;
  history: Array<{
    action: string;
    actor: string;
    timestamp: string;
    comments?: string;
  }>;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user: string;
  role: string;
  action: string;
  module: string;
  recordNumber: string;
  oldStatus?: string;
  newStatus?: string;
  remarks: string;
  ipAddress?: string;
}

export interface RfqClosureDetails {
  rfqNumber: string;
  customerName: string;
  customerRfqReference: string;
  closureDate: string;
  closureReason: 'CUSTOMER_CONFIRMATION' | 'BUDGET_CANCELLED' | 'LOST_TO_COMPETITOR' | 'SPEC_CHANGED' | 'OTHER';
  customerEmailReference: string; // e.g. "Email from John (Procurement Head) on 04-Oct-2026: Project on hold"
  remarks: string;
  closedBy: string;
  closedAt: string;
}

export interface LoginAuditRecord {
  id: string;
  timestamp: string;
  username: string;
  role: string;
  userId?: string;
  status: 'SUCCESS' | 'FAILED';
  ipAddress: string;
  userAgent: string;
  deviceType: string;
  sessionId: string;
  failureReason?: string;
}

export interface ActiveSessionRecord {
  id: string;
  userId: string;
  username: string;
  name: string;
  role: string;
  ipAddress: string;
  userAgent: string;
  deviceType: string;
  loginTime: string;
  lastActiveTime: string;
  status: 'ACTIVE' | 'REVOKED';
}

export interface ErpDatabaseSchema {
  version: number;
  lastUpdated: string;
  users: UserRecord[];
  roles: RoleDefinition[];
  approvals: ApprovalRecord[];
  auditLogs: AuditLogEntry[];
  requirements: any[];
  deletedRequirementIds: string[];
  companies: any[];
  purchaseExecutives: any[];
  customers: any[];
  vendors: any[];
  products: any[];
  quotations: any[];
  customerPos: any[];
  vendorPos: any[];
  proformaInvoices: any[];
  payments: any[];
  dispatches: any[];
  deliveries: any[];
  rfqs: any[];
  vendorQuotes: any[];
  notifications: any[];
  loginAuditLogs: LoginAuditRecord[];
  activeSessions: ActiveSessionRecord[];
  rfqCounter: number;
  vendorProductMappings: any[];
  invoices: any[];
  vendorBills: any[];
  expenses: any[];
  challans: any[];
  companySettings: any;
  brands: any[];
  categories: any[];
  productTypes: any[];
  deletedVendorIds: string[];
}

// Initial Roles
export const INITIAL_ROLES: RoleDefinition[] = [
  {
    id: 'ROLE-ADMIN',
    name: 'Admin',
    description: 'Full administrative access across all modules, approvals, and user management',
    approvalLimit: 0, // unlimited
    defaultPermissions: {
      modules: {
        dashboard: true,
        requirements: true,
        rfqs: true,
        approvals: true,
        vendors: true,
        quotations: true,
        customerPos: true,
        vendorPos: true,
        payments: true,
        dispatch: true,
        reports: true,
        userManagement: true,
        auditTrail: true,
      },
      actions: { canView: true, canAdd: true, canEdit: true, canDelete: true, canApprove: true },
    },
  },
  {
    id: 'ROLE-PURCHASE-MGR',
    name: 'Purchase Manager',
    description: 'Manages sourcing, reviews RFQs, approves supplier purchase orders up to ₹10,00,000',
    approvalLimit: 1000000,
    defaultPermissions: {
      modules: {
        dashboard: true,
        requirements: true,
        rfqs: true,
        approvals: true,
        vendors: true,
        quotations: true,
        customerPos: true,
        vendorPos: true,
        payments: false,
        dispatch: true,
        reports: true,
        userManagement: false,
        auditTrail: true,
      },
      actions: { canView: true, canAdd: true, canEdit: true, canDelete: false, canApprove: true },
    },
  },
  {
    id: 'ROLE-PURCHASE-USER',
    name: 'Purchase User',
    description: 'Creates requirements, drafts vendor RFQs, compares quotes and tracks order delivery',
    approvalLimit: 0,
    defaultPermissions: {
      modules: {
        dashboard: true,
        requirements: true,
        rfqs: true,
        approvals: false,
        vendors: true,
        quotations: true,
        customerPos: false,
        vendorPos: false,
        payments: false,
        dispatch: false,
        reports: true,
        userManagement: false,
        auditTrail: false,
      },
      actions: { canView: true, canAdd: true, canEdit: true, canDelete: false, canApprove: false },
    },
  },
  {
    id: 'ROLE-APPROVAL-USER',
    name: 'Approval User',
    description: 'Senior reviewer authorized to approve high-value procurement requests and vendor quotes',
    approvalLimit: 5000000,
    defaultPermissions: {
      modules: {
        dashboard: true,
        requirements: true,
        rfqs: true,
        approvals: true,
        vendors: true,
        quotations: true,
        customerPos: true,
        vendorPos: true,
        payments: true,
        dispatch: false,
        reports: true,
        userManagement: false,
        auditTrail: true,
      },
      actions: { canView: true, canAdd: false, canEdit: false, canDelete: false, canApprove: true },
    },
  },
  {
    id: 'ROLE-ACCOUNTS-USER',
    name: 'Accounts User',
    description: 'Oversees financial settlements, vendor payments, GST invoices and proforma billing',
    approvalLimit: 500000,
    defaultPermissions: {
      modules: {
        dashboard: true,
        requirements: false,
        rfqs: false,
        approvals: true,
        vendors: true,
        quotations: true,
        customerPos: true,
        vendorPos: true,
        payments: true,
        dispatch: true,
        reports: true,
        userManagement: false,
        auditTrail: true,
      },
      actions: { canView: true, canAdd: true, canEdit: true, canDelete: false, canApprove: true },
    },
  },
  {
    id: 'ROLE-STORE-USER',
    name: 'Store User',
    description: 'Handles goods receiving, dispatch LR verification, and physical warehouse inventory',
    approvalLimit: 0,
    defaultPermissions: {
      modules: {
        dashboard: true,
        requirements: true,
        rfqs: false,
        approvals: false,
        vendors: true,
        quotations: false,
        customerPos: false,
        vendorPos: true,
        payments: false,
        dispatch: true,
        reports: false,
        userManagement: false,
        auditTrail: false,
      },
      actions: { canView: true, canAdd: true, canEdit: false, canDelete: false, canApprove: false },
    },
  },
  {
    id: 'ROLE-VIEWER',
    name: 'Management / Viewer',
    description: 'Executive read-only visibility into procurement KPIs, analytics and audit trails',
    approvalLimit: 0,
    defaultPermissions: {
      modules: {
        dashboard: true,
        requirements: true,
        rfqs: true,
        approvals: true,
        vendors: true,
        quotations: true,
        customerPos: true,
        vendorPos: true,
        payments: true,
        dispatch: true,
        reports: true,
        userManagement: false,
        auditTrail: true,
      },
      actions: { canView: true, canAdd: false, canEdit: false, canDelete: false, canApprove: false },
    },
  },
];

export const INITIAL_COMPANY_SETTINGS = {
  companyName: 'MRO PROCUREMENT SOLUTION',
  tagline: 'Industrial MRO Spares, Bearings, Electrical, Belts & Mechanical Solutions',
  gstin: '24AAECM8891Q1Z4',
  pan: 'AAECM8891Q',
  address: 'Plot 42, GIDC Industrial Estate, Phase 2, Vatva',
  city: 'Ahmedabad',
  state: 'Gujarat',
  stateCode: '24',
  pincode: '382445',
  phone: '+91 98250 12345',
  email: 'accounts@mroprocurement.com',
  website: 'www.mroprocurement.com',
  invoicePrefix: 'INV-2026-',
  financialYear: '2026-2027',
  bankAccounts: [
    {
      id: 'BANK-01',
      accountName: 'HDFC Current A/c - MRO Procurement',
      bankName: 'HDFC Bank Ltd',
      accountNumber: '50200088991122',
      ifscCode: 'HDFC0001234',
      branch: 'Vatva Industrial Branch, Ahmedabad',
      accountType: 'CURRENT',
      openingBalance: 250000,
      currentBalance: 425600,
      upiId: 'mroprocurement@hdfcbank',
      isDefault: true,
    },
    {
      id: 'BANK-02',
      accountName: 'ICICI Bank Operating A/c',
      bankName: 'ICICI Bank',
      accountNumber: '003405012345',
      ifscCode: 'ICIC0000034',
      branch: 'C.G. Road Branch, Ahmedabad',
      accountType: 'CURRENT',
      openingBalance: 100000,
      currentBalance: 185000,
      upiId: 'mroprocurement@icici',
      isDefault: false,
    },
  ],
};

export const INITIAL_INVOICES = [
  {
    id: 'INV-001',
    invoiceNumber: 'INV-2026-0001',
    invoiceDate: '2026-09-09',
    dueDate: '2026-10-09',
    quotationId: 'QTN-2026-00001',
    customerPoId: 'CPO-2026-00001',
    requirementId: 'REQ-2026-00001',
    customerId: 'CMP-001',
    customerName: 'hyfunfoods',
    customerGstin: '24AAACH1234F1Z5',
    customerAddress: 'hyfunfoods Processing Plant, GIDC Mehsana, Gujarat 384002',
    placeOfSupply: 'Gujarat (24)',
    items: [
      {
        id: 'INV-ITM-001',
        requirementItemId: 'ITEM-001-A',
        itemName: 'Tapered Roller Bearing 30205',
        partNumber: '30205-J2/Q',
        hsnCode: '84822010',
        quantity: 50,
        uom: 'NOS',
        unitPrice: 568.76,
        taxableAmount: 28438,
        gstRate: 18,
        igstAmount: 5118.84,
        cgstAmount: 0,
        sgstAmount: 0,
        totalAmount: 33556.84,
      },
      {
        id: 'INV-ITM-002',
        requirementItemId: 'ITEM-001-B',
        itemName: 'Spherical Roller Bearing 22216 EK',
        partNumber: '22216-EK-C3',
        hsnCode: '84823000',
        quantity: 10,
        uom: 'NOS',
        unitPrice: 5382,
        taxableAmount: 53820,
        gstRate: 18,
        igstAmount: 9687.6,
        cgstAmount: 0,
        sgstAmount: 0,
        totalAmount: 63507.6,
      },
    ],
    subtotal: 82258,
    cgstTotal: 0,
    sgstTotal: 0,
    igstTotal: 14806.44,
    totalTax: 14806.44,
    grandTotal: 97064.44,
    paidAmount: 97064.44,
    balanceDue: 0,
    status: 'PAID',
    eWayBillNumber: 'EWB-2490-8812-9901',
    createdAt: '2026-09-09',
  },
  {
    id: 'INV-002',
    invoiceNumber: 'INV-2026-0002',
    invoiceDate: '2026-09-20',
    dueDate: '2026-11-04',
    quotationId: 'QTN-2026-00002',
    customerPoId: 'CPO-2026-00002',
    requirementId: 'REQ-2026-00002',
    customerId: 'CUST-002',
    customerName: 'Larsen & Toubro Heavy Engineering',
    customerGstin: '24AAACL0140P1ZL',
    customerAddress: 'Hazira Manufacturing Complex, Surat, Gujarat 394510',
    placeOfSupply: 'Gujarat (24)',
    items: [
      {
        id: 'INV-ITM-003',
        requirementItemId: 'ITEM-002-A',
        itemName: 'Three Phase Induction Motor 15kW 4-Pole',
        partNumber: '1LE7501-1EB22-2AA4',
        hsnCode: '85015210',
        quantity: 2,
        uom: 'NOS',
        unitPrice: 73660,
        taxableAmount: 147320,
        gstRate: 18,
        cgstAmount: 13258.8,
        sgstAmount: 13258.8,
        igstAmount: 0,
        totalAmount: 173837.6,
      },
    ],
    subtotal: 147320,
    cgstTotal: 13258.8,
    sgstTotal: 13258.8,
    igstTotal: 0,
    totalTax: 26517.6,
    grandTotal: 173837.6,
    paidAmount: 173837.6,
    balanceDue: 0,
    status: 'PAID',
    eWayBillNumber: 'EWB-2490-9944-7712',
    createdAt: '2026-09-20',
  },
];

export const INITIAL_VENDOR_BILLS = [
  {
    id: 'BILL-001',
    billNumber: 'INV/APX/26-1189',
    billDate: '2026-09-07',
    dueDate: '2026-09-21',
    vendorId: 'VEND-001',
    vendorName: 'Apex Industrial Bearings & Spares Pvt Ltd',
    vendorGstin: '27AABCA4589H1ZN',
    vendorPoId: 'VPO-2026-00001',
    subtotal: 69500,
    cgstTotal: 0,
    sgstTotal: 0,
    igstTotal: 12510,
    totalTax: 12510,
    freight: 1400,
    grandTotal: 83410,
    paidAmount: 83410,
    balanceDue: 0,
    status: 'PAID',
    paymentReference: 'NEFT-HDFC-99382104921',
    createdAt: '2026-09-07',
  },
  {
    id: 'BILL-002',
    billNumber: 'INV/SPMC/26-891',
    billDate: '2026-09-15',
    dueDate: '2026-09-30',
    vendorId: 'VEND-002',
    vendorName: 'Siemens Precision Motion Controls',
    vendorGstin: '06AABCS9912K1Z5',
    vendorPoId: 'VPO-2026-00002',
    subtotal: 124000,
    cgstTotal: 0,
    sgstTotal: 0,
    igstTotal: 22320,
    totalTax: 22320,
    freight: 3000,
    grandTotal: 149320,
    paidAmount: 149320,
    balanceDue: 0,
    status: 'PAID',
    paymentReference: 'RTGS-UTIB-44910284759',
    createdAt: '2026-09-15',
  },
];

export const INITIAL_EXPENSES = [
  {
    id: 'EXP-001',
    expenseNumber: 'EXP-2026-001',
    date: '2026-09-10',
    category: 'Freight & Logistics',
    title: 'V-Trans Express Jamshedpur Delivery Freight',
    description: 'Special wooden crate logistics for 60 industrial bearings',
    amount: 3500,
    taxAmount: 630,
    totalAmount: 4130,
    paymentMode: 'BANK_TRANSFER',
    vendorName: 'V-Trans Express Cargo Ltd',
    receiptUrl: '#',
    status: 'PAID',
  },
  {
    id: 'EXP-002',
    expenseNumber: 'EXP-2026-002',
    date: '2026-09-16',
    category: 'Inspection & Testing',
    title: 'TUV India Third-Party Bearing Dynamic Load Inspection',
    description: 'Calibration and dynamic load certification for hyfunfoods order',
    amount: 4200,
    taxAmount: 756,
    totalAmount: 4956,
    paymentMode: 'BANK_TRANSFER',
    vendorName: 'TUV India Pvt Ltd',
    receiptUrl: '#',
    status: 'PAID',
  },
];

export const INITIAL_PRODUCT_TYPES = [
  { id: 'PT-001', name: 'MCB', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'PT-002', name: 'MCCB', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'PT-003', name: 'SPD', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'PT-004', name: 'ACB', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'PT-005', name: 'Contactor', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'PT-006', name: 'Overload Relay', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'PT-007', name: 'Bearings', category: 'Mechanical and Industrial', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'PT-008', name: 'Sensors', category: 'Electronics and Automation', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'PT-009', name: 'Valves', category: 'Plumbing, Pipes and Fittings', createdAt: '2026-01-01T00:00:00.000Z' },
  { id: 'PT-010', name: 'Industrial Lubricants', category: 'Paints, Chemicals and Lubricants', createdAt: '2026-01-01T00:00:00.000Z' },
];

// Helper to seed initial data
function createDefaultDatabase(): ErpDatabaseSchema {
  const adminSaltHash = hashPassword('Admin@123');
  const purchaseSaltHash = hashPassword('Purchase@123');
  const approverSaltHash = hashPassword('Approver@123');
  const accountsSaltHash = hashPassword('Accounts@123');

  const defaultUsers: UserRecord[] = [
    {
      id: 'USR-001',
      name: 'Vicky Bhavsar (Super Admin)',
      email: 'vickybhavsar960@gmail.com',
      username: 'admin',
      passwordHash: adminSaltHash.hash,
      passwordSalt: adminSaltHash.salt,
      role: 'Admin',
      department: 'Executive Management',
      mobile: '+91 98200 11223',
      status: 'ACTIVE',
      approvalAuthority: {
        canApproveRequirements: true,
        canApproveRfqs: true,
        canApprovePos: true,
        canApprovePayments: true,
        maxApprovalLimit: 0,
      },
      permissions: INITIAL_ROLES[0].defaultPermissions,
      createdAt: '2026-01-01 09:00:00',
    },
    {
      id: 'USR-002',
      name: 'Suresh Patil (Purchase Manager)',
      email: 'suresh.patil@procuremro.com',
      username: 'suresh_purchase',
      passwordHash: purchaseSaltHash.hash,
      passwordSalt: purchaseSaltHash.salt,
      role: 'Purchase Manager',
      department: 'Procurement & Sourcing',
      mobile: '+91 98221 44556',
      status: 'ACTIVE',
      approvalAuthority: {
        canApproveRequirements: true,
        canApproveRfqs: true,
        canApprovePos: true,
        canApprovePayments: false,
        maxApprovalLimit: 1000000,
      },
      permissions: INITIAL_ROLES[1].defaultPermissions,
      createdAt: '2026-01-10 10:30:00',
    },
    {
      id: 'USR-003',
      name: 'Anjali Deshmukh (Lead Approver)',
      email: 'anjali.d@procuremro.com',
      username: 'anjali_approver',
      passwordHash: approverSaltHash.hash,
      passwordSalt: approverSaltHash.salt,
      role: 'Approval User',
      department: 'Commercial Audit & Governance',
      mobile: '+91 98112 77889',
      status: 'ACTIVE',
      approvalAuthority: {
        canApproveRequirements: true,
        canApproveRfqs: true,
        canApprovePos: true,
        canApprovePayments: true,
        maxApprovalLimit: 5000000,
      },
      permissions: INITIAL_ROLES[3].defaultPermissions,
      createdAt: '2026-01-15 11:15:00',
    },
    {
      id: 'USR-004',
      name: 'Pooja Iyer (Accounts Lead)',
      email: 'pooja.i@procuremro.com',
      username: 'pooja_accounts',
      passwordHash: accountsSaltHash.hash,
      passwordSalt: accountsSaltHash.salt,
      role: 'Accounts User',
      department: 'Finance & Treasury',
      mobile: '+91 98334 66112',
      status: 'ACTIVE',
      approvalAuthority: {
        canApproveRequirements: false,
        canApproveRfqs: false,
        canApprovePos: false,
        canApprovePayments: true,
        maxApprovalLimit: 500000,
      },
      permissions: INITIAL_ROLES[4].defaultPermissions,
      createdAt: '2026-02-01 09:45:00',
    },
  ];

  const defaultApprovals: ApprovalRecord[] = [
    {
      id: 'APP-2026-0001',
      requestType: 'REQUIREMENT',
      requestNumber: 'REQ-2026-00001',
      requestDate: '2026-10-02',
      requestorId: 'USR-002',
      requestorName: 'Suresh Patil',
      department: 'Plant Maintenance #4',
      vendorOrCustomer: 'Tata Motors Pune Plant',
      amount: 45000,
      currency: 'INR',
      status: 'PENDING',
      approvalLevel: 'LEVEL_1',
      pendingSince: '2026-10-02 14:00',
      details: 'Indent for 50 Nos of SKF 6206 2RS Bearings for conveyor line overhaul.',
      history: [
        { action: 'CREATED', actor: 'Suresh Patil', timestamp: '2026-10-02 14:00', comments: 'Requirement submitted for technical review' },
      ],
    },
    {
      id: 'APP-2026-0002',
      requestType: 'RFQ',
      requestNumber: 'RFQ-2026-00002',
      requestDate: '2026-10-03',
      requestorId: 'USR-002',
      requestorName: 'Suresh Patil',
      department: 'Instrumentation',
      vendorOrCustomer: 'JSW Steel Ballari',
      amount: 114000,
      currency: 'INR',
      status: 'PENDING',
      approvalLevel: 'LEVEL_2',
      pendingSince: '2026-10-03 16:30',
      details: 'Vendor rate evaluation for Siemens S7-1200 CPU & Festo Solenoid Valves. Rate variance within 3.5%.',
      history: [
        { action: 'CREATED', actor: 'Suresh Patil', timestamp: '2026-10-03 16:30', comments: 'Multi-vendor rate comparison complete' },
      ],
    },
    {
      id: 'APP-2026-0003',
      requestType: 'VENDOR_PO',
      requestNumber: 'VPO-2026-00001',
      requestDate: '2026-09-28',
      requestorId: 'USR-002',
      requestorName: 'Suresh Patil',
      department: 'Mechanical Spares',
      vendorOrCustomer: 'Apex Industrial Bearings & Spares',
      amount: 38500,
      currency: 'INR',
      status: 'APPROVED',
      approvalLevel: 'FINAL',
      pendingSince: '2026-09-28 10:00',
      details: 'Binding Purchase Order for emergency bearing delivery with 50% advance terms.',
      approverId: 'USR-003',
      approverName: 'Anjali Deshmukh',
      actionDate: '2026-09-28 15:20',
      comments: 'Approved with commercial margin locked at 14.2%.',
      history: [
        { action: 'CREATED', actor: 'Suresh Patil', timestamp: '2026-09-28 10:00' },
        { action: 'APPROVED', actor: 'Anjali Deshmukh', timestamp: '2026-09-28 15:20', comments: 'Approved with commercial lock' },
      ],
    },
  ];

  const defaultAuditLogs: AuditLogEntry[] = [
    {
      id: 'AUD-001',
      timestamp: '2026-10-01 09:30:15',
      user: 'Vicky Bhavsar',
      role: 'Admin',
      action: 'SYSTEM_STARTUP',
      module: 'Core System',
      recordNumber: 'SYS-INIT',
      remarks: 'Production Database engine initialized with secure credentials & schema tables',
    },
    {
      id: 'AUD-002',
      timestamp: '2026-10-02 14:02:00',
      user: 'Suresh Patil',
      role: 'Purchase Manager',
      action: 'REQUIREMENT_CREATED',
      module: 'Requirement',
      recordNumber: 'REQ-2026-00001',
      newStatus: 'OPEN',
      remarks: 'Created requirement for Tata Motors bearing indent',
    },
  ];

  return {
    version: 2,
    lastUpdated: new Date().toISOString(),
    users: defaultUsers,
    roles: INITIAL_ROLES,
    approvals: defaultApprovals,
    auditLogs: defaultAuditLogs,
    requirements: [],
    deletedRequirementIds: ['RFQ-2026-00005', 'RFQ-2026-00006', 'REQ-2026-00005', 'REQ-2026-00006'],
    companies: [],
    purchaseExecutives: [],
    customers: [],
    vendors: [],
    products: [],
    quotations: [],
    customerPos: [],
    vendorPos: [],
    proformaInvoices: [],
    payments: [],
    dispatches: [],
    deliveries: [],
    rfqs: [],
    vendorQuotes: [],
    notifications: [],
    loginAuditLogs: [],
    activeSessions: [],
    rfqCounter: 100,
    vendorProductMappings: [],
    brands: [],
    categories: [],
    productTypes: [...INITIAL_PRODUCT_TYPES],
    invoices: INITIAL_INVOICES,
    vendorBills: INITIAL_VENDOR_BILLS,
    expenses: INITIAL_EXPENSES,
    challans: [],
    companySettings: INITIAL_COMPANY_SETTINGS,
    deletedVendorIds: [],
  };
}

// Memory cache with disk synchronization
class PersistentDatabase {
  private data: ErpDatabaseSchema;
  private isSaving: boolean = false;

  constructor() {
    this.data = this.loadFromDisk();
  }

  private loadFromDisk(): ErpDatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        if (!Array.isArray(parsed.vendorQuotes)) parsed.vendorQuotes = [];
        if (!Array.isArray(parsed.requirements)) parsed.requirements = [];
        if (!Array.isArray(parsed.rfqs)) parsed.rfqs = [];
        if (!Array.isArray(parsed.vendors)) parsed.vendors = [];
        if (!Array.isArray(parsed.vendorPos)) parsed.vendorPos = [];
        if (!Array.isArray(parsed.notifications)) parsed.notifications = [];
        if (!Array.isArray(parsed.users)) parsed.users = [];
        if (!Array.isArray(parsed.companies)) parsed.companies = [];
        if (!Array.isArray(parsed.purchaseExecutives)) parsed.purchaseExecutives = [];
        if (!Array.isArray(parsed.customers)) parsed.customers = [];
        if (!Array.isArray(parsed.products)) parsed.products = [];
        if (!Array.isArray(parsed.quotations)) parsed.quotations = [];
        if (!Array.isArray(parsed.customerPos)) parsed.customerPos = [];
        if (!Array.isArray(parsed.proformaInvoices)) parsed.proformaInvoices = [];
        if (!Array.isArray(parsed.payments)) parsed.payments = [];
        if (!Array.isArray(parsed.dispatches)) parsed.dispatches = [];
        if (!Array.isArray(parsed.deliveries)) parsed.deliveries = [];
        if (!Array.isArray(parsed.loginAuditLogs)) parsed.loginAuditLogs = [];
        if (!Array.isArray(parsed.activeSessions)) parsed.activeSessions = [];
        let needsDiskSave = false;
        if (!Array.isArray(parsed.invoices) || parsed.invoices.length === 0) {
          parsed.invoices = INITIAL_INVOICES;
          needsDiskSave = true;
        }
        if (!Array.isArray(parsed.vendorBills) || parsed.vendorBills.length === 0) {
          parsed.vendorBills = INITIAL_VENDOR_BILLS;
          needsDiskSave = true;
        }
        if (!Array.isArray(parsed.expenses) || parsed.expenses.length === 0) {
          parsed.expenses = INITIAL_EXPENSES;
          needsDiskSave = true;
        }
        if (!Array.isArray(parsed.challans)) {
          parsed.challans = [];
          needsDiskSave = true;
        }
        if (!parsed.companySettings) {
          parsed.companySettings = INITIAL_COMPANY_SETTINGS;
          needsDiskSave = true;
        }
        if (!Array.isArray(parsed.brands) || parsed.brands.length === 0) {
          parsed.brands = INITIAL_BRANDS.map((b) => ({ ...b }));
          needsDiskSave = true;
        }
        if (!Array.isArray(parsed.categories) || parsed.categories.length === 0) {
          parsed.categories = INITIAL_MATERIAL_CATEGORIES.map((c) => ({ ...c }));
          needsDiskSave = true;
        }
        if (!Array.isArray(parsed.productTypes) || parsed.productTypes.length === 0) {
          parsed.productTypes = INITIAL_PRODUCT_TYPES.map((pt) => ({ ...pt }));
          needsDiskSave = true;
        }
        if (typeof parsed.rfqCounter !== 'number') parsed.rfqCounter = 100;

        if (!Array.isArray(parsed.deletedRequirementIds)) {
          parsed.deletedRequirementIds = ['RFQ-2026-00005', 'RFQ-2026-00006', 'REQ-2026-00005', 'REQ-2026-00006'];
        } else {
          // Ensure RFQ 5 and 6 are strictly included in tombstones
          for (const tomb of ['RFQ-2026-00005', 'RFQ-2026-00006', 'REQ-2026-00005', 'REQ-2026-00006']) {
            if (!parsed.deletedRequirementIds.includes(tomb)) {
              parsed.deletedRequirementIds.push(tomb);
            }
          }
        }

        if (!Array.isArray(parsed.deletedVendorIds)) {
          parsed.deletedVendorIds = [];
        } else if (Array.isArray(parsed.vendors)) {
          parsed.vendors = parsed.vendors.filter((v: any) => !parsed.deletedVendorIds.includes(v.id));
        }

        // Ensure vendorProductMappings is populated with comprehensive multi-brand / multi-category records
        if (!parsed.vendorProductMappings || parsed.vendorProductMappings.length === 0) {
          parsed.vendorProductMappings = [
            {
              id: 'VPM-001',
              vendorId: 'VEND-001',
              vendorCode: 'VEND-001',
              vendorName: 'Apex Industrial Bearings & Spares Pvt Ltd',
              productName: 'Deep Groove Ball Bearing 6206-2RS',
              category: 'Mechanical and Industrial',
              subCategory: 'Bearings',
              productType: 'Deep Groove Ball Bearings',
              brand: 'SKF',
              modelNumber: '6206-2RS1/C3',
              partNumber: '6206-2RS1/C3',
              specification: '30x62x16mm, Rubber Sealed, C3 Clearance',
              size: '30x62x16mm',
              rating: 'Dynamic Load 20.3 kN',
              description: 'Standard deep groove ball bearing with synthetic rubber contact seals',
              uom: 'NOS',
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Primary authorized line',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
            {
              id: 'VPM-002',
              vendorId: 'VEND-001',
              vendorCode: 'VEND-001',
              vendorName: 'Apex Industrial Bearings & Spares Pvt Ltd',
              productName: 'Spherical Roller Bearing 22216-EK',
              category: 'Mechanical and Industrial',
              subCategory: 'Bearings',
              productType: 'Spherical Roller Bearings',
              brand: 'SKF',
              modelNumber: '22216-EK-C3',
              partNumber: '22216-EK-C3',
              specification: '80x140x33mm, Tapered 1:12 Bore, W33 Lube Groove',
              size: '80x140x33mm',
              rating: 'Heavy Radial / Axial Load',
              description: 'Self-aligning spherical roller bearing for vibratory screens and gearboxes',
              uom: 'NOS',
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'In stock at central warehouse',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
            {
              id: 'VPM-003',
              vendorId: 'VEND-001',
              vendorCode: 'VEND-001',
              vendorName: 'Apex Industrial Bearings & Spares Pvt Ltd',
              productName: 'Tapered Roller Bearing 30205',
              category: 'Mechanical and Industrial',
              subCategory: 'Bearings',
              productType: 'Tapered Roller Bearings',
              brand: 'Timken',
              modelNumber: '30205-J2/Q',
              partNumber: '30205-J2/Q',
              specification: '25x52x16.25mm, High Precision Cones',
              size: '25x52x16.25mm',
              rating: 'High Thrust Load',
              description: 'Metric single row tapered roller bearing',
              uom: 'NOS',
              supplyType: 'Dealer',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Timken genuine imported line',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
            {
              id: 'VPM-004',
              vendorId: 'VEND-002',
              vendorCode: 'VEND-002',
              vendorName: 'Siemens Precision Motion Controls',
              productName: 'Miniature Circuit Breaker (MCB) 32A 4-Pole',
              category: 'Electrical',
              subCategory: 'MCB',
              productType: 'MCB',
              brand: 'Schneider Electric',
              modelNumber: 'A9F74432',
              partNumber: 'A9F74432',
              specification: '4-Pole, 32A, C-Curve, 10kA Breaking Capacity',
              size: '4 Module Width',
              rating: '415V AC 50Hz',
              description: 'Acti9 iC60N industrial miniature circuit breaker',
              uom: 'NOS',
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Schneider Tier-1 direct supply',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
            {
              id: 'VPM-005',
              vendorId: 'VEND-002',
              vendorCode: 'VEND-002',
              vendorName: 'Siemens Precision Motion Controls',
              productName: 'Power Contactor 25A 3-Pole',
              category: 'Electrical',
              subCategory: 'Contactors',
              productType: 'Contactors',
              brand: 'Schneider Electric',
              modelNumber: 'LC1D25M7',
              partNumber: 'LC1D25M7',
              specification: '25A AC-3, 11kW, 220V AC 50/60Hz Coil, 1NO+1NC',
              size: 'Frame 2',
              rating: '690V Rated Insulation',
              description: 'TeSys Deca industrial motor starter contactor',
              uom: 'NOS',
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Ready stock 100+ units',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
            {
              id: 'VPM-006',
              vendorId: 'VEND-002',
              vendorCode: 'VEND-002',
              vendorName: 'Siemens Precision Motion Controls',
              productName: 'SIMATIC S7-1200 CPU 1214C Compact PLC',
              category: 'Electronics and Automation',
              subCategory: 'PLC',
              productType: 'PLC',
              brand: 'Siemens',
              modelNumber: '6ES7214-1AG40-0XB0',
              partNumber: '6ES7214-1AG40-0XB0',
              specification: 'DC/DC/DC, 14 Digital In, 10 Digital Out, 2 Analog In',
              size: 'Compact DIN Rail',
              rating: '24V DC Power Supply',
              description: 'Programmable Logic Controller for manufacturing line automation',
              uom: 'NOS',
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Includes factory warranty',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
            {
              id: 'VPM-007',
              vendorId: 'VEND-006',
              vendorCode: 'VEND-006',
              vendorName: 'Festo & SMC Fluid Automation Hub',
              productName: 'Compact Pneumatic Cylinder 32mm Bore 50mm Stroke',
              category: 'Mechanical and Industrial',
              subCategory: 'Pneumatic Components',
              productType: 'Pneumatic Cylinders',
              brand: 'Festo',
              modelNumber: 'ADN-32-50-I-P-A',
              partNumber: 'ADN-32-50-I-P-A',
              specification: 'ISO 21287, Double Acting, Magnetic Piston, Elastic Cushioning',
              size: 'Bore 32mm, Stroke 50mm',
              rating: 'Working Pressure 1 to 10 Bar',
              description: 'High-speed compact automation cylinder',
              uom: 'NOS',
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Festo authorized center',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
            {
              id: 'VPM-008',
              vendorId: 'VEND-006',
              vendorCode: 'VEND-006',
              vendorName: 'Festo & SMC Fluid Automation Hub',
              productName: 'Directional Solenoid Valve 5/2 Way 24V DC',
              category: 'Mechanical and Industrial',
              subCategory: 'Valves',
              productType: 'Solenoid Valves',
              brand: 'Festo',
              modelNumber: 'VUVS-L25-M52-MD-G14-F8',
              partNumber: 'VUVS-L25-M52-MD-G14-F8',
              specification: 'G1/4 Port, 5/2 Single Solenoid with Spring Return, 24V DC',
              size: 'G1/4 Inch',
              rating: 'Flow Rate 1300 l/min',
              description: 'Rugged pneumatic solenoid valve with manual override',
              uom: 'NOS',
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Direct replacement for plant pneumatic lines',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
            {
              id: 'VPM-009',
              vendorId: 'VEND-006',
              vendorCode: 'VEND-006',
              vendorName: 'Festo & SMC Fluid Automation Hub',
              productName: 'Inductive Proximity Sensor M12 PNP NO',
              category: 'Electronics and Automation',
              subCategory: 'Sensors',
              productType: 'Proximity Sensors',
              brand: 'Omron',
              modelNumber: 'E2B-M12KS04-WP-B1',
              partNumber: 'E2B-M12KS04-WP-B1',
              specification: 'M12 Threaded, Sensing Distance 4mm, 10-30V DC, 2m Cable',
              size: 'M12x50mm',
              rating: 'IP67 Waterproof & Oil Resistant',
              description: 'Solid brass body inductive proximity switch',
              uom: 'NOS',
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Standard factory sensor',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
            {
              id: 'VPM-010',
              vendorId: 'VEND-003',
              vendorCode: 'VEND-003',
              vendorName: 'Kirloskar Fluidics & Pump Tech',
              productName: 'Flanged Cast Iron Ball Valve 2 Inch (DN50)',
              category: 'Plumbing, Pipes and Fittings',
              subCategory: 'Valves',
              productType: 'Ball Valves',
              brand: 'Audco',
              modelNumber: 'AUD-BV-50-CI',
              partNumber: 'AUD-BV-50-CI',
              specification: 'Class 150 Flanged, SS Ball, PTFE Seats, Lever Operated',
              size: 'DN50 / 2 Inch',
              rating: 'Pressure Rating PN16 / Class 150',
              description: 'Industrial isolation ball valve for water and cooling utilities',
              uom: 'NOS',
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Includes hydro test certificate',
              createdAt: '2026-01-15T10:00:00Z',
              updatedAt: '2026-01-15T10:00:00Z',
            },
          ];

          // Link productsSupplied array onto vendors
          parsed.vendors.forEach((v: any) => {
            v.productsSupplied = parsed.vendorProductMappings.filter((m: any) => m.vendorId === v.id);
          });
        }

        if (needsDiskSave) {
          console.log('[DB] Seeding missing financial and settings records to production disk store...');
          this.saveToDiskSync(parsed);
        }

        console.log(`[DB] Production Database loaded from ${DB_FILE} (Version ${parsed.version || 2})`);
        return parsed;
      }
    } catch (err) {
      console.error('[DB] Error reading database file, creating fresh default:', err);
    }

    const initial = createDefaultDatabase();
    this.saveToDiskSync(initial);
    return initial;
  }

  private saveToDiskSync(dataToSave: ErpDatabaseSchema) {
    try {
      dataToSave.lastUpdated = new Date().toISOString();
      // Atomic write: write to temp file then rename
      const tempFile = `${DB_FILE}.tmp.${Date.now()}`;
      fs.writeFileSync(tempFile, JSON.stringify(dataToSave, null, 2), 'utf-8');
      fs.renameSync(tempFile, DB_FILE);
      console.log(`[DB] Database committed successfully to ${DB_FILE}`);
    } catch (err) {
      console.error('[DB] Critical: Failed to save database to disk:', err);
      throw new Error('Database persistence failed');
    }
  }

  public save() {
    this.saveToDiskSync(this.data);
  }

  // Diagnostics & Status
  public getStatus() {
    return {
      status: 'CONNECTED',
      databaseEngine: 'Persistent Enterprise JSON/ACID File Store with Write-Ahead Lock',
      storagePath: DB_FILE,
      sizeBytes: fs.existsSync(DB_FILE) ? fs.statSync(DB_FILE).size : 0,
      lastUpdated: this.data.lastUpdated,
      counts: {
        users: this.data.users.length,
        roles: this.data.roles.length,
        approvals: this.data.approvals.length,
        auditLogs: this.data.auditLogs.length,
        requirements: this.data.requirements.length,
        rfqs: this.data.rfqs.length,
        vendors: this.data.vendors.length,
      },
    };
  }

  // Users
  public getUsers(): UserRecord[] {
    return this.data.users.map((u) => {
      // Exclude salt & hash from public list
      const { passwordHash, passwordSalt, ...safe } = u;
      return safe as UserRecord;
    });
  }

  public getUserById(id: string): UserRecord | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  public getUserByUsernameOrEmail(identifier: string): UserRecord | undefined {
    const clean = identifier.toLowerCase().trim();
    return this.data.users.find(
      (u) => u.username.toLowerCase() === clean || u.email.toLowerCase() === clean
    );
  }

  public createUser(userData: {
    name: string;
    email: string;
    username: string;
    password: string;
    role: string;
    department: string;
    mobile?: string;
    approvalAuthority?: Partial<UserRecord['approvalAuthority']>;
    permissions?: Partial<UserRecord['permissions']>;
  }): UserRecord {
    // Check duplicates
    if (this.getUserByUsernameOrEmail(userData.username)) {
      throw new Error(`Username "${userData.username}" is already taken.`);
    }
    if (this.getUserByUsernameOrEmail(userData.email)) {
      throw new Error(`Email "${userData.email}" is already registered.`);
    }

    const { hash, salt } = hashPassword(userData.password || 'Welcome@123');
    const matchedRole = this.data.roles.find((r) => r.name === userData.role) || this.data.roles[2];

    const newUser: UserRecord = {
      id: `USR-${Date.now().toString().slice(-4)}`,
      name: userData.name,
      email: userData.email,
      username: userData.username,
      passwordHash: hash,
      passwordSalt: salt,
      role: userData.role,
      department: userData.department || 'General',
      mobile: userData.mobile || '+91 90000 00000',
      status: 'ACTIVE',
      approvalAuthority: {
        canApproveRequirements: userData.approvalAuthority?.canApproveRequirements ?? (matchedRole.approvalLimit > 0),
        canApproveRfqs: userData.approvalAuthority?.canApproveRfqs ?? (matchedRole.approvalLimit > 0),
        canApprovePos: userData.approvalAuthority?.canApprovePos ?? (matchedRole.approvalLimit > 0),
        canApprovePayments: userData.approvalAuthority?.canApprovePayments ?? false,
        maxApprovalLimit: userData.approvalAuthority?.maxApprovalLimit ?? matchedRole.approvalLimit,
      },
      permissions: {
        modules: {
          ...matchedRole.defaultPermissions.modules,
          ...(userData.permissions?.modules || {}),
        },
        actions: {
          ...matchedRole.defaultPermissions.actions,
          ...(userData.permissions?.actions || {}),
        },
      },
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 19),
    };

    this.data.users.push(newUser);
    this.save();
    return newUser;
  }

  public updateUser(id: string, updates: Partial<UserRecord> & { newPassword?: string }): UserRecord {
    const idx = this.data.users.findIndex((u) => u.id === id);
    if (idx === -1) throw new Error('User not found');

    const current = this.data.users[idx];

    if (updates.newPassword) {
      const { hash, salt } = hashPassword(updates.newPassword);
      current.passwordHash = hash;
      current.passwordSalt = salt;
    }

    if (updates.name) current.name = updates.name;
    if (updates.email) current.email = updates.email;
    if (updates.department) current.department = updates.department;
    if (updates.mobile) current.mobile = updates.mobile;
    if (updates.role) current.role = updates.role;
    if (updates.status) current.status = updates.status;
    if (updates.approvalAuthority) {
      current.approvalAuthority = { ...current.approvalAuthority, ...updates.approvalAuthority };
    }
    if (updates.permissions) {
      current.permissions = {
        modules: { ...current.permissions.modules, ...updates.permissions.modules },
        actions: { ...current.permissions.actions, ...updates.permissions.actions },
      };
    }

    this.data.users[idx] = current;
    this.save();
    return current;
  }

  public deleteUser(id: string) {
    const idx = this.data.users.findIndex((u) => u.id === id);
    if (idx === -1) throw new Error('User not found');
    if (this.data.users[idx].username === 'admin') {
      throw new Error('Cannot delete primary Super Admin user');
    }
    this.data.users.splice(idx, 1);
    this.save();
  }

  // Roles
  public getRoles(): RoleDefinition[] {
    return this.data.roles;
  }

  public updateRole(id: string, updates: Partial<RoleDefinition>): RoleDefinition {
    const idx = this.data.roles.findIndex((r) => r.id === id);
    if (idx === -1) throw new Error('Role not found');
    this.data.roles[idx] = { ...this.data.roles[idx], ...updates };
    this.save();
    return this.data.roles[idx];
  }

  // Approvals
  public getApprovals(filter?: { status?: string; userRole?: string }): ApprovalRecord[] {
    let list = this.data.approvals;
    if (filter?.status && filter.status !== 'ALL') {
      list = list.filter((a) => a.status === filter.status);
    }
    return list;
  }

  public createApproval(approvalData: Omit<ApprovalRecord, 'id' | 'pendingSince' | 'history'>): ApprovalRecord {
    const newApproval: ApprovalRecord = {
      ...approvalData,
      id: `APP-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`,
      pendingSince: new Date().toISOString().replace('T', ' ').slice(0, 16),
      history: [
        {
          action: 'CREATED',
          actor: approvalData.requestorName,
          timestamp: new Date().toISOString().replace('T', ' ').slice(0, 16),
          comments: approvalData.details,
        },
      ],
    };

    this.data.approvals.unshift(newApproval);
    this.save();
    return newApproval;
  }

  public processApproval(params: {
    id: string;
    action: 'APPROVE' | 'REJECT' | 'SEND_BACK';
    approverId: string;
    approverName: string;
    comments?: string;
  }): ApprovalRecord {
    const item = this.data.approvals.find((a) => a.id === params.id);
    if (!item) throw new Error('Approval request not found');

    const newStatus: ApprovalRecord['status'] =
      params.action === 'APPROVE' ? 'APPROVED' : params.action === 'REJECT' ? 'REJECTED' : 'SENT_BACK';

    item.status = newStatus;
    item.approverId = params.approverId;
    item.approverName = params.approverName;
    item.actionDate = new Date().toISOString().replace('T', ' ').slice(0, 16);
    item.comments = params.comments;

    item.history.push({
      action: params.action,
      actor: params.approverName,
      timestamp: item.actionDate,
      comments: params.comments,
    });

    this.save();
    return item;
  }

  // RFQ Closure
  public closeRfq(details: RfqClosureDetails): any {
    const rfqIndex = this.data.rfqs.findIndex(
      (r) => r.id === details.rfqNumber || r.rfqNumber === details.rfqNumber
    );

    const updatedRfq = rfqIndex !== -1 ? { ...this.data.rfqs[rfqIndex] } : { id: details.rfqNumber };

    updatedRfq.status = 'Closed – Customer Confirmation';
    updatedRfq.closureDetails = details;
    updatedRfq.closedAt = details.closedAt;
    updatedRfq.closedBy = details.closedBy;

    if (rfqIndex !== -1) {
      this.data.rfqs[rfqIndex] = updatedRfq;
    } else {
      this.data.rfqs.push(updatedRfq);
    }

    // Also close any pending approvals associated with this RFQ
    this.data.approvals.forEach((app) => {
      if (app.requestNumber === details.rfqNumber && app.status === 'PENDING') {
        app.status = 'REJECTED';
        app.comments = `Auto-cancelled: RFQ closed by customer confirmation (${details.closureReason})`;
        app.history.push({
          action: 'AUTO_CANCELLED',
          actor: details.closedBy,
          timestamp: details.closedAt,
          comments: details.remarks,
        });
      }
    });

    this.save();
    return updatedRfq;
  }

  // Generic Entity Getters & Setters
  public getCollection(collectionName: keyof ErpDatabaseSchema): any[] {
    return (this.data[collectionName] as any[]) || [];
  }

  public setCollection(collectionName: keyof ErpDatabaseSchema, items: any[]) {
    (this.data[collectionName] as any) = items;
    this.save();
  }

  public appendToCollection(collectionName: keyof ErpDatabaseSchema, item: any) {
    if (!this.data[collectionName]) {
      (this.data[collectionName] as any) = [];
    }
    (this.data[collectionName] as any[]).unshift(item);
    this.save();
  }

  // Vendor Product Mappings Management
  public getVendorProductMappings(vendorId?: string): any[] {
    if (!Array.isArray(this.data.vendorProductMappings)) {
      this.data.vendorProductMappings = [];
    }
    if (vendorId) {
      return this.data.vendorProductMappings.filter((m) => m.vendorId === vendorId);
    }
    return this.data.vendorProductMappings;
  }

  public addVendorProductMapping(mapping: any): any {
    if (!Array.isArray(this.data.vendorProductMappings)) {
      this.data.vendorProductMappings = [];
    }
    // Duplicate check: same vendorId, brand, and (partNumber or productName)
    const normBrand = (mapping.brand || '').toLowerCase().trim();
    const normPart = (mapping.partNumber || '').toLowerCase().trim();
    const normName = (mapping.productName || '').toLowerCase().trim();
    const isDup = this.data.vendorProductMappings.some(
      (m) =>
        m.vendorId === mapping.vendorId &&
        (m.brand || '').toLowerCase().trim() === normBrand &&
        ((normPart && (m.partNumber || '').toLowerCase().trim() === normPart) ||
          (!normPart && (m.productName || '').toLowerCase().trim() === normName))
    );
    if (isDup) {
      throw new Error(`Duplicate mapping: This vendor already has "${mapping.productName}" (${mapping.brand} ${mapping.partNumber || ''}) mapped.`);
    }

    const newMapping = {
      ...mapping,
      id: mapping.id || `VPM-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
      createdAt: mapping.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      status: mapping.status || 'ACTIVE',
    };
    this.data.vendorProductMappings.push(newMapping);

    // Also update vendor's productsSupplied array if vendor exists
    const vIdx = this.data.vendors.findIndex((v) => v.id === mapping.vendorId);
    if (vIdx !== -1) {
      const v = this.data.vendors[vIdx];
      if (!Array.isArray(v.productsSupplied)) v.productsSupplied = [];
      v.productsSupplied.push(newMapping);
      if (mapping.category && (!v.materialCategories || !v.materialCategories.includes(mapping.category))) {
        v.materialCategories = [...(v.materialCategories || []), mapping.category];
      }
      if (mapping.brand && (!v.brandsSupplied || !v.brandsSupplied.includes(mapping.brand))) {
        v.brandsSupplied = [...(v.brandsSupplied || []), mapping.brand];
      }
      this.data.vendors[vIdx] = v;
    }

    this.save();
    return newMapping;
  }

  public updateVendorProductMapping(id: string, updates: any): any {
    if (!Array.isArray(this.data.vendorProductMappings)) this.data.vendorProductMappings = [];
    const idx = this.data.vendorProductMappings.findIndex((m) => m.id === id);
    if (idx === -1) throw new Error('Product mapping not found');

    const updated = {
      ...this.data.vendorProductMappings[idx],
      ...updates,
      updatedAt: new Date().toISOString(),
    };
    this.data.vendorProductMappings[idx] = updated;

    const vIdx = this.data.vendors.findIndex((v) => v.id === updated.vendorId);
    if (vIdx !== -1 && Array.isArray(this.data.vendors[vIdx].productsSupplied)) {
      const pIdx = this.data.vendors[vIdx].productsSupplied.findIndex((p: any) => p.id === id);
      if (pIdx !== -1) {
        this.data.vendors[vIdx].productsSupplied[pIdx] = updated;
      }
    }

    this.save();
    return updated;
  }

  public deleteVendorProductMapping(id: string): boolean {
    if (!Array.isArray(this.data.vendorProductMappings)) return false;
    const idx = this.data.vendorProductMappings.findIndex((m) => m.id === id);
    if (idx === -1) return false;
    const mapping = this.data.vendorProductMappings[idx];
    const vendorId = mapping.vendorId;

    // Remove from vendorProductMappings
    this.data.vendorProductMappings.splice(idx, 1);

    // Also remove from vendor.productsSupplied
    const vIdx = this.data.vendors.findIndex((v) => v.id === vendorId);
    if (vIdx !== -1 && Array.isArray(this.data.vendors[vIdx].productsSupplied)) {
      this.data.vendors[vIdx].productsSupplied = this.data.vendors[vIdx].productsSupplied.filter(
        (p: any) => p.id !== id
      );
    }

    // Never delete the global product type or brand!
    this.save();
    return true;
  }

  // Global Product Type Master Methods
  public getProductTypes(): any[] {
    if (!Array.isArray(this.data.productTypes) || this.data.productTypes.length === 0) {
      this.data.productTypes = INITIAL_PRODUCT_TYPES.map((pt) => ({ ...pt }));
      this.save();
    }
    return this.data.productTypes;
  }

  public findOrCreateProductType(name: string, category?: string): { productType: any; isNew: boolean } {
    if (!Array.isArray(this.data.productTypes)) {
      this.data.productTypes = INITIAL_PRODUCT_TYPES.map((pt) => ({ ...pt }));
    }
    const cleanName = (name || '').trim();
    if (!cleanName) throw new Error('Product type name cannot be empty');

    const norm = cleanName.toLowerCase();
    const existing = this.data.productTypes.find(
      (pt: any) => pt.name && pt.name.toLowerCase().trim() === norm
    );

    if (existing) {
      if (category && !existing.category) {
        existing.category = category;
        existing.updatedAt = new Date().toISOString();
        this.save();
      }
      return { productType: existing, isNew: false };
    }

    const newPT = {
      id: `PT-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 1000)}`,
      name: cleanName,
      category: category || 'General',
      isActive: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.data.productTypes.push(newPT);
    this.save();
    return { productType: newPT, isNew: true };
  }

  public addProductTypeToVendor(
    vendorId: string,
    productTypeName: string,
    category?: string,
    brand?: string
  ): { productType: any; mapping: any; vendor: any; isNewProductType: boolean } {
    const cleanName = (productTypeName || '').trim();
    if (!cleanName) throw new Error('Product type name cannot be empty');

    const cleanBrand = (brand || '').trim();
    const cleanCategory = (category || '').trim();

    // 1. Create or reuse in global Product Type Master
    const { productType, isNew: isNewProductType } = this.findOrCreateProductType(cleanName, cleanCategory);

    // 2. Locate vendor
    const vIdx = this.data.vendors.findIndex((v) => v.id === vendorId);
    if (vIdx === -1) throw new Error(`Vendor ${vendorId} not found`);
    const vendor = this.data.vendors[vIdx];

    // 3. Check for existing mapping for this vendor
    if (!Array.isArray(this.data.vendorProductMappings)) {
      this.data.vendorProductMappings = [];
    }

    const normName = cleanName.toLowerCase();
    const normBrand = cleanBrand.toLowerCase();

    const existingMapping = this.data.vendorProductMappings.find(
      (m: any) =>
        m.vendorId === vendorId &&
        m.status !== 'INACTIVE' &&
        (m.productName || m.productType || '').toLowerCase().trim() === normName &&
        ((!cleanBrand && (!m.brand || m.brand === 'Generic')) ||
          (cleanBrand && (m.brand || '').toLowerCase().trim() === normBrand))
    );

    if (existingMapping) {
      throw new Error(`"${cleanName}" is already added to ${vendor.companyName}${cleanBrand ? ` under brand "${cleanBrand}"` : ''}.`);
    }

    // 4. Create new mapping
    const newMapping = {
      id: `VPM-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      vendorId,
      vendorCode: vendor.vendorCode || vendor.id,
      vendorName: vendor.companyName,
      productName: cleanName,
      productType: cleanName,
      category: cleanCategory || productType.category || 'General',
      brand: cleanBrand || 'Generic',
      uom: 'NOS',
      supplyType: 'Authorized Distributor',
      availability: 'Regular Stock',
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.data.vendorProductMappings.unshift(newMapping);

    // 5. Update vendor's productsSupplied and brand/category tags
    if (!Array.isArray(vendor.productsSupplied)) vendor.productsSupplied = [];
    vendor.productsSupplied.unshift(newMapping);

    if (cleanBrand) {
      const existingBrands = vendor.brandsSupplied || [];
      if (!existingBrands.some((b: string) => b.toLowerCase().trim() === normBrand)) {
        vendor.brandsSupplied = [...existingBrands, cleanBrand];
      }
      if (Array.isArray(this.data.brands)) {
        const hasBrand = this.data.brands.some((b: any) => b.name?.toLowerCase().trim() === normBrand);
        if (!hasBrand) {
          this.data.brands.push({
            id: `BRD-${Date.now().toString().slice(-6)}`,
            name: cleanBrand,
            category: cleanCategory || 'General',
            isActive: true,
            createdAt: new Date().toISOString(),
          });
        }
      }
    }

    if (cleanCategory) {
      const existingCats = vendor.materialCategories || [];
      if (!existingCats.some((c: string) => c.toLowerCase().trim() === cleanCategory.toLowerCase())) {
        vendor.materialCategories = [...existingCats, cleanCategory];
      }
    }

    this.data.vendors[vIdx] = vendor;
    this.save();

    return { productType, mapping: newMapping, vendor, isNewProductType };
  }

  public removeProductTypeFromVendor(mappingId: string): boolean {
    return this.deleteVendorProductMapping(mappingId);
  }

  public bulkUpsertVendorProductMappings(vendorId: string, mappings: any[]): { added: number; updated: number; skippedDuplicates: number } {
    if (!Array.isArray(this.data.vendorProductMappings)) this.data.vendorProductMappings = [];
    let added = 0;
    let updated = 0;
    let skippedDuplicates = 0;

    for (const m of mappings) {
      const normBrand = (m.brand || '').toLowerCase().trim();
      const normPart = (m.partNumber || '').toLowerCase().trim();
      const normName = (m.productName || '').toLowerCase().trim();

      const existingIdx = this.data.vendorProductMappings.findIndex(
        (ex) =>
          ex.vendorId === vendorId &&
          (ex.brand || '').toLowerCase().trim() === normBrand &&
          ((normPart && (ex.partNumber || '').toLowerCase().trim() === normPart) ||
            (!normPart && (ex.productName || '').toLowerCase().trim() === normName))
      );

      if (existingIdx !== -1) {
        this.data.vendorProductMappings[existingIdx] = {
          ...this.data.vendorProductMappings[existingIdx],
          ...m,
          vendorId,
          updatedAt: new Date().toISOString(),
        };
        updated++;
      } else {
        const newM = {
          ...m,
          id: m.id || `VPM-${Date.now()}-${Math.random().toString(36).substring(2, 6).toUpperCase()}`,
          vendorId,
          status: m.status || 'ACTIVE',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        };
        this.data.vendorProductMappings.push(newM);
        added++;
      }
    }

    const vIdx = this.data.vendors.findIndex((v) => v.id === vendorId);
    if (vIdx !== -1) {
      const v = this.data.vendors[vIdx];
      v.productsSupplied = this.data.vendorProductMappings.filter((m) => m.vendorId === vendorId);
      const cats = Array.from(new Set([...(v.materialCategories || []), ...mappings.map((m) => m.category).filter(Boolean)]));
      const brands = Array.from(new Set([...(v.brandsSupplied || []), ...mappings.map((m) => m.brand).filter(Boolean)]));
      v.materialCategories = cats;
      v.brandsSupplied = brands;
      this.data.vendors[vIdx] = v;
    }

    this.save();
    return { added, updated, skippedDuplicates };
  }

  // Audit Logs
  public addAuditLog(entry: Omit<AuditLogEntry, 'id' | 'timestamp'>): AuditLogEntry {
    const newLog: AuditLogEntry = {
      ...entry,
      id: `AUD-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
    };
    this.data.auditLogs.unshift(newLog);
    if (this.data.auditLogs.length > 1000) {
      this.data.auditLogs.pop();
    }
    this.save();
    return newLog;
  }

  // Requirement Management & Permanent Deletion
  public deleteRequirement(
    id: string,
    user: string = 'User',
    role: string = 'Procurement Specialist',
    ip: string = 'unknown',
    reason: string = 'Archived by user'
  ): { success: boolean; message: string; deletedId: string } {
    const rfqNumber = id;
    const reqIndex = this.data.requirements.findIndex(
      (r) => r.id === id || r.rfqNumber === id
    );

    const actualReq = reqIndex !== -1 ? this.data.requirements[reqIndex] : null;
    const actualId = actualReq?.id || id;
    const actualRfq = actualReq?.rfqNumber || id;
    const now = new Date().toISOString();

    // Soft delete: Retain record in database with isDeleted flag for recovery
    if (reqIndex !== -1) {
      this.data.requirements[reqIndex] = {
        ...this.data.requirements[reqIndex],
        isDeleted: true,
        deletedAt: now,
        deletedBy: user,
        deletedReason: reason,
        lastModifiedAt: now,
        lastModifiedBy: user,
      };
    }

    // Add immutable server audit log with IP and Actor
    this.addAuditLog({
      user,
      role,
      action: 'REQUIREMENT_SOFT_DELETED',
      module: 'Requirement',
      recordNumber: actualRfq,
      remarks: `Requirement ${actualRfq} (${actualId}) soft-deleted by ${user} from IP ${ip}. Reason: ${reason}. Retained in database for Super Admin recovery.`,
      ipAddress: ip,
    });

    this.save();
    return {
      success: true,
      message: `Requirement ${actualRfq} soft-deleted. It can be recovered anytime from the Deleted RFQs view.`,
      deletedId: actualId,
    };
  }

  public restoreRequirement(
    id: string,
    user: string = 'Admin',
    role: string = 'Admin',
    ip: string = 'unknown'
  ): { success: boolean; message: string; requirement?: any } {
    const reqIndex = this.data.requirements.findIndex(
      (r) => r.id === id || r.rfqNumber === id
    );

    if (reqIndex === -1) {
      return { success: false, message: `Requirement ${id} not found in database.` };
    }

    const now = new Date().toISOString();
    const restored = {
      ...this.data.requirements[reqIndex],
      isDeleted: false,
      deletedAt: undefined,
      deletedBy: undefined,
      deletedReason: undefined,
      lastModifiedAt: now,
      lastModifiedBy: user,
    };
    this.data.requirements[reqIndex] = restored;

    // Remove from deletedRequirementIds if present
    this.data.deletedRequirementIds = (this.data.deletedRequirementIds || []).filter(
      (dId: string) => dId !== restored.id && dId !== restored.rfqNumber
    );

    this.addAuditLog({
      user,
      role,
      action: 'REQUIREMENT_RESTORED',
      module: 'Requirement',
      recordNumber: restored.rfqNumber || restored.id,
      remarks: `Requirement ${restored.rfqNumber || restored.id} restored to active register by ${user} from IP ${ip}.`,
      ipAddress: ip,
    });

    this.save();
    return {
      success: true,
      message: `Requirement ${restored.rfqNumber || restored.id} successfully restored to active register.`,
      requirement: restored,
    };
  }

  public saveRequirement(req: any, user: string = 'User', role: string = 'Procurement Specialist', ip: string = 'unknown'): any {
    if (!req || (!req.id && !req.rfqNumber)) {
      throw new Error('Invalid requirement data');
    }

    // If ID was in tombstones, remove it since user explicitly created/saved it
    if (this.data.deletedRequirementIds.includes(req.id)) {
      this.data.deletedRequirementIds = this.data.deletedRequirementIds.filter((tid) => tid !== req.id);
    }
    if (req.rfqNumber && this.data.deletedRequirementIds.includes(req.rfqNumber)) {
      this.data.deletedRequirementIds = this.data.deletedRequirementIds.filter((tid) => tid !== req.rfqNumber);
    }

    const now = new Date().toISOString();
    const cleanReq = {
      ...req,
      isDeleted: req.isDeleted === true ? true : false,
      dbSaveStatus: 'COMMITTED',
      cloudSyncStatus: 'SYNCED',
      lastModifiedAt: now,
      lastModifiedBy: user,
    };

    const idx = this.data.requirements.findIndex((r) => r.id === req.id || (req.rfqNumber && r.rfqNumber === req.rfqNumber));
    if (idx !== -1) {
      this.data.requirements[idx] = { ...this.data.requirements[idx], ...cleanReq, updatedAt: now };
      this.addAuditLog({
        user,
        role,
        action: 'REQUIREMENT_UPDATED',
        module: 'Requirement',
        recordNumber: req.rfqNumber || req.id,
        remarks: `Requirement ${req.rfqNumber || req.id} updated from IP ${ip}`,
        ipAddress: ip,
      });
    } else {
      this.data.requirements.unshift(cleanReq);
      this.addAuditLog({
        user,
        role,
        action: 'REQUIREMENT_CREATED',
        module: 'Requirement',
        recordNumber: req.rfqNumber || req.id,
        remarks: `New Requirement ${req.rfqNumber || req.id} permanently saved to database from IP ${ip}`,
        ipAddress: ip,
      });
    }

    this.save();
    return cleanReq;
  }

  // Atomic RFQ Sequence Number Generator
  public getNextRfqNumber(): string {
    const year = new Date().getFullYear();
    this.data.rfqCounter = (this.data.rfqCounter || 100) + 1;
    const seq = String(this.data.rfqCounter).padStart(5, '0');
    this.save();
    return `RFQ-${year}-${seq}`;
  }

  // Authoritative State Sync
  public getAuthoritativeState() {
    return {
      version: this.data.version || 2,
      lastUpdated: this.data.lastUpdated,
      requirements: this.data.requirements,
      deletedRequirementIds: this.data.deletedRequirementIds,
      companies: this.data.companies,
      purchaseExecutives: this.data.purchaseExecutives,
      customers: this.data.customers,
      vendors: (this.data.vendors || []).filter((v: any) => !(this.data.deletedVendorIds || []).includes(v.id)),
      deletedVendorIds: this.data.deletedVendorIds || [],
      products: this.data.products,
      quotations: this.data.quotations,
      customerPos: this.data.customerPos,
      vendorPos: this.data.vendorPos,
      proformaInvoices: this.data.proformaInvoices,
      payments: this.data.payments,
      dispatches: this.data.dispatches,
      deliveries: this.data.deliveries,
      rfqs: this.data.rfqs,
      vendorQuotes: this.data.vendorQuotes,
      notifications: this.data.notifications,
      auditLogs: this.data.auditLogs,
      loginAuditLogs: this.data.loginAuditLogs,
      activeSessions: this.data.activeSessions.filter((s) => s.status === 'ACTIVE'),
      vendorProductMappings: this.data.vendorProductMappings || [],
      invoices: this.data.invoices || INITIAL_INVOICES,
      vendorBills: this.data.vendorBills || INITIAL_VENDOR_BILLS,
      expenses: this.data.expenses || INITIAL_EXPENSES,
      challans: this.data.challans || [],
      companySettings: this.data.companySettings || INITIAL_COMPANY_SETTINGS,
      users: this.getUsers(),
      roles: this.getRoles(),
      approvals: this.data.approvals,
      brands: this.data.brands || [],
      categories: this.data.categories || [],
      productTypes: this.getProductTypes(),
    };
  }

  // Full Sync with Conflict Resolution
  public syncState(clientPayload: any, user: string = 'User', ip: string = 'unknown') {
    if (!clientPayload) return this.getAuthoritativeState();

    // Reconcile Requirements: Never restore items that are in deletedRequirementIds
    if (Array.isArray(clientPayload.requirements)) {
      const incoming = clientPayload.requirements.filter(
        (r: any) =>
          !this.data.deletedRequirementIds.includes(r.id) &&
          !this.data.deletedRequirementIds.includes(r.rfqNumber)
      );

      for (const item of incoming) {
        const existingIdx = this.data.requirements.findIndex((r) => r.id === item.id || r.rfqNumber === item.rfqNumber);
        if (existingIdx !== -1) {
          // If client version is newer, update
          this.data.requirements[existingIdx] = { ...this.data.requirements[existingIdx], ...item };
        } else {
          this.data.requirements.push(item);
        }
      }
    }

    // Companies sync
    if (Array.isArray(clientPayload.companies)) {
      for (const c of clientPayload.companies) {
        const idx = this.data.companies.findIndex((item) => item.id === c.id);
        if (idx !== -1) {
          this.data.companies[idx] = { ...this.data.companies[idx], ...c };
        } else {
          this.data.companies.push(c);
        }
      }
    }

    // Purchase Executives sync
    if (Array.isArray(clientPayload.purchaseExecutives)) {
      for (const pe of clientPayload.purchaseExecutives) {
        const idx = this.data.purchaseExecutives.findIndex((item) => item.id === pe.id);
        if (idx !== -1) {
          this.data.purchaseExecutives[idx] = { ...this.data.purchaseExecutives[idx], ...pe };
        } else {
          this.data.purchaseExecutives.push(pe);
        }
      }
    }

    // Vendors sync - update and merge vendors
    if (Array.isArray(clientPayload.vendors) && clientPayload.vendors.length > 0) {
      for (const v of clientPayload.vendors) {
        const idx = this.data.vendors.findIndex((item) => item.id === v.id);
        if (idx !== -1) {
          this.data.vendors[idx] = { ...this.data.vendors[idx], ...v };
        } else {
          this.data.vendors.push(v);
        }
      }
    }

    // Vendor Product Mappings sync
    if (Array.isArray(clientPayload.vendorProductMappings)) {
      for (const m of clientPayload.vendorProductMappings) {
        const idx = this.data.vendorProductMappings.findIndex((item) => item.id === m.id);
        if (idx !== -1) {
          this.data.vendorProductMappings[idx] = { ...this.data.vendorProductMappings[idx], ...m };
        } else {
          this.data.vendorProductMappings.push(m);
        }
      }
    }

    // Products Master sync
    if (Array.isArray(clientPayload.products)) {
      for (const p of clientPayload.products) {
        const idx = this.data.products.findIndex((item) => item.id === p.id);
        if (idx !== -1) {
          this.data.products[idx] = { ...this.data.products[idx], ...p };
        } else {
          this.data.products.push(p);
        }
      }
    }

    // Quotations sync
    if (Array.isArray(clientPayload.quotations)) {
      for (const q of clientPayload.quotations) {
        const idx = this.data.quotations.findIndex((item) => item.id === q.id);
        if (idx !== -1) {
          this.data.quotations[idx] = { ...this.data.quotations[idx], ...q };
        } else {
          this.data.quotations.push(q);
        }
      }
    }

    // Customer POs sync
    if (Array.isArray(clientPayload.customerPos)) {
      for (const po of clientPayload.customerPos) {
        const idx = this.data.customerPos.findIndex((item) => item.id === po.id);
        if (idx !== -1) {
          this.data.customerPos[idx] = { ...this.data.customerPos[idx], ...po };
        } else {
          this.data.customerPos.push(po);
        }
      }
    }

    // Payments sync
    if (Array.isArray(clientPayload.payments)) {
      for (const p of clientPayload.payments) {
        const idx = this.data.payments.findIndex((item) => item.id === p.id);
        if (idx !== -1) {
          this.data.payments[idx] = { ...this.data.payments[idx], ...p };
        } else {
          this.data.payments.push(p);
        }
      }
    }

    // Dispatches sync
    if (Array.isArray(clientPayload.dispatches)) {
      for (const d of clientPayload.dispatches) {
        const idx = this.data.dispatches.findIndex((item) => item.id === d.id);
        if (idx !== -1) {
          this.data.dispatches[idx] = { ...this.data.dispatches[idx], ...d };
        } else {
          this.data.dispatches.push(d);
        }
      }
    }

    // Invoices sync
    if (Array.isArray(clientPayload.invoices)) {
      if (!Array.isArray(this.data.invoices)) this.data.invoices = [];
      for (const inv of clientPayload.invoices) {
        const idx = this.data.invoices.findIndex((item) => item.id === inv.id);
        if (idx !== -1) {
          this.data.invoices[idx] = { ...this.data.invoices[idx], ...inv };
        } else {
          this.data.invoices.push(inv);
        }
      }
    }

    // Vendor Bills sync
    if (Array.isArray(clientPayload.vendorBills)) {
      if (!Array.isArray(this.data.vendorBills)) this.data.vendorBills = [];
      for (const b of clientPayload.vendorBills) {
        const idx = this.data.vendorBills.findIndex((item) => item.id === b.id);
        if (idx !== -1) {
          this.data.vendorBills[idx] = { ...this.data.vendorBills[idx], ...b };
        } else {
          this.data.vendorBills.push(b);
        }
      }
    }

    // Expenses sync
    if (Array.isArray(clientPayload.expenses)) {
      if (!Array.isArray(this.data.expenses)) this.data.expenses = [];
      for (const e of clientPayload.expenses) {
        const idx = this.data.expenses.findIndex((item) => item.id === e.id);
        if (idx !== -1) {
          this.data.expenses[idx] = { ...this.data.expenses[idx], ...e };
        } else {
          this.data.expenses.push(e);
        }
      }
    }

    // Challans sync
    if (Array.isArray(clientPayload.challans)) {
      if (!Array.isArray(this.data.challans)) this.data.challans = [];
      for (const ch of clientPayload.challans) {
        const idx = this.data.challans.findIndex((item) => item.id === ch.id);
        if (idx !== -1) {
          this.data.challans[idx] = { ...this.data.challans[idx], ...ch };
        } else {
          this.data.challans.push(ch);
        }
      }
    }

    // Company Settings sync
    if (clientPayload.companySettings && typeof clientPayload.companySettings === 'object') {
      this.data.companySettings = {
        ...(this.data.companySettings || INITIAL_COMPANY_SETTINGS),
        ...clientPayload.companySettings,
      };
    }

    // Brands sync
    if (Array.isArray(clientPayload.brands)) {
      if (!Array.isArray(this.data.brands)) this.data.brands = [];
      for (const b of clientPayload.brands) {
        const idx = this.data.brands.findIndex((item) => item.id === b.id || item.name?.toLowerCase().trim() === b.name?.toLowerCase().trim());
        if (idx !== -1) {
          this.data.brands[idx] = { ...this.data.brands[idx], ...b };
        } else {
          this.data.brands.push(b);
        }
      }
    }

    // Categories sync
    if (Array.isArray(clientPayload.categories)) {
      if (!Array.isArray(this.data.categories)) this.data.categories = [];
      for (const c of clientPayload.categories) {
        const idx = this.data.categories.findIndex((item) => item.id === c.id || item.name?.toLowerCase().trim() === c.name?.toLowerCase().trim());
        if (idx !== -1) {
          this.data.categories[idx] = { ...this.data.categories[idx], ...c };
        } else {
          this.data.categories.push(c);
        }
      }
    }

    // Product Types sync
    if (Array.isArray(clientPayload.productTypes)) {
      if (!Array.isArray(this.data.productTypes)) this.data.productTypes = [];
      for (const pt of clientPayload.productTypes) {
        if (!pt || !pt.name) continue;
        const idx = this.data.productTypes.findIndex(
          (item) => item.id === pt.id || item.name?.toLowerCase().trim() === pt.name?.toLowerCase().trim()
        );
        if (idx !== -1) {
          this.data.productTypes[idx] = { ...this.data.productTypes[idx], ...pt };
        } else {
          this.data.productTypes.push(pt);
        }
      }
    }

    // Customers sync
    if (Array.isArray(clientPayload.customers)) {
      if (!Array.isArray(this.data.customers)) this.data.customers = [];
      for (const c of clientPayload.customers) {
        if (!c || !c.companyName) continue;
        const idx = this.data.customers.findIndex(
          (item) =>
            item.id === c.id ||
            (c.gstin && item.gstin && item.gstin.trim().toLowerCase() === c.gstin.trim().toLowerCase()) ||
            item.companyName?.trim().toLowerCase() === c.companyName?.trim().toLowerCase()
        );
        if (idx !== -1) {
          this.data.customers[idx] = { ...this.data.customers[idx], ...c };
        } else {
          this.data.customers.push(c);
        }
      }
    }

    // RFQs sync
    if (Array.isArray(clientPayload.rfqs)) {
      if (!Array.isArray(this.data.rfqs)) this.data.rfqs = [];
      for (const r of clientPayload.rfqs) {
        if (!r) continue;
        const idx = this.data.rfqs.findIndex((item) => item.id === r.id || (r.rfqNumber && item.rfqNumber === r.rfqNumber));
        if (idx !== -1) {
          this.data.rfqs[idx] = { ...this.data.rfqs[idx], ...r };
        } else {
          this.data.rfqs.push(r);
        }
      }
    }

    // Vendor Quotes sync
    if (Array.isArray(clientPayload.vendorQuotes)) {
      if (!Array.isArray(this.data.vendorQuotes)) this.data.vendorQuotes = [];
      for (const vq of clientPayload.vendorQuotes) {
        if (!vq || !vq.id) continue;
        const idx = this.data.vendorQuotes.findIndex((item) => item.id === vq.id);
        if (idx !== -1) {
          this.data.vendorQuotes[idx] = { ...this.data.vendorQuotes[idx], ...vq };
        } else {
          this.data.vendorQuotes.push(vq);
        }
      }
    }

    // Vendor POs sync
    if (Array.isArray(clientPayload.vendorPos)) {
      if (!Array.isArray(this.data.vendorPos)) this.data.vendorPos = [];
      for (const vpo of clientPayload.vendorPos) {
        if (!vpo || !vpo.id) continue;
        const idx = this.data.vendorPos.findIndex((item) => item.id === vpo.id);
        if (idx !== -1) {
          this.data.vendorPos[idx] = { ...this.data.vendorPos[idx], ...vpo };
        } else {
          this.data.vendorPos.push(vpo);
        }
      }
    }

    // Proforma Invoices sync
    if (Array.isArray(clientPayload.proformaInvoices)) {
      if (!Array.isArray(this.data.proformaInvoices)) this.data.proformaInvoices = [];
      for (const pi of clientPayload.proformaInvoices) {
        if (!pi || !pi.id) continue;
        const idx = this.data.proformaInvoices.findIndex((item) => item.id === pi.id);
        if (idx !== -1) {
          this.data.proformaInvoices[idx] = { ...this.data.proformaInvoices[idx], ...pi };
        } else {
          this.data.proformaInvoices.push(pi);
        }
      }
    }

    // Deliveries sync
    if (Array.isArray(clientPayload.deliveries)) {
      if (!Array.isArray(this.data.deliveries)) this.data.deliveries = [];
      for (const del of clientPayload.deliveries) {
        if (!del || !del.id) continue;
        const idx = this.data.deliveries.findIndex((item) => item.id === del.id);
        if (idx !== -1) {
          this.data.deliveries[idx] = { ...this.data.deliveries[idx], ...del };
        } else {
          this.data.deliveries.push(del);
        }
      }
    }

    // Notifications sync
    if (Array.isArray(clientPayload.notifications)) {
      if (!Array.isArray(this.data.notifications)) this.data.notifications = [];
      for (const notif of clientPayload.notifications) {
        if (!notif || !notif.id) continue;
        const idx = this.data.notifications.findIndex((item) => item.id === notif.id);
        if (idx !== -1) {
          this.data.notifications[idx] = { ...this.data.notifications[idx], ...notif };
        } else {
          this.data.notifications.unshift(notif);
        }
      }
    }

    this.save();
    return this.getAuthoritativeState();
  }

  // Customers Management
  public getCustomers(): any[] {
    return this.data.customers || [];
  }

  public saveCustomer(customer: any, user: string = 'Admin', role: string = 'Admin', ip: string = 'unknown'): any {
    if (!Array.isArray(this.data.customers)) this.data.customers = [];
    const idx = this.data.customers.findIndex(
      (c) => c.id === customer.id || (customer.gstin && c.gstin && c.gstin.trim().toLowerCase() === customer.gstin.trim().toLowerCase())
    );
    if (idx !== -1) {
      this.data.customers[idx] = { ...this.data.customers[idx], ...customer, updatedAt: new Date().toISOString() };
      this.addAuditLog({
        user,
        role,
        action: 'CUSTOMER_UPDATED',
        module: 'Customer Master',
        recordNumber: customer.id,
        remarks: `Customer ${customer.companyName} updated from IP ${ip}`,
        ipAddress: ip,
      });
    } else {
      const newCust = {
        ...customer,
        id: customer.id || `CUST-${String(this.data.customers.length + 1).padStart(3, '0')}`,
        createdAt: customer.createdAt || new Date().toISOString().split('T')[0],
      };
      this.data.customers.unshift(newCust);
      this.addAuditLog({
        user,
        role,
        action: 'CUSTOMER_CREATED',
        module: 'Customer Master',
        recordNumber: newCust.id,
        remarks: `Customer ${newCust.companyName} created from IP ${ip}`,
        ipAddress: ip,
      });
      customer = newCust;
    }
    this.save();
    return customer;
  }

  public deleteCustomer(id: string, user: string = 'Admin', role: string = 'Admin', ip: string = 'unknown'): boolean {
    if (!Array.isArray(this.data.customers)) return false;
    const target = this.data.customers.find((c) => c.id === id);
    this.data.customers = this.data.customers.filter((c) => c.id !== id);
    this.addAuditLog({
      user,
      role,
      action: 'CUSTOMER_DELETED',
      module: 'Customer Master',
      recordNumber: id,
      remarks: `Customer ${target?.companyName || id} removed from IP ${ip}`,
      ipAddress: ip,
    });
    this.save();
    return true;
  }

  // Categories Management
  public getCategories(): any[] {
    if (!Array.isArray(this.data.categories) || this.data.categories.length === 0) {
      this.data.categories = INITIAL_MATERIAL_CATEGORIES.map((c) => ({ ...c }));
      this.save();
    }
    return this.data.categories;
  }

  public saveCategory(category: any, user: string = 'Admin', role: string = 'Admin', ip: string = 'unknown'): any {
    if (!Array.isArray(this.data.categories)) this.data.categories = [];
    const idx = this.data.categories.findIndex((c) => c.id === category.id || c.name?.trim().toLowerCase() === category.name?.trim().toLowerCase());
    if (idx !== -1) {
      this.data.categories[idx] = { ...this.data.categories[idx], ...category, updatedAt: new Date().toISOString().split('T')[0] };
    } else {
      const newCat = {
        ...category,
        id: category.id || `CAT-${String(this.data.categories.length + 1).padStart(3, '0')}`,
        createdAt: category.createdAt || new Date().toISOString().split('T')[0],
        updatedAt: new Date().toISOString().split('T')[0],
      };
      this.data.categories.push(newCat);
      category = newCat;
    }
    this.addAuditLog({
      user,
      role,
      action: idx !== -1 ? 'CATEGORY_UPDATED' : 'CATEGORY_CREATED',
      module: 'Category Master',
      recordNumber: category.id,
      remarks: `Material category "${category.name}" saved from IP ${ip}`,
      ipAddress: ip,
    });
    this.save();
    return category;
  }

  public deleteCategory(id: string, user: string = 'Admin', role: string = 'Admin', ip: string = 'unknown'): boolean {
    if (!Array.isArray(this.data.categories)) return false;
    const target = this.data.categories.find((c) => c.id === id);
    this.data.categories = this.data.categories.filter((c) => c.id !== id);
    this.addAuditLog({
      user,
      role,
      action: 'CATEGORY_DELETED',
      module: 'Category Master',
      recordNumber: id,
      remarks: `Category "${target?.name || id}" removed from IP ${ip}`,
      ipAddress: ip,
    });
    this.save();
    return true;
  }

  // Brands Management
  public getBrands(): any[] {
    if (!Array.isArray(this.data.brands) || this.data.brands.length === 0) {
      this.data.brands = INITIAL_BRANDS.map((b) => ({ ...b }));
      this.save();
    }
    return this.data.brands;
  }

  public saveBrand(brand: any, user: string = 'Admin', role: string = 'Admin', ip: string = 'unknown'): any {
    if (!Array.isArray(this.data.brands)) this.data.brands = [];
    const idx = this.data.brands.findIndex((b) => b.id === brand.id || b.name?.trim().toLowerCase() === brand.name?.trim().toLowerCase());
    if (idx !== -1) {
      this.data.brands[idx] = { ...this.data.brands[idx], ...brand, updatedAt: new Date().toISOString().split('T')[0] };
    } else {
      const newBrd = {
        ...brand,
        id: brand.id || `BRD-${String(this.data.brands.length + 1).padStart(3, '0')}`,
        createdAt: brand.createdAt || new Date().toISOString().split('T')[0],
        updatedAt: new Date().toISOString().split('T')[0],
      };
      this.data.brands.unshift(newBrd);
      brand = newBrd;
    }
    this.addAuditLog({
      user,
      role,
      action: idx !== -1 ? 'BRAND_UPDATED' : 'BRAND_CREATED',
      module: 'Brand Master',
      recordNumber: brand.id,
      remarks: `Brand "${brand.name}" saved from IP ${ip}`,
      ipAddress: ip,
    });
    this.save();
    return brand;
  }

  public deleteBrand(id: string, user: string = 'Admin', role: string = 'Admin', ip: string = 'unknown'): boolean {
    if (!Array.isArray(this.data.brands)) return false;
    const target = this.data.brands.find((b) => b.id === id);
    this.data.brands = this.data.brands.filter((b) => b.id !== id);
    this.addAuditLog({
      user,
      role,
      action: 'BRAND_DELETED',
      module: 'Brand Master',
      recordNumber: id,
      remarks: `Brand "${target?.name || id}" removed from IP ${ip}`,
      ipAddress: ip,
    });
    this.save();
    return true;
  }

  // Deliveries Management
  public getDeliveries(): any[] {
    return this.data.deliveries || [];
  }

  public saveDelivery(del: any, user: string = 'User', role: string = 'Admin', ip: string = 'unknown'): any {
    if (!Array.isArray(this.data.deliveries)) this.data.deliveries = [];
    const idx = this.data.deliveries.findIndex((d) => d.id === del.id || (del.dispatchId && d.dispatchId === del.dispatchId));
    if (idx !== -1) {
      this.data.deliveries[idx] = { ...this.data.deliveries[idx], ...del };
    } else {
      this.data.deliveries.unshift(del);
    }
    this.addAuditLog({
      user,
      role,
      action: 'DELIVERY_STATUS_UPDATED',
      module: 'Delivery Tracking',
      recordNumber: del.id || del.dispatchId,
      remarks: `Delivery status updated: ${del.status || 'DELIVERED'} from IP ${ip}`,
      ipAddress: ip,
    });
    this.save();
    return del;
  }

  // Financial Helpers
  public getInvoices(): any[] {
    if (!Array.isArray(this.data.invoices) || this.data.invoices.length === 0) {
      this.data.invoices = INITIAL_INVOICES;
      this.save();
    }
    return this.data.invoices;
  }

  public saveInvoice(invoice: any): any {
    if (!Array.isArray(this.data.invoices)) this.data.invoices = [];
    const idx = this.data.invoices.findIndex((i) => i.id === invoice.id);
    if (idx !== -1) {
      this.data.invoices[idx] = { ...this.data.invoices[idx], ...invoice, updatedAt: new Date().toISOString() };
    } else {
      this.data.invoices.push({ ...invoice, createdAt: invoice.createdAt || new Date().toISOString() });
    }
    this.save();
    return invoice;
  }

  public getVendorBills(): any[] {
    if (!Array.isArray(this.data.vendorBills) || this.data.vendorBills.length === 0) {
      this.data.vendorBills = INITIAL_VENDOR_BILLS;
      this.save();
    }
    return this.data.vendorBills;
  }

  public saveVendorBill(bill: any): any {
    if (!Array.isArray(this.data.vendorBills)) this.data.vendorBills = [];
    const idx = this.data.vendorBills.findIndex((b) => b.id === bill.id);
    if (idx !== -1) {
      this.data.vendorBills[idx] = { ...this.data.vendorBills[idx], ...bill, updatedAt: new Date().toISOString() };
    } else {
      this.data.vendorBills.push({ ...bill, createdAt: bill.createdAt || new Date().toISOString() });
    }
    this.save();
    return bill;
  }

  public getExpenses(): any[] {
    if (!Array.isArray(this.data.expenses) || this.data.expenses.length === 0) {
      this.data.expenses = INITIAL_EXPENSES;
      this.save();
    }
    return this.data.expenses;
  }

  public saveExpense(expense: any): any {
    if (!Array.isArray(this.data.expenses)) this.data.expenses = [];
    const idx = this.data.expenses.findIndex((e) => e.id === expense.id);
    if (idx !== -1) {
      this.data.expenses[idx] = { ...this.data.expenses[idx], ...expense };
    } else {
      this.data.expenses.push(expense);
    }
    this.save();
    return expense;
  }

  public getCompanySettings(): any {
    return this.data.companySettings || INITIAL_COMPANY_SETTINGS;
  }

  public saveCompanySettings(settings: any): any {
    this.data.companySettings = {
      ...(this.data.companySettings || INITIAL_COMPANY_SETTINGS),
      ...settings,
    };
    this.save();
    return this.data.companySettings;
  }

  // Login Audit Records
  public recordLoginAudit(entry: Omit<LoginAuditRecord, 'id' | 'timestamp'>): LoginAuditRecord {
    const newLog: LoginAuditRecord = {
      ...entry,
      id: `LOG-${Date.now().toString().slice(-6)}`,
      timestamp: new Date().toISOString().replace('T', ' ').slice(0, 19),
    };
    this.data.loginAuditLogs.unshift(newLog);
    if (this.data.loginAuditLogs.length > 2000) {
      this.data.loginAuditLogs.pop();
    }
    this.save();
    return newLog;
  }

  public getLoginAuditLogs(limit: number = 200): LoginAuditRecord[] {
    return this.data.loginAuditLogs.slice(0, limit);
  }

  // Active Sessions
  public createSession(data: Omit<ActiveSessionRecord, 'status'>): ActiveSessionRecord {
    const newSession: ActiveSessionRecord = {
      ...data,
      status: 'ACTIVE',
    };
    // Keep max 5 active sessions per user, mark older ones as inactive
    this.data.activeSessions = this.data.activeSessions.filter(
      (s) => s.id !== data.id && (s.userId !== data.userId || s.status === 'ACTIVE')
    );
    this.data.activeSessions.unshift(newSession);
    this.save();
    return newSession;
  }

  public getActiveSessions(): ActiveSessionRecord[] {
    return this.data.activeSessions;
  }

  public revokeSession(sessionId: string, adminUser: string, ip: string = 'unknown'): boolean {
    const session = this.data.activeSessions.find((s) => s.id === sessionId);
    if (!session) return false;

    session.status = 'REVOKED';
    this.addAuditLog({
      user: adminUser,
      role: 'Admin',
      action: 'SESSION_REVOKED',
      module: 'Security',
      recordNumber: sessionId,
      remarks: `Admin ${adminUser} revoked session ${sessionId} for user ${session.username} from IP ${ip}`,
      ipAddress: ip,
    });

    this.recordLoginAudit({
      username: session.username,
      role: session.role,
      userId: session.userId,
      status: 'FAILED',
      ipAddress: session.ipAddress,
      userAgent: session.userAgent,
      deviceType: session.deviceType,
      sessionId: session.id,
      failureReason: `Session revoked by administrator ${adminUser}`,
    });

    this.save();
    return true;
  }

  public updateSessionActivity(sessionId: string) {
    const s = this.data.activeSessions.find((item) => item.id === sessionId);
    if (s && s.status === 'ACTIVE') {
      s.lastActiveTime = new Date().toISOString().replace('T', ' ').slice(0, 19);
      this.save();
    }
  }
}

export const db = new PersistentDatabase();
