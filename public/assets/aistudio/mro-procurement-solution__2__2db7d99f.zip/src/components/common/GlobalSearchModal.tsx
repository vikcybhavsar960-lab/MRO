import React, { useState, useMemo } from 'react';
import {
  Search,
  X,
  FileText,
  Building,
  CreditCard,
  Truck,
  ArrowRight,
  PackageCheck,
  Receipt,
  ShoppingCart,
  Layers,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface GlobalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectOrder: (orderId: string) => void;
}

export const GlobalSearchModal: React.FC<GlobalSearchModalProps> = ({
  isOpen,
  onClose,
  onSelectOrder,
}) => {
  const {
    requirements,
    customerQuotations,
    customerPOs,
    vendorPOs,
    proformaInvoices,
    dispatches,
    customers,
    vendors,
    products,
    categories,
    setActiveTab,
  } = useApp();

  const [query, setQuery] = useState('');

  const searchResults = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase().trim();

    const results: Array<{
      type: string;
      title: string;
      subtitle: string;
      refId: string;
      tab: string;
      badge: string;
    }> = [];

    // Search Requirements & Items
    requirements.forEach((req) => {
      const matchReq =
        req.id.toLowerCase().includes(q) ||
        req.customerName.toLowerCase().includes(q) ||
        req.contactPerson.toLowerCase().includes(q) ||
        req.customerMobile.includes(q);

      const matchedItem = req.items.find(
        (it) =>
          it.itemName.toLowerCase().includes(q) ||
          (it.partNumber || '').toLowerCase().includes(q) ||
          it.brand.toLowerCase().includes(q)
      );

      if (matchReq || matchedItem) {
        results.push({
          type: 'REQUIREMENT',
          title: `${req.id} • ${req.customerName}`,
          subtitle: matchedItem
            ? `Matched item: ${matchedItem.itemName} (${matchedItem.partNumber})`
            : `${req.items.length} items • Status: ${req.status}`,
          refId: req.id,
          tab: 'requirements',
          badge: req.status,
        });
      }
    });

    // Search Quotations
    customerQuotations.forEach((qtn) => {
      if (
        qtn.id.toLowerCase().includes(q) ||
        qtn.customerName.toLowerCase().includes(q) ||
        qtn.items.some((i) => i.itemName.toLowerCase().includes(q) || i.partNumber.toLowerCase().includes(q))
      ) {
        results.push({
          type: 'QUOTATION',
          title: `${qtn.id} • ${qtn.customerName}`,
          subtitle: `Total: ₹${qtn.grandTotal.toLocaleString('en-IN')} (Ref: ${qtn.requirementId})`,
          refId: qtn.requirementId,
          tab: 'quotations',
          badge: qtn.status,
        });
      }
    });

    // Search Customer POs
    customerPOs.forEach((cpo) => {
      if (
        cpo.id.toLowerCase().includes(q) ||
        cpo.customerPoNumber.toLowerCase().includes(q) ||
        cpo.customerName.toLowerCase().includes(q)
      ) {
        results.push({
          type: 'CUSTOMER PO',
          title: `${cpo.id} • ${cpo.customerPoNumber}`,
          subtitle: `${cpo.customerName} • Amount: ₹${cpo.poAmount.toLocaleString('en-IN')}`,
          refId: cpo.requirementId,
          tab: 'customer-pos',
          badge: 'PO RECEIVED',
        });
      }
    });

    // Search Vendor POs
    vendorPOs.forEach((vpo) => {
      if (
        vpo.id.toLowerCase().includes(q) ||
        vpo.vendorName.toLowerCase().includes(q) ||
        vpo.items.some((i) => i.itemName.toLowerCase().includes(q) || i.partNumber.toLowerCase().includes(q))
      ) {
        results.push({
          type: 'VENDOR PO',
          title: `${vpo.id} • ${vpo.vendorName}`,
          subtitle: `Value: ₹${vpo.totalAmount.toLocaleString('en-IN')} (Ref: ${vpo.requirementId})`,
          refId: vpo.requirementId,
          tab: 'vendor-pos',
          badge: 'ORDER PLACED',
        });
      }
    });

    // Search Proforma Invoices
    proformaInvoices.forEach((pi) => {
      if (
        pi.id.toLowerCase().includes(q) ||
        pi.piNumber.toLowerCase().includes(q) ||
        pi.vendorName.toLowerCase().includes(q)
      ) {
        results.push({
          type: 'PROFORMA INVOICE',
          title: `${pi.id} • ${pi.piNumber}`,
          subtitle: `Vendor: ${pi.vendorName} • ₹${pi.totalAmount.toLocaleString('en-IN')}`,
          refId: pi.requirementId,
          tab: 'pi',
          badge: 'PI RECEIVED',
        });
      }
    });

    // Search Dispatches & Tracking / LR
    dispatches.forEach((dsp) => {
      if (
        dsp.id.toLowerCase().includes(q) ||
        dsp.vendorInvoiceNumber.toLowerCase().includes(q) ||
        dsp.lrNumber.toLowerCase().includes(q) ||
        dsp.awbNumber.toLowerCase().includes(q) ||
        dsp.trackingNumber.toLowerCase().includes(q) ||
        dsp.transporter.toLowerCase().includes(q)
      ) {
        results.push({
          type: 'DISPATCH',
          title: `${dsp.id} • LR: ${dsp.lrNumber}`,
          subtitle: `${dsp.transporter} • Inv: ${dsp.vendorInvoiceNumber} • Ref: ${dsp.requirementId}`,
          refId: dsp.requirementId,
          tab: 'dispatch',
          badge: 'DISPATCHED',
        });
      }
    });

    // Search Products Master
    products.forEach((prod) => {
      if (
        prod.itemName.toLowerCase().includes(q) ||
        prod.partNumber.toLowerCase().includes(q) ||
        prod.brand.toLowerCase().includes(q) ||
        prod.modelNumber.toLowerCase().includes(q)
      ) {
        results.push({
          type: 'PRODUCT MASTER',
          title: `${prod.itemName} (${prod.brand})`,
          subtitle: `Part #: ${prod.partNumber} • Category: ${prod.category}`,
          refId: prod.id,
          tab: 'products',
          badge: prod.uom,
        });
      }
    });

    // Search Customers
    customers.forEach((c) => {
      if (
        c.companyName.toLowerCase().includes(q) ||
        c.contactPerson.toLowerCase().includes(q) ||
        c.mobile.includes(q) ||
        c.gstin.toLowerCase().includes(q)
      ) {
        results.push({
          type: 'CUSTOMER',
          title: `${c.companyName}`,
          subtitle: `Contact: ${c.contactPerson} (${c.mobile}) • GSTIN: ${c.gstin}`,
          refId: c.id,
          tab: 'customers',
          badge: c.city,
        });
      }
    });

    // Search Material Categories
    categories.forEach((cat) => {
      const matchName = cat.name.toLowerCase().includes(q) || cat.code.toLowerCase().includes(q);
      const matchKeyword = cat.keywords.some((k) => k.toLowerCase().includes(q));
      const matchSub = cat.subCategories.some((sc) => sc.toLowerCase().includes(q));

      if (matchName || matchKeyword || matchSub) {
        results.push({
          type: 'MATERIAL CATEGORY',
          title: `${cat.name} (${cat.code})`,
          subtitle: matchKeyword
            ? `Matched keyword in ${cat.keywords.length} keywords • ${cat.subCategories.length} sub-types`
            : cat.description,
          refId: cat.id,
          tab: 'categories',
          badge: 'TAXONOMY',
        });
      }
    });

    // Search Vendors
    vendors.forEach((v) => {
      const vCats = v.materialCategories && v.materialCategories.length > 0 ? v.materialCategories : v.productCategories || [];
      const matchCategory = vCats.some((c) => c.toLowerCase().includes(q));
      const matchSupplyHistory = (v.supplyHistory || []).some((sh) => sh.itemName.toLowerCase().includes(q));

      if (
        v.companyName.toLowerCase().includes(q) ||
        v.contactPerson.toLowerCase().includes(q) ||
        v.mobile.includes(q) ||
        v.brandsSupplied.some((b) => b.toLowerCase().includes(q)) ||
        matchCategory ||
        matchSupplyHistory
      ) {
        results.push({
          type: 'VENDOR',
          title: `${v.companyName}`,
          subtitle: matchCategory
            ? `Supplies category: ${vCats.join(', ')} • Contact: ${v.contactPerson}`
            : matchSupplyHistory
            ? `Supplied item matching "${q}" in past transactions`
            : `Contact: ${v.contactPerson} • Brands: ${v.brandsSupplied.join(', ')}`,
          refId: v.id,
          tab: 'vendors',
          badge: `★ ${v.rating}`,
        });
      }
    });

    return results;
  }, [query, requirements, customerQuotations, customerPOs, vendorPOs, proformaInvoices, dispatches, products, customers, vendors, categories]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-start justify-center pt-16 sm:pt-24 p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden animate-in fade-in zoom-in-95 duration-100">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3">
          <Search className="w-5 h-5 text-blue-600 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type Part # (e.g. 30205), Order (REQ-001), LR, Customer, Vendor, Invoice..."
            className="w-full text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-hidden"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-md text-slate-400 hover:text-slate-600 hover:bg-slate-100"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-semibold px-2 py-1 text-slate-500 hover:bg-slate-100 rounded-md"
          >
            ESC
          </button>
        </div>

        {/* Quick query chips */}
        <div className="px-4 py-2 bg-slate-50 border-b border-slate-100 flex items-center gap-2 overflow-x-auto text-[11px] text-slate-500">
          <span className="font-semibold text-slate-600 shrink-0">Try searching:</span>
          {['30205', 'Tata Steel', 'Apex', 'REQ-2026-00001', 'Siemens', 'VTR889124'].map((term) => (
            <button
              key={term}
              onClick={() => setQuery(term)}
              className="px-2 py-0.5 rounded-full bg-white border border-slate-200 hover:border-blue-400 hover:text-blue-600 shrink-0 font-medium transition-colors"
            >
              {term}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto divide-y divide-slate-100 p-2">
          {query.trim() === '' ? (
            <div className="py-12 text-center text-xs text-slate-400">
              Type any keyword to search across the entire supply chain enterprise database
            </div>
          ) : searchResults.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-500">
              No matching records found for "{query}". Try checking the spelling or part number.
            </div>
          ) : (
            searchResults.map((item, idx) => (
              <div
                key={idx}
                onClick={() => {
                  setActiveTab(item.tab);
                  if (item.refId && item.refId.startsWith('REQ-')) {
                    onSelectOrder(item.refId);
                  }
                  onClose();
                }}
                className="p-3 rounded-xl hover:bg-blue-50/60 cursor-pointer flex items-center justify-between group transition-colors"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-lg bg-slate-100 group-hover:bg-blue-600 group-hover:text-white text-slate-600 flex items-center justify-center shrink-0 transition-colors">
                    {item.type.includes('REQ') ? (
                      <FileText className="w-4 h-4" />
                    ) : item.type.includes('PO') ? (
                      <ShoppingCart className="w-4 h-4" />
                    ) : item.type.includes('DISPATCH') ? (
                      <Truck className="w-4 h-4" />
                    ) : item.type.includes('PRODUCT') ? (
                      <Layers className="w-4 h-4" />
                    ) : (
                      <Building className="w-4 h-4" />
                    )}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-900 truncate">{item.title}</span>
                      <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded bg-slate-100 text-slate-600 uppercase">
                        {item.type}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">{item.subtitle}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0 ml-3">
                  <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                    {item.badge}
                  </span>
                  <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 group-hover:translate-x-0.5 transition-transform" />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
