import React, { useState } from 'react';
import {
  Database,
  HardDrive,
  Download,
  Upload,
  RotateCcw,
  ShieldCheck,
  CheckCircle2,
  Sparkles,
  HelpCircle,
  X,
  Server,
  Layers,
  ArrowRight,
  Info,
  Laptop,
  Smartphone,
  RefreshCw,
  CloudCheck,
  Copy,
  Check,
  Share2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

interface DataModeModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'switcher' | 'how-it-works' | 'backup';
}

export const DataModeModal: React.FC<DataModeModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'switcher',
}) => {
  const {
    customers,
    vendors,
    products,
    productTypes,
    requirements,
    customerQuotations,
    customerPOs,
    vendorPOs,
    exportFullBackup,
    restoreFullBackup,
    exportTeamSyncSnapshot,
    importTeamSyncSnapshot,
    syncBackendNow,
    pushDeviceDataToCentralDb,
    isSyncing,
    lastSyncTime,
    isOnline,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'switcher' | 'how-it-works' | 'backup'>(initialTab);
  const [restoreText, setRestoreText] = useState('');
  const [restoreStatus, setRestoreStatus] = useState<string | null>(null);
  const [pushStatus, setPushStatus] = useState<string | null>(null);
  const [isPushing, setIsPushing] = useState<boolean>(false);
  const [teamSyncCode, setTeamSyncCode] = useState<string>('');
  const [copiedSyncCode, setCopiedSyncCode] = useState<boolean>(false);
  const [pasteSyncInput, setPasteSyncInput] = useState<string>('');
  const [teamSyncStatus, setTeamSyncStatus] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleManualSync = async () => {
    await syncBackendNow();
  };

  const handlePushToCloud = async () => {
    setIsPushing(true);
    setPushStatus(null);
    try {
      const res = await pushDeviceDataToCentralDb();
      setPushStatus(res.message);
      setTimeout(() => setPushStatus(null), 4000);
    } catch (err: any) {
      setPushStatus(err?.message || 'Upload error');
    } finally {
      setIsPushing(false);
    }
  };

  const handleFileRestore = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      const success = restoreFullBackup(content);
      if (success) {
        setRestoreStatus('Backup successfully restored into current workspace!');
        setTimeout(() => setRestoreStatus(null), 3000);
      } else {
        setRestoreStatus('Error: Invalid backup file format.');
      }
    };
    reader.readAsText(file);
  };

  const handleTextRestore = () => {
    if (!restoreText.trim()) return;
    const success = restoreFullBackup(restoreText);
    if (success) {
      setRestoreStatus('Backup successfully restored into current workspace!');
      setRestoreText('');
      setTimeout(() => setRestoreStatus(null), 3000);
    } else {
      setRestoreStatus('Error: Failed to parse JSON text.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in duration-150">
      <div className="bg-white rounded-2xl shadow-2xl max-w-3xl w-full border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-600/30 border border-emerald-400/40 flex items-center justify-center text-emerald-400">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base tracking-tight">Live Enterprise Cloud ERP Database</h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full border bg-emerald-500/20 text-emerald-300 border-emerald-500/40 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Real-Time Multi-Device Synced</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                Centralized cloud architecture — all company users, laptops, desktops & phones access the identical live database
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-slate-50 border-b border-slate-200 px-5 flex items-center gap-2 text-xs font-semibold shrink-0">
          <button
            onClick={() => setActiveTab('switcher')}
            className={`py-3 px-3 border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'switcher'
                ? 'border-emerald-600 text-emerald-700 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Server className="w-4 h-4" />
            <span>Cloud Sync Status & All Company Devices</span>
          </button>

          <button
            onClick={() => setActiveTab('how-it-works')}
            className={`py-3 px-3 border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'how-it-works'
                ? 'border-emerald-600 text-emerald-700 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <HelpCircle className="w-4 h-4 text-amber-500" />
            <span>Why Did It Only Work On 1 Laptop? (Architecture Fix)</span>
          </button>

          <button
            onClick={() => setActiveTab('backup')}
            className={`py-3 px-3 border-b-2 flex items-center gap-2 transition-all ${
              activeTab === 'backup'
                ? 'border-emerald-600 text-emerald-700 font-bold'
                : 'border-transparent text-slate-600 hover:text-slate-900'
            }`}
          >
            <Download className="w-4 h-4" />
            <span>Backup & Export</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6 text-xs text-slate-700 flex-1">
          {/* TAB 1: Live Cloud Sync Status */}
          {activeTab === 'switcher' && (
            <div className="space-y-6">
              {/* Live Synchronization Status Card */}
              <div className="p-5 rounded-2xl border-2 border-emerald-500/40 bg-gradient-to-br from-emerald-50/70 to-teal-50/40 shadow-xs relative">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold shadow-md shadow-emerald-600/20">
                      <Server className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-extrabold text-sm text-slate-900">
                          Central Live Production Database
                        </h4>
                        <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-800 bg-emerald-100 px-2.5 py-0.5 rounded-full border border-emerald-300">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Active Live Cloud Sync</span>
                        </span>
                      </div>
                      <p className="text-slate-600 text-xs mt-1">
                        Connected to authoritative backend database. Every change you make is saved instantly and broadcast to all company laptops in real-time.
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
                    <button
                      onClick={handleManualSync}
                      disabled={isSyncing}
                      className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold flex items-center gap-1.5 text-xs shadow-sm shadow-emerald-600/20 transition-all disabled:opacity-50"
                    >
                      <RotateCcw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                      <span>{isSyncing ? 'Syncing...' : 'Sync All Devices Now'}</span>
                    </button>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-emerald-200/80 grid grid-cols-1 sm:grid-cols-3 gap-3 text-[11px]">
                  <div className="flex justify-between sm:flex-col gap-0.5 bg-white/70 p-2.5 rounded-xl border border-emerald-200/60">
                    <span className="text-slate-500">Multi-Device Status:</span>
                    <strong className="text-emerald-700 font-bold flex items-center gap-1">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                      <span>{isOnline ? 'Online & Synchronized' : 'Offline Cached'}</span>
                    </strong>
                  </div>
                  <div className="flex justify-between sm:flex-col gap-0.5 bg-white/70 p-2.5 rounded-xl border border-emerald-200/60">
                    <span className="text-slate-500">Last Central Sync:</span>
                    <strong className="text-slate-800 font-mono font-bold">
                      {lastSyncTime.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                    </strong>
                  </div>
                  <div className="flex justify-between sm:flex-col gap-0.5 bg-white/70 p-2.5 rounded-xl border border-emerald-200/60">
                    <span className="text-slate-500">Auto-Sync Heartbeat:</span>
                    <strong className="text-slate-800 font-mono">
                      Every 3 Seconds + On Window Focus
                    </strong>
                  </div>
                </div>
              </div>

              {/* Live Synced Records Across All Users */}
              <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                    <HardDrive className="w-4 h-4 text-emerald-600" />
                    <span>Live Database Record Counts (Shared Across Company Laptops)</span>
                  </span>
                  <span className="text-[11px] font-mono text-emerald-700 font-bold bg-emerald-100/70 px-2 py-0.5 rounded border border-emerald-200">
                    ACID Disk Store Active
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Customers</span>
                    <span className="text-base font-extrabold text-slate-900 font-mono">{customers.length}</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Vendors</span>
                    <span className="text-base font-extrabold text-slate-900 font-mono">{vendors.length}</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Product Types</span>
                    <span className="text-base font-extrabold text-indigo-600 font-mono">{productTypes.length}</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Catalog Products</span>
                    <span className="text-base font-extrabold text-slate-900 font-mono">{products.length}</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Customer RFQs</span>
                    <span className="text-base font-extrabold text-blue-600 font-mono">{requirements.length}</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Quotations</span>
                    <span className="text-base font-extrabold text-purple-600 font-mono">{customerQuotations.length}</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Customer POs</span>
                    <span className="text-base font-extrabold text-emerald-600 font-mono">{customerPOs.length}</span>
                  </div>
                  <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                    <span className="text-[10px] text-slate-500 uppercase font-bold block">Vendor POs</span>
                    <span className="text-base font-extrabold text-amber-600 font-mono">{vendorPOs.length}</span>
                  </div>
                </div>
              </div>

              {/* Force Cloud Sync Button */}
              <div className="bg-white rounded-2xl p-4 border border-slate-200 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <h5 className="font-bold text-xs text-slate-800">
                      Upload / Sync This Laptop's Local Master Records
                    </h5>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      If you added records while offline or want to guarantee every customer, vendor, and product on this laptop is in the central database.
                    </p>
                  </div>
                  <button
                    onClick={handlePushToCloud}
                    disabled={isPushing}
                    className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold transition-all text-xs shrink-0 disabled:opacity-50"
                  >
                    <Upload className={`w-3.5 h-3.5 ${isPushing ? 'animate-bounce' : ''}`} />
                    <span>{isPushing ? 'Uploading...' : 'Push Records to Central Cloud'}</span>
                  </button>
                </div>
                {pushStatus && (
                  <p className="text-[11px] font-bold text-emerald-700 bg-emerald-50 p-2 rounded-lg border border-emerald-200">
                    ✓ {pushStatus}
                  </p>
                )}
              </div>

              {/* 1-Click Instant Teammate Mirror & Sync */}
              <div className="bg-gradient-to-r from-blue-50 to-indigo-50/60 rounded-2xl p-5 border border-blue-200 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-600 text-white flex items-center justify-center font-bold">
                      <Share2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h5 className="font-bold text-xs text-slate-900">
                        1-Click Team Member Sync & Dashboard Mirror
                      </h5>
                      <p className="text-[11px] text-slate-600">
                        Instantly share your active hyfunfoods requirements & company masters with your teammate
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      try {
                        const raw = exportTeamSyncSnapshot();
                        const token = btoa(unescape(encodeURIComponent(raw)));
                        setTeamSyncCode(token);
                        navigator.clipboard?.writeText(token);
                        setCopiedSyncCode(true);
                        setTimeout(() => setCopiedSyncCode(false), 3000);
                        setTeamSyncStatus('✓ 1-Click Sync Token copied to clipboard! Send it to your teammate via Chat / Email.');
                        setTimeout(() => setTeamSyncStatus(null), 5000);
                      } catch (err: any) {
                        setTeamSyncStatus(`Could not copy: ${err.message}`);
                      }
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs shadow-xs transition-all"
                  >
                    {copiedSyncCode ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedSyncCode ? 'Copied to Clipboard!' : 'Copy 1-Click Sync Code'}</span>
                  </button>
                </div>

                {teamSyncStatus && (
                  <div className="p-2.5 rounded-xl text-xs font-bold bg-white text-blue-800 border border-blue-300 shadow-2xs">
                    {teamSyncStatus}
                  </div>
                )}

                <div className="pt-2 border-t border-blue-200/80">
                  <label className="block text-[11px] font-bold text-slate-700 mb-1.5">
                    Teammate: Paste 1-Click Sync Code to mirror this dashboard instantly:
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={pasteSyncInput}
                      onChange={(e) => setPasteSyncInput(e.target.value)}
                      placeholder="Paste the Sync Code received from team member..."
                      className="flex-1 px-3 py-2 bg-white border border-blue-200 rounded-xl text-xs font-mono outline-none focus:ring-2 focus:ring-blue-500"
                    />
                    <button
                      onClick={() => {
                        if (!pasteSyncInput.trim()) return;
                        try {
                          let decoded = pasteSyncInput.trim();
                          if (!decoded.startsWith('{')) {
                            decoded = decodeURIComponent(escape(atob(decoded)));
                          }
                          const res = importTeamSyncSnapshot(decoded);
                          setTeamSyncStatus(res.message);
                          setPasteSyncInput('');
                          setTimeout(() => setTeamSyncStatus(null), 5000);
                        } catch (e: any) {
                          setTeamSyncStatus(`Sync failed: ${e.message}`);
                        }
                      }}
                      disabled={!pasteSyncInput.trim()}
                      className="px-4 py-2 bg-slate-900 hover:bg-black text-white rounded-xl font-bold text-xs disabled:opacity-40 transition-all shadow-xs"
                    >
                      Apply Sync
                    </button>
                  </div>
                  <p className="text-[10px] text-slate-500 mt-1.5">
                    Tip: Remind your teammate to click <span className="font-bold text-blue-700">"1. Requirements (REQ)"</span> in the left sidebar to view the Requirement Register.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: Architecture Explanation */}
          {activeTab === 'how-it-works' && (
            <div className="space-y-4 leading-relaxed">
              <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex gap-3 text-amber-900">
                <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-xs">Why Was Data Previously Staying Only On Your Laptop?</h4>
                  <p className="text-[11px] mt-1 text-amber-800">
                    The software previously had a "Demo Sandbox Mode" vs "My Local Business Mode" switch. In Local Business mode, records were saved exclusively inside your browser's private <code className="bg-amber-100 px-1 py-0.5 rounded font-mono font-bold">localStorage (mro_biz_*)</code> without automatically pushing to the central server database. When another employee opened the ERP on their laptop, their browser only saw its own local storage, so your changes were not visible to them.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 flex gap-3 text-emerald-900">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-xs">How It Works Now (Live Central Cloud Architecture)</h4>
                  <p className="text-[11px] mt-1 text-emerald-800">
                    We converted the entire application into a <strong>Single Unified Live Production Cloud ERP</strong>:
                  </p>
                  <ul className="list-disc list-inside mt-2 space-y-1 text-[11px] text-emerald-800/90">
                    <li><strong>Single Central Database:</strong> All entries (Customers, Vendors, Product Types, Quotations, RFQs, POs, Invoices, Deliveries) write to the authoritative backend on disk (<code className="bg-emerald-100 px-1 rounded font-mono">data/erp_production.json</code>).</li>
                    <li><strong>3-Second Real-Time Heartbeat:</strong> Every open laptop, mobile device, or browser polls the central server every 3 seconds to pull any changes made by other team members.</li>
                    <li><strong>Instant Focus & Tab Sync:</strong> The moment a colleague unlocks their laptop, focuses the tab, or opens the app, the latest state is immediately fetched and displayed.</li>
                    <li><strong>Zero Data Loss:</strong> Any data previously saved on your laptop under local business mode has been automatically migrated into the live shared cloud database.</li>
                  </ul>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                    <Laptop className="w-4 h-4 text-blue-600" />
                    <span>Laptop A (You - Admin)</span>
                  </span>
                  <p className="text-[11px] text-slate-600">
                    Adds product type "MCB" or creates Customer Quotation → Instantly committed to Central Cloud Backend.
                  </p>
                </div>

                <div className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 space-y-1">
                  <span className="font-bold text-slate-800 flex items-center gap-1.5 text-xs">
                    <Laptop className="w-4 h-4 text-emerald-600" />
                    <span>Laptop B (Colleague / Other User)</span>
                  </span>
                  <p className="text-[11px] text-slate-600">
                    Receives real-time update automatically within seconds → Same "MCB" and Quotation appear immediately.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Backup & Export */}
          {activeTab === 'backup' && (
            <div className="space-y-4">
              <p className="text-slate-600 text-xs">
                Download a complete, offline JSON snapshot of the company database or restore from a previously downloaded backup.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between space-y-3">
                  <div>
                    <h5 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                      <Download className="w-4 h-4 text-blue-600" />
                      <span>Export Full Company Database</span>
                    </h5>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Downloads an exact snapshot of all customers, suppliers, master catalog, RFQs, quotations, and POs as an offline JSON file.
                    </p>
                  </div>
                  <button
                    onClick={exportFullBackup}
                    className="w-full py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 text-xs shadow-xs transition-all"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download JSON Backup</span>
                  </button>
                </div>

                <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col justify-between space-y-3">
                  <div>
                    <h5 className="font-bold text-slate-800 text-xs flex items-center gap-1.5">
                      <Upload className="w-4 h-4 text-emerald-600" />
                      <span>Restore from Backup File</span>
                    </h5>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Upload a previously exported JSON backup file to restore records into the database.
                    </p>
                  </div>
                  <label className="w-full py-2 bg-slate-800 hover:bg-slate-900 text-white rounded-xl font-bold flex items-center justify-center gap-1.5 text-xs shadow-xs cursor-pointer transition-all">
                    <Upload className="w-4 h-4" />
                    <span>Choose JSON Backup File</span>
                    <input
                      type="file"
                      accept=".json,application/json"
                      onChange={handleFileRestore}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {restoreStatus && (
                <div className={`p-3 rounded-xl text-xs font-bold ${
                  restoreStatus.startsWith('Error')
                    ? 'bg-red-50 text-red-700 border border-red-200'
                    : 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                }`}>
                  {restoreStatus}
                </div>
              )}

              <div className="pt-2">
                <label className="block text-slate-700 font-bold text-xs mb-1">
                  Or Paste Raw JSON Backup Text:
                </label>
                <textarea
                  value={restoreText}
                  onChange={(e) => setRestoreText(e.target.value)}
                  placeholder="Paste JSON database snapshot here..."
                  rows={3}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-[11px] focus:bg-white focus:ring-1 focus:ring-emerald-500 outline-none"
                />
                <button
                  onClick={handleTextRestore}
                  disabled={!restoreText.trim()}
                  className="mt-2 px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white rounded-lg text-xs font-bold disabled:opacity-40 transition-all"
                >
                  Apply Pasted Backup
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>MRO Procurement Solution Enterprise Database v2.6</span>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl text-xs transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
