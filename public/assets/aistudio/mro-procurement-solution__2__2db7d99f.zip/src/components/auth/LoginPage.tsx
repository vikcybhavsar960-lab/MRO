import React, { useState } from 'react';
import {
  Building2,
  Lock,
  Mail,
  Eye,
  EyeOff,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  KeyRound,
  Sparkles,
  Users,
  Briefcase,
  ChevronRight,
  Globe2,
  FileCheck2,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { User, UserRole } from '../../types';
import { fetchApi } from '../../utils/apiClient';

interface LoginPageProps {
  onLoginSuccess: () => void;
}

interface DemoCredential {
  id: string;
  name: string;
  roleTitle: string;
  badgeColor: string;
  email: string;
  password: string;
  role: UserRole;
  description: string;
}

const DEMO_ACCOUNTS: DemoCredential[] = [
  {
    id: 'USR-001',
    name: 'Vikram Bhavsar',
    roleTitle: 'Super Admin',
    badgeColor: 'bg-red-50 text-red-700 border-red-200',
    email: 'vickybhavsar960@gmail.com',
    password: 'Admin@123',
    role: 'SUPER_ADMIN',
    description: 'Full administrative access across RFQ, Vendors, Quotations, Settings & Audit',
  },
  {
    id: 'USR-002',
    name: 'Suresh Patil',
    roleTitle: 'Purchase Manager',
    badgeColor: 'bg-blue-50 text-blue-700 border-blue-200',
    email: 'suresh.patil@procuremro.com',
    password: 'Purchase@123',
    role: 'PROCUREMENT_EMPLOYEE',
    description: 'Manages vendor sourcing, RFQ enquiries, product rate comparison and vendor POs',
  },
  {
    id: 'USR-003',
    name: 'Anjali Deshmukh',
    roleTitle: 'Lead Approver',
    badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
    email: 'anjali.d@procuremro.com',
    password: 'Approver@123',
    role: 'SUPER_ADMIN',
    description: 'Senior governance, high-value commercial sanctions and margin approvals',
  },
  {
    id: 'USR-004',
    name: 'Pooja Iyer',
    roleTitle: 'Accounts Lead',
    badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    email: 'pooja.i@procuremro.com',
    password: 'Accounts@123',
    role: 'ACCOUNTS_USER',
    description: 'Finance lead, vendor bills, proforma invoices, GST compliance & payments',
  },
];

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const { setCurrentUser, availableUsers } = useApp();

  const [usernameOrEmail, setUsernameOrEmail] = useState('vickybhavsar960@gmail.com');
  const [password, setPassword] = useState('Admin@123');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!usernameOrEmail.trim()) {
      setErrorMessage('Please enter your email or username');
      return;
    }
    if (!password.trim()) {
      setErrorMessage('Please enter your account password');
      return;
    }

    setIsLoading(true);
    setErrorMessage('');
    setSuccessMessage('');

    try {
      const response = await fetchApi('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: usernameOrEmail.trim(),
          password: password.trim(),
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setErrorMessage(data.error || 'Authentication failed. Please verify credentials.');
        setIsLoading(false);
        return;
      }

      // Find matching user from available users or construct one
      const matchedUser =
        availableUsers.find(
          (u) =>
            u.email.toLowerCase() === (data.user?.email || '').toLowerCase() ||
            u.name.toLowerCase() === (data.user?.name || '').toLowerCase() ||
            u.id === data.user?.id
        ) || {
          id: data.user?.id || 'USR-001',
          name: data.user?.name || usernameOrEmail,
          email: data.user?.email || usernameOrEmail,
          role: (data.user?.role?.toUpperCase().replace(/\s+/g, '_') as UserRole) || 'SUPER_ADMIN',
          department: data.user?.department || 'Operations',
          mobile: data.user?.mobile || '+91 98250 12345',
        };

      setCurrentUser(matchedUser);

      if (data.sessionId) {
        localStorage.setItem('mro_current_session_id', data.sessionId);
      }
      localStorage.removeItem('mro_is_logged_out');
      if (rememberMe) {
        localStorage.setItem('mro_remember_user', matchedUser.email);
      }

      setSuccessMessage(`Welcome back, ${matchedUser.name}! Opening ERP...`);
      setTimeout(() => {
        onLoginSuccess();
      }, 400);
    } catch (err: any) {
      setErrorMessage('Login request failed: ' + (err.message || 'Server connection error'));
      setIsLoading(false);
    }
  };

  const handleQuickPersonaSelect = (acc: DemoCredential) => {
    setUsernameOrEmail(acc.email);
    setPassword(acc.password);
    setErrorMessage('');
  };

  const handleQuickSignIn = async (acc: DemoCredential) => {
    setUsernameOrEmail(acc.email);
    setPassword(acc.password);
    setIsLoading(true);
    setErrorMessage('');

    try {
      const response = await fetchApi('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: acc.email,
          password: acc.password,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        setErrorMessage(data.error || 'Quick login failed');
        setIsLoading(false);
        return;
      }

      const matchedUser =
        availableUsers.find((u) => u.email.toLowerCase() === acc.email.toLowerCase()) || {
          id: acc.id,
          name: acc.name,
          email: acc.email,
          role: acc.role,
          department: 'Procurement',
          mobile: '+91 98250 12345',
        };

      setCurrentUser(matchedUser);
      if (data.sessionId) {
        localStorage.setItem('mro_current_session_id', data.sessionId);
      }
      localStorage.removeItem('mro_is_logged_out');

      setSuccessMessage(`Logged in as ${acc.name}. Launching ERP...`);
      setTimeout(() => {
        onLoginSuccess();
      }, 300);
    } catch (err: any) {
      setErrorMessage('Quick login failed: ' + (err.message || 'Network error'));
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col justify-between text-slate-100 selection:bg-blue-600 selection:text-white">
      {/* Background Ambience */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl" />
        <div className="absolute top-1/2 -right-40 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 left-1/3 w-96 h-96 bg-sky-600/10 rounded-full blur-3xl" />
      </div>

      {/* Top Header Bar */}
      <header className="relative z-10 w-full border-b border-slate-800/80 bg-slate-900/60 backdrop-blur-md px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-lg shadow-blue-500/25">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-white text-base tracking-tight">
                MRO <span className="text-blue-400">PROCUREMENT SOLUTION</span>
              </span>
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-blue-500/10 text-blue-300 rounded border border-blue-500/30">
                Enterprise ERP
              </span>
            </div>
            <p className="text-xs text-slate-400 hidden sm:block">
              Industrial Procurement Management & Multi-User Cloud Platform
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-400">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span className="hidden sm:inline">256-Bit SSL Encrypted ERP Session</span>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Column: Login Card */}
          <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl">
            <div className="mb-6">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-semibold mb-3">
                <Lock className="w-3.5 h-3.5" />
                <span>Authorized Staff Login</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                Sign in to your ERP Portal
              </h1>
              <p className="text-sm text-slate-400 mt-1.5">
                Enter your registered corporate email or username and password to access requirements, RFQs, vendor rates, and orders.
              </p>
            </div>

            {/* Error & Success Messages */}
            {errorMessage && (
              <div className="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-start gap-3">
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-400 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold">Authentication Error</p>
                  <p className="text-xs text-rose-300/90 mt-0.5">{errorMessage}</p>
                </div>
              </div>
            )}

            {successMessage && (
              <div className="mb-5 p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-sm flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
                <span className="font-medium">{successMessage}</span>
              </div>
            )}

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              {/* Username/Email Input */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5">
                  Corporate Email or Username
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={usernameOrEmail}
                    onChange={(e) => setUsernameOrEmail(e.target.value)}
                    placeholder="e.g. vickybhavsar960@gmail.com or admin"
                    autoComplete="username"
                    required
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-950/70 border border-slate-700 rounded-xl text-white text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
                  />
                </div>
              </div>

              {/* Password Input */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider">
                    Password
                  </label>
                  <span className="text-[11px] text-blue-400 font-medium">Default: Admin@123</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                    <KeyRound className="w-4 h-4" />
                  </div>
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your account password"
                    autoComplete="current-password"
                    required
                    className="w-full pl-10 pr-11 py-2.5 bg-slate-950/70 border border-slate-700 rounded-xl text-white text-sm placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-white transition-colors"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember Me & Help */}
              <div className="flex items-center justify-between pt-1 text-xs">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300 select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 rounded border-slate-700 bg-slate-950 text-blue-600 focus:ring-blue-500 focus:ring-offset-slate-900"
                  />
                  <span>Keep me signed in on this workstation</span>
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setUsernameOrEmail('vickybhavsar960@gmail.com');
                    setPassword('Admin@123');
                    setErrorMessage('');
                  }}
                  className="text-blue-400 hover:text-blue-300 font-medium underline underline-offset-2"
                >
                  Reset to Super Admin
                </button>
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 hover:shadow-blue-600/50 flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                >
                  {isLoading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Authenticating Credentials...</span>
                    </>
                  ) : (
                    <>
                      <span>Sign In with Password</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </form>

            {/* Quick Guest Bypass option for effortless development/testing */}
            <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
              <span>Testing without typing?</span>
              <button
                type="button"
                onClick={() => onLoginSuccess()}
                className="text-slate-300 hover:text-white font-semibold flex items-center gap-1 hover:underline cursor-pointer"
              >
                <span>Enter ERP Directly</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right Column: 1-Click Role Accounts & System Status */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-md">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 text-blue-400" />
                  <h2 className="text-sm font-bold text-white tracking-wide">
                    1-Click Test Personas (RBAC)
                  </h2>
                </div>
                <span className="text-[10px] font-bold text-slate-400 bg-slate-800 px-2 py-0.5 rounded">
                  Instant Login
                </span>
              </div>
              <p className="text-xs text-slate-400 mb-3.5">
                Click any role card below to instantly sign in and test permissions, modules, and approval workflows:
              </p>

              <div className="space-y-2">
                {DEMO_ACCOUNTS.map((acc) => (
                  <div
                    key={acc.id}
                    className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 hover:border-blue-500/40 hover:bg-slate-900 transition-all flex items-center justify-between group"
                  >
                    <div className="flex-1 min-w-0 pr-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-white truncate">{acc.name}</span>
                        <span className={`text-[9px] font-bold px-1.5 py-0.2 rounded border ${acc.badgeColor}`}>
                          {acc.roleTitle}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-400 font-mono truncate mt-0.5">{acc.email}</p>
                      <p className="text-[10px] text-slate-400 truncate mt-0.5">{acc.description}</p>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleQuickPersonaSelect(acc)}
                        title="Fill in credentials"
                        className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium transition-colors"
                      >
                        Fill
                      </button>
                      <button
                        type="button"
                        onClick={() => handleQuickSignIn(acc)}
                        title="Sign in immediately"
                        className="px-2.5 py-1 rounded bg-blue-600 hover:bg-blue-500 text-white text-[11px] font-bold flex items-center gap-1 shadow transition-colors"
                      >
                        <span>Login</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Platform Trust Highlights */}
            <div className="bg-slate-900/40 border border-slate-800/60 rounded-xl p-4 text-xs text-slate-400 space-y-2">
              <div className="flex items-center gap-2 text-slate-300 font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>Enterprise Grade Security & Persistence</span>
              </div>
              <ul className="space-y-1.5 text-[11px] text-slate-400">
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                  <span>PBKDF2 SHA-512 password encryption with salt</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                  <span>Real-time IP & device security audit trail logs</span>
                </li>
                <li className="flex items-center gap-2">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
                  <span>Permanent database protection – no accidental wipeouts</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 w-full border-t border-slate-800/80 bg-slate-900/60 backdrop-blur-md px-6 py-3 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-2">
        <p>© 2026 MRO Procurement Solution. All rights reserved.</p>
        <div className="flex items-center gap-4 text-[11px]">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>Central Cloud Database Active</span>
          </span>
          <span>•</span>
          <span>Dual Deployment Sync</span>
        </div>
      </footer>
    </div>
  );
};
