import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  User,
  UserRole,
  DataMode,
  Customer,
  Vendor,
  ProductItem,
  MaterialCategory,
  CustomerRequirement,
  VendorEnquiry,
  VendorQuote,
  CustomerQuotation,
  CustomerPO,
  VendorPO,
  ProformaInvoice,
  PaymentRecord,
  DispatchRecord,
  DeliveryRecord,
  NotificationItem,
  AuditLogItem,
  DocumentRecord,
  OrderWorkflowStage,
  RequirementItem,
  BackupRecord,
  BackupSettings,
  VendorCatalogFile,
  VendorCatalogProduct,
  VendorMaterialCategory,
  AIActivityLog,
  BrandMasterItem,
  Company,
  PurchaseExecutive,
  VendorProductMapping,
  ProductTypeMasterItem,
  ParsedVendorProduct,
} from '../types';
import { getBrandEnrichment } from '../utils/brandAutoEnrichment';
import { analyzeVendorCatalog, detectDuplicateProduct } from '../services/aiCatalogService';
import { exportDataToJSON } from '../services/dataExportService';
import { INITIAL_MATERIAL_CATEGORIES } from '../data/categoryMasterData';
import { INITIAL_BRANDS } from '../data/brandMasterData';
import { INITIAL_COMPANIES, INITIAL_PURCHASE_EXECUTIVES } from '../data/companyMasterData';
import {
  getSavedBackups,
  getBackupSettings,
  createBackupSnapshot,
  testBackupIntegrity,
  getActiveBackupFailure,
  clearBackupFailure,
} from '../services/backupRecoveryService';
import { recommendCategoryForRequirement, recommendVendorsForRequirement } from '../services/categoryMatchingService';
import {
  INITIAL_USERS,
  INITIAL_CUSTOMERS,
  INITIAL_VENDORS,
  INITIAL_PRODUCTS,
  INITIAL_REQUIREMENT_001,
  INITIAL_RFQ_001,
  INITIAL_VENDOR_QUOTES_001,
  INITIAL_CUSTOMER_QUOTATION_001,
  INITIAL_CUSTOMER_PO_001,
  INITIAL_VENDOR_PO_001,
  INITIAL_PROFORMA_INVOICE_001,
  INITIAL_PAYMENT_001,
  INITIAL_DISPATCH_001,
  INITIAL_DELIVERY_001,
  INITIAL_REQUIREMENT_002,
  INITIAL_RFQ_002,
  INITIAL_VENDOR_QUOTES_002,
  INITIAL_CUSTOMER_QUOTATION_002,
  INITIAL_CUSTOMER_PO_002,
  INITIAL_VENDOR_PO_002,
  INITIAL_PROFORMA_INVOICE_002,
  INITIAL_PAYMENT_002,
  INITIAL_DISPATCH_002,
  INITIAL_DELIVERY_002,
  INITIAL_REQUIREMENT_003,
  INITIAL_RFQ_003,
  INITIAL_VENDOR_QUOTES_003,
  INITIAL_REQUIREMENT_004,
  INITIAL_NOTIFICATIONS,
  INITIAL_AUDIT_LOGS,
  INITIAL_DOCUMENTS,
} from '../data/mockData';
import { fetchApi, PRODUCTION_BACKEND_URL } from '../utils/apiClient';
import { syncAccountingWithBackend } from '../services/accountingService';

interface AppContextType {
  currentUser: User;
  setCurrentUser: (user: User) => void;
  availableUsers: User[];
  isMobileView: boolean;
  setIsMobileView: (val: boolean) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedOrderId: string | null;
  setSelectedOrderId: (id: string | null) => void;

  // Data Collections
  customers: Customer[];
  companies: Company[];
  purchaseExecutives: PurchaseExecutive[];
  vendors: Vendor[];
  products: ProductItem[];
  requirements: CustomerRequirement[];
  rfqs: VendorEnquiry[];
  vendorQuotes: VendorQuote[];
  customerQuotations: CustomerQuotation[];
  customerPOs: CustomerPO[];
  vendorPOs: VendorPO[];
  proformaInvoices: ProformaInvoice[];
  payments: PaymentRecord[];
  dispatches: DispatchRecord[];
  deliveries: DeliveryRecord[];
  notifications: NotificationItem[];
  auditLogs: AuditLogItem[];
  documents: DocumentRecord[];

  // Action methods
  addCustomer: (cust: Omit<Customer, 'id' | 'createdAt'>) => Customer;
  addCompany: (comp: Omit<Company, 'id' | 'createdAt' | 'companyCode'>) => Company;
  updateCompany: (comp: Company) => void;
  deleteCompany: (id: string) => { success: boolean; message: string };
  addPurchaseExecutive: (exec: Omit<PurchaseExecutive, 'id' | 'createdAt'>) => PurchaseExecutive;
  updatePurchaseExecutive: (exec: PurchaseExecutive) => void;
  deletePurchaseExecutive: (id: string) => { success: boolean; message: string };
  getExecutivesByCompany: (companyId: string) => PurchaseExecutive[];
  addVendor: (vend: Omit<Vendor, 'id' | 'createdAt'>) => Vendor;
  addProduct: (prd: Omit<ProductItem, 'id'>) => ProductItem;
  addRequirement: (req: {
    customerId: string;
    customerName: string;
    contactPerson: string;
    customerEmail: string;
    customerMobile: string;
    requirementDate: string;
    requiredDeliveryDate: string;
    receivedRequirementDate?: string;
    expectedDeliveryDate?: string;
    priority?: 'High' | 'Medium' | 'Low';
    items: Omit<RequirementItem, 'id'>[];
    remarks?: string;
    companyId?: string;
    companyName?: string;
    companyCode?: string;
    purchaseExecutiveId?: string;
    purchaseExecutiveName?: string;
    purchaseExecutiveDesignation?: string;
    purchaseExecutiveMobile?: string;
    purchaseExecutiveEmail?: string;
    rfqNumber?: string;
    requirementSource?: 'Email' | 'WhatsApp' | 'Phone' | 'Manual' | 'Other' | string;
    referenceNumber?: string;
  }) => CustomerRequirement;
  updateRequirement: (req: CustomerRequirement) => void;
  deleteRequirement: (id: string, reason?: string) => { success: boolean; message: string };
  restoreRequirement: (id: string) => { success: boolean; message: string };
  sendVendorEnquiry: (requirementId: string, vendorIds: string[], notes?: string) => VendorEnquiry;
  submitVendorQuote: (quote: {
    id?: string;
    enquiryId?: string;
    requirementId: string;
    customerName?: string;
    vendorId: string;
    vendorName: string;
    items: any[];
    validUntil?: string;
    paymentTerms?: string;
    remarks?: string;
    attachmentName?: string;
  }) => VendorQuote;
  updateVendorQuote: (quote: VendorQuote) => VendorQuote;
  deleteVendorQuote: (id: string) => { success: boolean; message?: string };
  getRateCompletionStatus: (requirementId: string) => {
    status: 'COMPLETED' | 'PARTIALLY_COMPLETED' | 'PENDING';
    totalItems: number;
    quotedItemsCount: number;
    missingItems: RequirementItem[];
    quotesCount: number;
    quotes: VendorQuote[];
  };
  createCustomerQuotation: (quoteData: any) => CustomerQuotation;
  recordCustomerPO: (poData: {
    quotationId: string;
    requirementId: string;
    customerPoNumber: string;
    poDate: string;
    customerId: string;
    customerName: string;
    poAmount: number;
    deliveryAddress: string;
    paymentTerms: string;
    remarks?: string;
  }) => CustomerPO;
  createVendorPO: (vpoData: {
    customerPoId: string;
    quotationId: string;
    requirementId: string;
    vendorId: string;
    vendorName: string;
    items: any[];
    subtotal: number;
    gstAmount: number;
    freight: number;
    totalAmount: number;
    deliveryAddress: string;
    deliveryDate: string;
    paymentTerms: string;
    remarks?: string;
  }) => VendorPO;
  submitProformaInvoice: (piData: {
    vendorPoId: string;
    requirementId: string;
    vendorId: string;
    vendorName: string;
    piNumber: string;
    piDate: string;
    amount: number;
    gstAmount: number;
    freight: number;
    totalAmount: number;
    bankDetails: string;
    paymentDueDate: string;
    remarks?: string;
  }) => ProformaInvoice;
  recordPayment: (payData: {
    piId: string;
    vendorPoId: string;
    requirementId: string;
    vendorId: string;
    vendorName: string;
    totalPiAmount: number;
    amountPaid: number;
    paymentDate: string;
    paymentMode: any;
    transactionReference: string;
    remarks?: string;
  }) => PaymentRecord;
  recordDispatch: (dspData: {
    vendorPoId: string;
    requirementId: string;
    vendorId: string;
    vendorName: string;
    dispatchDate: string;
    vendorInvoiceNumber: string;
    transporter: string;
    courierName?: string;
    lrNumber: string;
    awbNumber: string;
    trackingNumber: string;
    quantityDispatched: string;
    expectedDeliveryDate: string;
    remarks?: string;
  }) => DispatchRecord;
  updateDeliveryTracking: (delData: {
    dispatchId: string;
    requirementId: string;
    deliveryDate: string;
    receivedBy: string;
    customerAcknowledgement: string;
    status: any;
    remarks?: string;
  }) => DeliveryRecord;
  closeOrder: (requirementId: string, remarks?: string) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: () => void;
  pushNotification: (
    title: string,
    message: string,
    type?: 'INFO' | 'SUCCESS' | 'WARNING' | 'ACTION_REQUIRED',
    targetRole?: UserRole[],
    linkTab?: string,
    linkId?: string
  ) => void;
  addDocument: (doc: Omit<DocumentRecord, 'id' | 'uploadedAt'>) => void;
  getLinkedOrderData: (requirementId: string) => any;

  // Dual Data Mode (Local Business vs Demo Sandbox)
  dataMode: DataMode;
  setDataMode: (mode: DataMode) => void;
  copyDemoToLocalBusiness: () => void;
  resetCurrentModeData: () => void;
  exportFullBackup: () => void;
  restoreFullBackup: (jsonContent: string) => boolean;

  // Master Data CRUD & Import
  updateCustomer: (customer: Customer) => void;
  deleteCustomer: (id: string) => void;
  importCustomersList: (newCusts: (Omit<Customer, 'id' | 'createdAt'> | Customer)[]) => any;
  updateVendor: (vendor: Vendor) => void;
  deleteVendor: (id: string, reason?: string) => void;
  restoreVendor: (id: string) => Promise<boolean>;
  permanentlyDeleteVendor: (id: string) => Promise<boolean>;
  purgeArchivedVendors: () => Promise<{ success: boolean; count: number }>;
  importVendorsList: (newVends: (Omit<Vendor, 'id' | 'createdAt'> | Vendor)[]) => any;
  updateProduct: (product: ProductItem) => void;
  deleteProduct: (id: string, reason?: string) => void;
  restoreProduct: (id: string) => Promise<boolean>;
  importProductsList: (newProds: (Omit<ProductItem, 'id'> | ProductItem)[]) => any;

  // Commercial Rules & Earning Open/Lock
  lockQuotationCommercials: (quotationId: string, remarks?: string) => void;
  unlockQuotationCommercials: (quotationId: string, reason: string) => void;

  // Category Master & Vendor Matching
  categories: MaterialCategory[];
  addCategory: (cat: Omit<MaterialCategory, 'id' | 'createdAt' | 'updatedAt'>) => MaterialCategory;
  updateCategory: (cat: MaterialCategory) => void;
  deleteCategory: (id: string) => { success: boolean; message: string };
  toggleCategoryStatus: (id: string) => void;
  addKeywordToCategory: (categoryId: string, keyword: string) => void;
  bulkImportRequirements: (newRequirements: Omit<CustomerRequirement, 'id' | 'createdAt'>[]) => number;
  assignVendorToRequirementItem: (requirementId: string, itemId: string, vendorId: string, vendorName: string) => void;

  // Brand Master (Multiple Brands per Vendor & Brand Registry)
  brands: BrandMasterItem[];
  addBrand: (brand: Omit<BrandMasterItem, 'id' | 'createdAt'>) => BrandMasterItem;
  updateBrand: (brand: BrandMasterItem) => void;
  deleteBrand: (id: string) => { success: boolean; message: string };
  registerVendorBrands: (brandNames: string[]) => void;

  // AI Vendor Catalog Analyzer & Learning
  aiActivityLogs: AIActivityLog[];
  analyzeVendorCatalogFiles: (vendorId: string, files: Array<{ name: string; type: string; size?: number; textContent?: string }>) => Promise<number>;
  approveVendorMaterialCategory: (vendorId: string, categoryId: string) => void;
  rejectVendorMaterialCategory: (vendorId: string, categoryId: string) => void;
  editVendorMaterialCategory: (vendorId: string, categoryId: string, updated: Partial<VendorMaterialCategory>) => void;
  approveAllVendorMaterialCategories: (vendorId: string) => void;
  approveVendorCatalogProduct: (vendorId: string, productId: string) => void;
  rejectVendorCatalogProduct: (vendorId: string, productId: string) => void;
  learnCategoryFromVendorQuotation: (vendorId: string, categoryName: string, subCategoryName?: string, sourceDoc?: string) => void;
  deleteVendorCatalogFile: (vendorId: string, fileId: string) => void;
  saveCatalogAnalysisToVendor: (
    vendorId: string,
    payload: {
      catalogFile?: any;
      catalogProducts?: any[];
      suggestedCategories?: any[];
      vendorProfile?: any;
    }
  ) => Promise<boolean>;

  // Products & Materials Supplied Master Registry
  vendorProductMappings: VendorProductMapping[];
  addVendorProductMapping: (mapping: Omit<VendorProductMapping, 'id' | 'createdAt'>) => Promise<VendorProductMapping>;
  updateVendorProductMapping: (mapping: VendorProductMapping) => Promise<void>;
  deleteVendorProductMapping: (id: string) => Promise<void>;
  bulkAddVendorProductMappings: (
    vendorId: string,
    mappings: Partial<VendorProductMapping>[]
  ) => Promise<{ added: number; updated: number; skipped: number }>;

  // Global Product Type Master & One-Click Vendor Linking
  productTypes: ProductTypeMasterItem[];
  addProductTypeToMaster: (name: string, category?: string) => Promise<ProductTypeMasterItem>;
  addProductTypeToVendor: (
    vendorId: string,
    productTypeName: string,
    category?: string,
    brand?: string
  ) => Promise<{ productType: ProductTypeMasterItem; mapping: VendorProductMapping }>;
  removeProductTypeFromVendor: (mappingId: string) => Promise<void>;

  // Automated Cloud Backup & Recovery
  backups: BackupRecord[];
  backupSettings: BackupSettings;
  updateBackupSettings: (settings: Partial<BackupSettings>) => void;
  triggerManualBackup: () => BackupRecord;
  restoreFromBackupRecord: (backupId: string) => boolean;
  testBackupRecord: (backupId: string) => { valid: boolean; message: string; details: any };
  backupFailureAlert: { timestamp: string; error: string } | null;
  clearBackupFailureAlert: () => void;

  // User Management & Access Control (Admin Module)
  addUser: (userData: Omit<User, 'id' | 'createdAt'>) => User;
  updateUser: (user: User) => void;
  deleteUser: (id: string) => { success: boolean; message: string };
  toggleUserStatus: (id: string) => void;
  resetUserPassword: (id: string, tempPass?: string) => { success: boolean; message: string; tempPass: string };
  changeUserPassword: (userId: string, currentPass: string, newPass: string) => { success: boolean; message: string };
  updateUserPermissions: (userId: string, permissions: NonNullable<User['permissions']>, approvalLimit?: number) => void;
  syncBackendNow: () => Promise<void>;
  pushDeviceDataToCentralDb: () => Promise<{ success: boolean; message: string }>;
  exportTeamSyncSnapshot: () => string;
  importTeamSyncSnapshot: (raw: string) => { success: boolean; count: number; message: string };
  isSyncing: boolean;
  lastSyncTime: Date;
  isOnline: boolean;
}

// Default starter items for Local Business Mode (Clean starter slate)
const INITIAL_LOCAL_CUSTOMERS: Customer[] = [
  {
    id: 'CUST-001',
    companyName: 'Apex Industrial Technologies Pvt Ltd',
    contactPerson: 'Suresh Patil (Procurement Head)',
    mobile: '+91 98201 44552',
    email: 'procurement@apexind.com',
    address: 'Plot 42, Hinjewadi Phase 2, Pune',
    city: 'Pune',
    state: 'Maharashtra',
    pincode: '411057',
    gstin: '27AABCA1234F1ZX',
    pan: 'AABCA1234F',
    paymentTerms: '30 Days Net',
    deliveryAddress: 'Central Receiving Dock, Unit 2, Hinjewadi',
    remarks: 'Private Local Business Account',
    createdAt: '2026-09-20',
  },
];

const INITIAL_LOCAL_VENDORS: Vendor[] = [
  {
    id: 'VEND-001',
    companyName: 'Precision Engineering & Bearings Co.',
    contactPerson: 'Ramesh Mehta',
    mobile: '+91 98920 11223',
    email: 'sales@precisionbearing.in',
    address: '14, Industrial Area, Sector 5, Bhosari',
    city: 'Pune',
    state: 'Maharashtra',
    gstin: '27AAACP9988D1Z8',
    pan: 'AAACP9988D',
    bankDetails: {
      accountName: 'Precision Engineering & Bearings Co.',
      accountNumber: '50200088991122',
      bankName: 'ICICI Bank',
      ifscCode: 'ICIC0000104',
      branch: 'Bhosari Pune',
    },
    paymentTerms: '50% Advance, Balance on LR',
    deliveryTerms: 'Door Delivery',
    productCategories: ['Bearings', 'Power Transmission', 'Shafts'],
    brandsSupplied: ['SKF', 'Timken', 'FAG'],
    rating: 4.9,
    remarks: 'Preferred Local Channel Partner',
    createdAt: '2026-09-20',
  },
];

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const saved = localStorage.getItem('procure_user');
    return saved ? JSON.parse(saved) : INITIAL_USERS[0]; // Default to Super Admin
  });

  const [isMobileView, setIsMobileView] = useState<boolean>(() => {
    return window.innerWidth < 768;
  });

  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);

  // Active Data Mode: Unified Live Enterprise Cloud Database across all company laptops & users
  const [dataMode, setDataModeState] = useState<DataMode>(() => {
    return 'LIVE_ENTERPRISE' as DataMode;
  });

  const getStoragePrefix = (_mode?: DataMode) => 'erp_live_';

  // Helper to load collection with auto-migration from previous local business or demo stores
  const loadCollection = <T,>(keySuffix: string, _mode: DataMode, fallback: T): T => {

    // 1. Authoritative central live cache
    const live = localStorage.getItem(`erp_live_${keySuffix}`);
    if (live) {
      try {
        const parsed = JSON.parse(live);
        if (Array.isArray(parsed) ? parsed.length > 0 : parsed) return parsed;
      } catch {}
    }
    // 2. Migration from user's previous laptop local business store (keeps all existing work safe!)
    const biz = localStorage.getItem(`mro_biz_${keySuffix}`);
    if (biz) {
      try {
        const parsed = JSON.parse(biz);
        if (Array.isArray(parsed) ? parsed.length > 0 : parsed) {
          localStorage.setItem(`erp_live_${keySuffix}`, biz);
          return parsed;
        }
      } catch {}
    }
    // 3. Fallback to previous demo store if present
    const demo = localStorage.getItem(`mro_demo_${keySuffix}`) || localStorage.getItem(`mro_${keySuffix}`);
    if (demo) {
      try {
        const parsed = JSON.parse(demo);
        if (Array.isArray(parsed) ? parsed.length > 0 : parsed) {
          localStorage.setItem(`erp_live_${keySuffix}`, demo);
          return parsed;
        }
      } catch {}
    }
    return fallback;
  };

  // States - Defaulting to authoritative production records across all team laptops
  const [customers, setCustomers] = useState<Customer[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    return loadCollection('customers', initMode, INITIAL_CUSTOMERS);
  });

  const [companies, setCompanies] = useState<Company[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const loaded = loadCollection('companies', initMode, INITIAL_COMPANIES);
    const list = Array.isArray(loaded) && loaded.length > 0 ? loaded : INITIAL_COMPANIES;
    if (!list.some((c) => c.id === 'CMP-001' || c.companyName === 'hyfunfoods')) {
      return [...INITIAL_COMPANIES, ...list.filter((c) => c.id !== 'CMP-001')];
    }
    return list;
  });

  const [purchaseExecutives, setPurchaseExecutives] = useState<PurchaseExecutive[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const loaded = loadCollection('purchase_executives', initMode, INITIAL_PURCHASE_EXECUTIVES);
    const list = Array.isArray(loaded) && loaded.length > 0 ? loaded : INITIAL_PURCHASE_EXECUTIVES;
    if (!list.some((e) => e.companyId === 'CMP-001')) {
      return [...INITIAL_PURCHASE_EXECUTIVES, ...list];
    }
    return list;
  });

  const [vendors, setVendors] = useState<Vendor[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    return loadCollection('vendors', initMode, INITIAL_VENDORS);
  });

  const [products, setProducts] = useState<ProductItem[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    return loadCollection('products', initMode, INITIAL_PRODUCTS);
  });

  const [requirements, setRequirements] = useState<CustomerRequirement[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaultList = [
      INITIAL_REQUIREMENT_001,
      INITIAL_REQUIREMENT_002,
      INITIAL_REQUIREMENT_003,
      INITIAL_REQUIREMENT_004,
    ];
    const loaded = loadCollection('requirements', initMode, defaultList);
    // Load local deleted tombstones if any
    let localDeleted: string[] = [];
    try {
      const stored = localStorage.getItem('erp_deleted_requirements');
      if (stored) localDeleted = JSON.parse(stored);
    } catch {}

    const listToFilter = Array.isArray(loaded) && loaded.length > 0 ? loaded : defaultList;
    const filtered = listToFilter.map((r) => {
      // Guarantee hyfunfoods for REQ-001 and REQ-002
      if (r.id === 'REQ-2026-00001' && (r.customerName?.includes('Tata') || r.companyName?.includes('Tata') || !r.companyName)) {
        return { ...INITIAL_REQUIREMENT_001, ...r, customerName: 'hyfunfoods', companyName: 'hyfunfoods' };
      }
      if (r.id === 'REQ-2026-00002' && (r.customerName?.includes('Larsen') || r.companyName?.includes('Larsen') || !r.companyName)) {
        return { ...INITIAL_REQUIREMENT_002, ...r, customerName: 'hyfunfoods', companyName: 'hyfunfoods' };
      }
      return r;
    });
    return filtered;
  });

  const [rfqs, setRfqs] = useState<VendorEnquiry[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const loaded = loadCollection('rfqs', initMode, [INITIAL_RFQ_001, INITIAL_RFQ_002, INITIAL_RFQ_003]);
    return Array.isArray(loaded) && loaded.length > 0 ? loaded : [INITIAL_RFQ_001, INITIAL_RFQ_002, INITIAL_RFQ_003];
  });

  const [vendorQuotes, setVendorQuotes] = useState<VendorQuote[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaultQuotes = [...INITIAL_VENDOR_QUOTES_001, ...INITIAL_VENDOR_QUOTES_002, ...INITIAL_VENDOR_QUOTES_003];
    const loaded = loadCollection('vendor_quotes', initMode, defaultQuotes);
    return Array.isArray(loaded) && loaded.length > 0 ? loaded : defaultQuotes;
  });

  const [customerQuotations, setCustomerQuotations] = useState<CustomerQuotation[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaultQuotes = [INITIAL_CUSTOMER_QUOTATION_001, INITIAL_CUSTOMER_QUOTATION_002];
    const loaded = loadCollection('quotations', initMode, defaultQuotes);
    return Array.isArray(loaded) && loaded.length > 0 ? loaded : defaultQuotes;
  });

  const [customerPOs, setCustomerPOs] = useState<CustomerPO[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaultPOs = [INITIAL_CUSTOMER_PO_001, INITIAL_CUSTOMER_PO_002];
    const loaded = loadCollection('customer_pos', initMode, defaultPOs);
    return Array.isArray(loaded) && loaded.length > 0 ? loaded : defaultPOs;
  });

  const [vendorPOs, setVendorPOs] = useState<VendorPO[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaultVPOs = [INITIAL_VENDOR_PO_001, INITIAL_VENDOR_PO_002];
    const loaded = loadCollection('vendor_pos', initMode, defaultVPOs);
    return Array.isArray(loaded) && loaded.length > 0 ? loaded : defaultVPOs;
  });

  const [proformaInvoices, setProformaInvoices] = useState<ProformaInvoice[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaultPIs = [INITIAL_PROFORMA_INVOICE_001, INITIAL_PROFORMA_INVOICE_002];
    const loaded = loadCollection('proforma_invoices', initMode, defaultPIs);
    return Array.isArray(loaded) && loaded.length > 0 ? loaded : defaultPIs;
  });

  const [payments, setPayments] = useState<PaymentRecord[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaultPayments = [INITIAL_PAYMENT_001, INITIAL_PAYMENT_002];
    const loaded = loadCollection('payments', initMode, defaultPayments);
    return Array.isArray(loaded) && loaded.length > 0 ? loaded : defaultPayments;
  });

  const [dispatches, setDispatches] = useState<DispatchRecord[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaultDispatches = [INITIAL_DISPATCH_001, INITIAL_DISPATCH_002];
    const loaded = loadCollection('dispatches', initMode, defaultDispatches);
    return Array.isArray(loaded) && loaded.length > 0 ? loaded : defaultDispatches;
  });

  const [deliveries, setDeliveries] = useState<DeliveryRecord[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaultDeliveries = [INITIAL_DELIVERY_001, INITIAL_DELIVERY_002];
    const loaded = loadCollection('deliveries', initMode, defaultDeliveries);
    return Array.isArray(loaded) && loaded.length > 0 ? loaded : defaultDeliveries;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const s = localStorage.getItem('mro_notifications');
    return s ? JSON.parse(s) : INITIAL_NOTIFICATIONS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLogItem[]>(() => {
    const s = localStorage.getItem('mro_audit_logs');
    return s ? JSON.parse(s) : INITIAL_AUDIT_LOGS;
  });

  const [documents, setDocuments] = useState<DocumentRecord[]>(() => {
    const s = localStorage.getItem('mro_documents');
    return s ? JSON.parse(s) : INITIAL_DOCUMENTS;
  });

  const [categories, setCategories] = useState<MaterialCategory[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    return loadCollection('categories', initMode, INITIAL_MATERIAL_CATEGORIES);
  });

  const [brands, setBrands] = useState<BrandMasterItem[]>(() => {
    try {
      const live = localStorage.getItem('erp_live_brands');
      if (live) {
        const parsed = JSON.parse(live);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {}
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    return loadCollection('brands', initMode, INITIAL_BRANDS);
  });

  const [vendorProductMappings, setVendorProductMappings] = useState<VendorProductMapping[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    return loadCollection('vendor_products', initMode, []);
  });

  const [productTypes, setProductTypes] = useState<ProductTypeMasterItem[]>(() => {
    const initMode = (localStorage.getItem('mro_active_data_mode') === 'LOCAL_BUSINESS' ? 'LOCAL_BUSINESS' : 'DEMO') as DataMode;
    const defaults: ProductTypeMasterItem[] = [
      { id: 'PT-001', name: 'MCB', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
      { id: 'PT-002', name: 'MCCB', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
      { id: 'PT-003', name: 'SPD', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
      { id: 'PT-004', name: 'ACB', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
      { id: 'PT-005', name: 'Contactor', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
      { id: 'PT-006', name: 'Overload Relay', category: 'Electrical', createdAt: '2026-01-01T00:00:00.000Z' },
      { id: 'PT-007', name: 'Bearings', category: 'Mechanical and Industrial', createdAt: '2026-01-01T00:00:00.000Z' },
      { id: 'PT-008', name: 'Sensors', category: 'Electronics and Automation', createdAt: '2026-01-01T00:00:00.000Z' },
      { id: 'PT-009', name: 'Valves', category: 'Plumbing, Pipes and Fittings', createdAt: '2026-01-01T00:00:00.000Z' },
      { id: 'PT-010', name: 'Industrial Lubricants', category: 'Paints, Chemicals and Lubricants', createdAt: '2026-01-01T00:00:00.000Z' },
    ];
    return loadCollection('product_types', initMode, defaults);
  });

  useEffect(() => {
    const curPrefix = getStoragePrefix(dataMode);
    localStorage.setItem(`${curPrefix}vendor_products`, JSON.stringify(vendorProductMappings));
  }, [vendorProductMappings, dataMode]);

  useEffect(() => {
    const curPrefix = getStoragePrefix(dataMode);
    localStorage.setItem(`${curPrefix}product_types`, JSON.stringify(productTypes));
  }, [productTypes, dataMode]);

  const [aiActivityLogs, setAiActivityLogs] = useState<AIActivityLog[]>(() => {
    const s = localStorage.getItem('mro_ai_activity_logs');
    if (s) {
      try {
        return JSON.parse(s);
      } catch {
        // fallback
      }
    }
    return [
      {
        id: 'AILOG-001',
        timestamp: '2026-09-28 14:32',
        vendorId: 'VEND-001',
        vendorName: 'Apex Industrial Bearings & Spares Pvt Ltd',
        fileName: 'SKF_Industrial_Bearings_Master_PriceList_2026.pdf',
        action: 'CATALOG_ANALYZED',
        productsCount: 12,
        categoriesSuggested: ['Bearings', 'Mechanical Components'],
        userAction: 'Analyzed via Gemini 3.5 Flash',
        confidence: 96,
        details: 'Extracted 12 bearing & seal products with 0 duplicates.',
      },
      {
        id: 'AILOG-002',
        timestamp: '2026-09-28 14:35',
        vendorId: 'VEND-001',
        vendorName: 'Apex Industrial Bearings & Spares Pvt Ltd',
        fileName: 'SKF_Industrial_Bearings_Master_PriceList_2026.pdf',
        action: 'CATEGORY_APPROVED',
        productsCount: 12,
        categoriesSuggested: ['Bearings'],
        userAction: 'Approved by Super Admin',
        confidence: 98,
        details: 'Approved Bearings category for Apex Industrial Bearings.',
      },
    ];
  });

  useEffect(() => {
    localStorage.setItem('mro_ai_activity_logs', JSON.stringify(aiActivityLogs));
  }, [aiActivityLogs]);

  const [backups, setBackups] = useState<BackupRecord[]>(() => getSavedBackups());
  const [backupSettings, setBackupSettings] = useState<BackupSettings>(() => getBackupSettings());
  const [backupFailureAlert, setBackupFailureAlert] = useState<{ timestamp: string; error: string } | null>(() => getActiveBackupFailure());

  const [availableUsers, setAvailableUsers] = useState<User[]>(() => {
    const s = localStorage.getItem('mro_users');
    if (s) {
      try {
        const parsed = JSON.parse(s);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {
        // fallback
      }
    }
    return INITIAL_USERS;
  });

  useEffect(() => {
    localStorage.setItem('mro_users', JSON.stringify(availableUsers));
  }, [availableUsers]);

  // Automatic Local & Multi-User Cache Persistence
  useEffect(() => {
    try {
      if (requirements && requirements.length > 0) {
        localStorage.setItem('erp_live_requirements', JSON.stringify(requirements));
      }
    } catch {}
  }, [requirements]);

  useEffect(() => {
    try {
      if (companies && companies.length > 0) {
        localStorage.setItem('erp_live_companies', JSON.stringify(companies));
      }
    } catch {}
  }, [companies]);

  useEffect(() => {
    try {
      if (purchaseExecutives && purchaseExecutives.length > 0) {
        localStorage.setItem('erp_live_purchase_executives', JSON.stringify(purchaseExecutives));
      }
    } catch {}
  }, [purchaseExecutives]);

  useEffect(() => {
    try {
      if (customers && customers.length > 0) {
        localStorage.setItem('erp_live_customers', JSON.stringify(customers));
      }
    } catch {}
  }, [customers]);

  useEffect(() => {
    try {
      if (vendors && vendors.length > 0) {
        localStorage.setItem('erp_live_vendors', JSON.stringify(vendors));
      }
    } catch {}
  }, [vendors]);

  useEffect(() => {
    try {
      if (products && products.length > 0) {
        localStorage.setItem('erp_live_products', JSON.stringify(products));
      }
    } catch {}
  }, [products]);

  // Central Real-Time Cloud Synchronization Engine State
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncTime, setLastSyncTime] = useState<Date>(new Date());
  const [isOnline, setIsOnline] = useState<boolean>(typeof navigator !== 'undefined' ? navigator.onLine : true);

  const broadcastRef = React.useRef<BroadcastChannel | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      try {
        broadcastRef.current = new BroadcastChannel('mro_enterprise_cloud_sync');
      } catch {}
    }
    return () => {
      try {
        broadcastRef.current?.close();
      } catch {}
    };
  }, []);

  const pushMutationToCloud = (overrideState?: any) => {
    try {
      const payload = overrideState || {
        requirements,
        companies,
        purchaseExecutives,
        customers,
        vendors,
        products,
        quotations: customerQuotations,
        customerPos: customerPOs,
        vendorPos: vendorPOs,
        proformaInvoices,
        payments,
        dispatches,
        deliveries,
        rfqs,
        vendorQuotes,
        vendorProductMappings,
        brands,
        categories,
        productTypes,
      };
      fetchApi('/api/sync/full', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ state: payload, user: currentUser.name }),
      }).catch(() => {});
      setLastSyncTime(new Date());
      if (broadcastRef.current) {
        broadcastRef.current.postMessage({ type: 'MUTATION', timestamp: Date.now() });
      }
    } catch {}
  };

  // Multi-Device Central Database Synchronization Engine
  // Guarantees that all laptops, desktops, and mobile devices across the company see identical data in real-time
  useEffect(() => {
    let isMounted = true;

    const syncBackendState = async () => {
      try {
        setIsSyncing(true);
        const res = await fetchApi('/api/sync/state');
        if (!res.ok) {
          setIsSyncing(false);
          return;
        }
        const data = await res.json();
        if (!data || !data.state) {
          setIsSyncing(false);
          return;
        }

        const serverState = data.state;
        const serverDeletedIds: string[] = Array.isArray(serverState.deletedRequirementIds)
          ? serverState.deletedRequirementIds
          : [];

        // Save server deleted tombstones locally
        try {
          const localStored = localStorage.getItem('erp_deleted_requirements');
          const localList: string[] = localStored ? JSON.parse(localStored) : [];
          const mergedTombstones = Array.from(new Set([...localList, ...serverDeletedIds]));
          localStorage.setItem('erp_deleted_requirements', JSON.stringify(mergedTombstones));
        } catch {}

        if (!isMounted) return;

        // Safe Two-Way Merged Requirements Sync: Never erases locally created requirements
        if (Array.isArray(serverState.requirements)) {
          setRequirements((prevReqs) => {
            // Guard: If server returns empty array but local client has requirements, NEVER wipe!
            if (serverState.requirements.length === 0 && prevReqs.length > 0) {
              pushMutationToCloud({ requirements: prevReqs });
              return prevReqs;
            }

            const reqMap = new Map<string, CustomerRequirement>();

            // 1. Load server requirements into map
            serverState.requirements.forEach((sr: CustomerRequirement) => {
              if (sr && sr.id) {
                reqMap.set(sr.id, sr);
              }
            });

            // 2. Safely merge local requirements so newly created or unsynced ones are never lost
            prevReqs.forEach((lr) => {
              if (lr && lr.id) {
                const existing = reqMap.get(lr.id);
                if (!existing) {
                  // Not on server yet: preserve local record!
                  reqMap.set(lr.id, lr);
                } else if (
                  lr.lastModifiedAt &&
                  (!existing.lastModifiedAt || new Date(lr.lastModifiedAt) > new Date(existing.lastModifiedAt))
                ) {
                  // Local modification is newer: preserve local record
                  reqMap.set(lr.id, lr);
                }
              }
            });

            const uniqueMerged = Array.from(reqMap.values());
            try {
              localStorage.setItem('erp_live_requirements', JSON.stringify(uniqueMerged));
            } catch {}
            return uniqueMerged;
          });
        }

        // Authoritative Companies Sync
        if (Array.isArray(serverState.companies) && serverState.companies.length > 0) {
          setCompanies(serverState.companies);
        }

        // Authoritative Purchase Executives Sync
        if (Array.isArray(serverState.purchaseExecutives) && serverState.purchaseExecutives.length > 0) {
          setPurchaseExecutives(serverState.purchaseExecutives);
        }

        // Authoritative Vendor Quotes Sync
        if (Array.isArray(serverState.vendorQuotes) && serverState.vendorQuotes.length > 0) {
          setVendorQuotes(serverState.vendorQuotes);
        }

        // Authoritative Quotations Sync
        if (Array.isArray(serverState.quotations)) {
          setCustomerQuotations(serverState.quotations);
        }

        // Authoritative Customer POs Sync
        if (Array.isArray(serverState.customerPos)) {
          setCustomerPOs(serverState.customerPos);
        }

        // Authoritative Vendor POs Sync
        if (Array.isArray(serverState.vendorPos)) {
          setVendorPOs(serverState.vendorPos);
        }

        // Authoritative Payments Sync
        if (Array.isArray(serverState.payments)) {
          setPayments(serverState.payments);
        }

        // Authoritative Dispatches Sync
        if (Array.isArray(serverState.dispatches)) {
          setDispatches(serverState.dispatches);
        }

        // Authoritative & Merged Vendors Sync (Never overwrites or deletes locally registered vendors)
        if (Array.isArray(serverState.vendors) && serverState.vendors.length > 0) {
          setVendors((prevVendors) => {
            const vendorMap = new Map<string, Vendor>();
            serverState.vendors.forEach((v: Vendor) => {
              if (v && v.id) vendorMap.set(v.id, v);
            });
            prevVendors.forEach((v) => {
              if (v && v.id) {
                const normName = v.companyName?.trim().toLowerCase();
                const exists = Array.from(vendorMap.values()).some(
                  (sv) => sv.id === v.id || (normName && sv.companyName?.trim().toLowerCase() === normName)
                );
                if (!exists) {
                  vendorMap.set(v.id, v);
                }
              }
            });
            const merged = Array.from(vendorMap.values());
            try {
              localStorage.setItem('erp_live_vendors', JSON.stringify(merged));
            } catch {}
            return merged;
          });
        }

        // Authoritative & Merged Products Sync (Never overwrites or deletes locally imported products)
        if (Array.isArray(serverState.products) && serverState.products.length > 0) {
          setProducts((prevProducts) => {
            const prodMap = new Map<string, ProductItem>();
            serverState.products.forEach((p: ProductItem) => {
              if (p && p.id) prodMap.set(p.id, p);
            });
            prevProducts.forEach((p) => {
              if (p && p.id) {
                const normName = p.itemName?.trim().toLowerCase();
                const normPart = p.partNumber?.trim().toLowerCase();
                const exists = Array.from(prodMap.values()).some(
                  (sp) =>
                    sp.id === p.id ||
                    (normName && sp.itemName?.trim().toLowerCase() === normName) ||
                    (normPart && sp.partNumber && sp.partNumber.trim().toLowerCase() === normPart)
                );
                if (!exists) {
                  prodMap.set(p.id, p);
                }
              }
            });
            const merged = Array.from(prodMap.values());
            try {
              localStorage.setItem('erp_live_products', JSON.stringify(merged));
            } catch {}
            return merged;
          });
        }

        // Authoritative & Merged Customers Sync
        if (Array.isArray(serverState.customers) && serverState.customers.length > 0) {
          setCustomers((prevCustomers) => {
            const custMap = new Map<string, Customer>();
            serverState.customers.forEach((c: Customer) => {
              if (c && c.id) custMap.set(c.id, c);
            });
            prevCustomers.forEach((c) => {
              if (c && c.id) {
                const normName = c.companyName?.trim().toLowerCase();
                const exists = Array.from(custMap.values()).some(
                  (sc) => sc.id === c.id || (normName && sc.companyName?.trim().toLowerCase() === normName)
                );
                if (!exists) {
                  custMap.set(c.id, c);
                }
              }
            });
            const merged = Array.from(custMap.values());
            try {
              localStorage.setItem('erp_live_customers', JSON.stringify(merged));
            } catch {}
            return merged;
          });
        }

        // Authoritative RFQs Sync
        if (Array.isArray(serverState.rfqs) && serverState.rfqs.length > 0) {
          setRfqs(serverState.rfqs);
        }

        // Authoritative Deliveries Sync
        if (Array.isArray(serverState.deliveries) && serverState.deliveries.length > 0) {
          setDeliveries(serverState.deliveries);
        }

        // Authoritative Proforma Invoices Sync
        if (Array.isArray(serverState.proformaInvoices) && serverState.proformaInvoices.length > 0) {
          setProformaInvoices(serverState.proformaInvoices);
        }

        // Authoritative Vendor Product Mappings Sync
        if (Array.isArray(serverState.vendorProductMappings) && serverState.vendorProductMappings.length > 0) {
          setVendorProductMappings(serverState.vendorProductMappings);
        }

        // Authoritative Brands Sync
        if (Array.isArray(serverState.brands) && serverState.brands.length > 0) {
          setBrands(serverState.brands);
        }

        // Authoritative Categories Sync
        if (Array.isArray(serverState.categories) && serverState.categories.length > 0) {
          setCategories(serverState.categories);
        }

        // Authoritative Global Product Types Sync
        if (Array.isArray(serverState.productTypes) && serverState.productTypes.length > 0) {
          setProductTypes(serverState.productTypes);
        }

        // Authoritative Accounting & Revenue Sync (GST Invoices, Vendor Bills, Expenses, Company Settings)
        syncAccountingWithBackend(serverState);

        setLastSyncTime(new Date());
        setIsSyncing(false);
      } catch (err) {
        setIsSyncing(false);
        console.warn('[Sync] Background sync warning:', err);
      }
    };

    // Initial immediate sync on mount
    syncBackendState();

    // Fast multi-laptop heartbeat sync every 3 seconds across open devices
    const interval = setInterval(syncBackendState, 3000);

    // Sync immediately when window/tab regains focus
    const handleFocus = () => {
      syncBackendState();
    };
    window.addEventListener('focus', handleFocus);

    // Sync when tab visibility changes (e.g. user unlocks laptop or switches tab)
    const handleVisibility = () => {
      if (document.visibilityState === 'visible') {
        syncBackendState();
      }
    };
    document.addEventListener('visibilitychange', handleVisibility);

    // Network connectivity change
    const handleOnline = () => {
      setIsOnline(true);
      syncBackendState();
    };
    const handleOffline = () => {
      setIsOnline(false);
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Instant Cross-Tab sync listener: when any tab mutates data, all tabs sync immediately
    const handleStorageChange = (e: StorageEvent) => {
      if (
        e.key?.startsWith('erp_') ||
        e.key?.startsWith('mro_') ||
        e.key === 'erp_live_requirements' ||
        e.key === 'erp_deleted_requirements'
      ) {
        syncBackendState();
      }
    };
    window.addEventListener('storage', handleStorageChange);

    // Listen to cross-tab broadcast notifications
    if (broadcastRef.current) {
      broadcastRef.current.onmessage = (event) => {
        if (event.data?.type === 'MUTATION') {
          syncBackendState();
        }
      };
    }

    return () => {
      isMounted = false;
      clearInterval(interval);
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleVisibility);
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  // Sync state to current mode's localStorage
  const activePrefix = getStoragePrefix(dataMode);

  useEffect(() => {
    localStorage.setItem('mro_active_data_mode', dataMode);
  }, [dataMode]);

  useEffect(() => {
    localStorage.setItem('procure_user', JSON.stringify(currentUser));
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}customers`, JSON.stringify(customers));
  }, [customers, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}companies`, JSON.stringify(companies));
  }, [companies, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}purchase_executives`, JSON.stringify(purchaseExecutives));
  }, [purchaseExecutives, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}vendors`, JSON.stringify(vendors));
  }, [vendors, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}products`, JSON.stringify(products));
  }, [products, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}categories`, JSON.stringify(categories));
  }, [categories, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}brands`, JSON.stringify(brands));
  }, [brands, activePrefix]);

  // Daily automatic backup check (runs on mount)
  useEffect(() => {
    if (backupSettings.autoBackupEnabled) {
      const last = backupSettings.lastBackupTimestamp ? new Date(backupSettings.lastBackupTimestamp).getTime() : 0;
      const now = Date.now();
      const intervalMs = (backupSettings.frequencyHours || 24) * 3600 * 1000;

      if (now - last > intervalMs) {
        try {
          const newBkp = createBackupSnapshot({
            vendors,
            categories,
            requirements,
            quotations: customerQuotations,
            customerPOs,
            vendorPOs,
            auditLogs,
            documents,
          }, 'AUTOMATIC_DAILY');
          setBackups(getSavedBackups());
          setBackupSettings(getBackupSettings());
          setBackupFailureAlert(null);
        } catch (err: any) {
          setBackupFailureAlert({
            timestamp: new Date().toISOString(),
            error: err?.message || 'Automatic cloud backup synchronization error',
          });
        }
      }
    }
  }, []);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}requirements`, JSON.stringify(requirements));
  }, [requirements, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}quotations`, JSON.stringify(customerQuotations));
  }, [customerQuotations, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}customer_pos`, JSON.stringify(customerPOs));
  }, [customerPOs, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}vendor_pos`, JSON.stringify(vendorPOs));
  }, [vendorPOs, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}proforma_invoices`, JSON.stringify(proformaInvoices));
  }, [proformaInvoices, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}payments`, JSON.stringify(payments));
  }, [payments, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}dispatches`, JSON.stringify(dispatches));
  }, [dispatches, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}deliveries`, JSON.stringify(deliveries));
  }, [deliveries, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}rfqs`, JSON.stringify(rfqs));
  }, [rfqs, activePrefix]);

  useEffect(() => {
    localStorage.setItem(`${activePrefix}vendor_quotes`, JSON.stringify(vendorQuotes));
  }, [vendorQuotes, activePrefix]);

  useEffect(() => {
    localStorage.setItem('mro_notifications', JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem('mro_audit_logs', JSON.stringify(auditLogs));
  }, [auditLogs]);

  // Helper log and notify
  const pushAudit = (action: string, entityType: string, entityId: string, details: string, oldValue?: string, newValue?: string) => {
    const newLog: AuditLogItem = {
      id: `AUD-${Date.now().toString().slice(-5)}`,
      timestamp: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
      user: currentUser.name,
      role: currentUser.role,
      action,
      entityType,
      entityId,
      oldValue,
      newValue,
      details,
    };
    setAuditLogs((prev) => [newLog, ...prev]);
  };

  const pushNotification = (
    title: string,
    message: string,
    type: 'INFO' | 'SUCCESS' | 'WARNING' | 'ACTION_REQUIRED' = 'INFO',
    targetRole: UserRole[] = ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE'],
    linkTab?: string,
    linkId?: string
  ) => {
    const notif: NotificationItem = {
      id: `NOTIF-${Date.now().toString().slice(-5)}`,
      title,
      message,
      timestamp: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
      type,
      read: false,
      targetRole,
      linkTab,
      linkId,
    };
    setNotifications((prev) => [notif, ...prev]);
  };

  const updateRequirementStage = (requirementId: string, stage: OrderWorkflowStage) => {
    setRequirements((prev) =>
      prev.map((r) => {
        if (r.id === requirementId) {
          return { ...r, status: stage };
        }
        return r;
      })
    );
  };

  // Add Customer
  const addCustomer = (custData: Omit<Customer, 'id' | 'createdAt'>): Customer => {
    const newId = `CUST-${String(customers.length + 1).padStart(3, '0')}`;
    const newCust: Customer = {
      ...custData,
      id: newId,
      createdAt: new Date().toISOString().split('T')[0],
    };
    setCustomers((prev) => [newCust, ...prev]);
    fetchApi('/api/customers', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newCust),
    }).catch((e) => console.warn('[API] Customer sync notice:', e));
    pushMutationToCloud();
    pushAudit('CUSTOMER_CREATED', 'Customer', newId, `Customer ${newCust.companyName} registered by ${currentUser.name}`);
    return newCust;
  };

  // Brand Master Operations
  const registerVendorBrands = (brandNames: string[]) => {
    if (!brandNames || brandNames.length === 0) return;
    setBrands((prev) => {
      const existingNames = new Set(prev.map((b) => b.name.toLowerCase().trim()));
      const toAdd: BrandMasterItem[] = [];
      brandNames.forEach((name) => {
        const clean = name.trim();
        if (clean && !existingNames.has(clean.toLowerCase())) {
          existingNames.add(clean.toLowerCase());
          const enrichment = getBrandEnrichment(clean, prev);
          toAdd.push({
            id: `BRD-${Date.now().toString().slice(-4)}-${Math.floor(Math.random() * 900 + 100)}`,
            name: enrichment.canonicalName || clean,
            code: enrichment.code || clean.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4) || 'BRD',
            category: enrichment.category || 'General MRO',
            categories: enrichment.subCategories && enrichment.subCategories.length > 0 ? enrichment.subCategories : ['General MRO'],
            description: enrichment.description || `Registered for supplied vendor catalog (${clean})`,
            countryOfOrigin: enrichment.country || 'India',
            isActive: true,
            createdAt: new Date().toISOString().split('T')[0],
            updatedAt: new Date().toISOString().split('T')[0],
          });
        }
      });
      if (toAdd.length === 0) return prev;
      const nextBrands = [...prev, ...toAdd];

      try {
        localStorage.setItem('erp_live_brands', JSON.stringify(nextBrands));
        localStorage.setItem(`${activePrefix}brands`, JSON.stringify(nextBrands));
      } catch {}

      fetchApi('/api/brands', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(toAdd),
      }).catch((e) => console.warn('[API] Brand registration warning:', e));

      setTimeout(() => {
        pushMutationToCloud({ brands: nextBrands });
      }, 50);

      pushAudit('BRAND_CREATED', 'BrandMaster', `${toAdd.length} items`, `Auto-registered ${toAdd.map((b) => b.name).join(', ')} from vendor profile`);
      return nextBrands;
    });
  };

  const addBrand = (brandData: Omit<BrandMasterItem, 'id' | 'createdAt'>): BrandMasterItem => {
    const newId = `BRD-${String(brands.length + 1).padStart(3, '0')}`;
    const newBrand: BrandMasterItem = {
      ...brandData,
      id: newId,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };
    const nextBrands = [newBrand, ...brands];
    setBrands(nextBrands);
    try {
      localStorage.setItem('erp_live_brands', JSON.stringify(nextBrands));
      localStorage.setItem(`${activePrefix}brands`, JSON.stringify(nextBrands));
    } catch {}
    fetchApi('/api/brands', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newBrand),
    }).catch((e) => console.warn('[API] Add brand sync warning:', e));
    pushMutationToCloud({ brands: nextBrands });
    pushAudit('BRAND_CREATED', 'BrandMaster', newId, `Added brand ${newBrand.name} (${newBrand.category || 'MRO'})`);
    return newBrand;
  };

  const updateBrand = (updated: BrandMasterItem) => {
    const nextBrands = brands.map((b) => (b.id === updated.id ? { ...updated, updatedAt: new Date().toISOString().split('T')[0] } : b));
    setBrands(nextBrands);
    try {
      localStorage.setItem('erp_live_brands', JSON.stringify(nextBrands));
      localStorage.setItem(`${activePrefix}brands`, JSON.stringify(nextBrands));
    } catch {}
    fetchApi('/api/brands', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).catch((e) => console.warn('[API] Update brand sync warning:', e));
    pushMutationToCloud({ brands: nextBrands });
    pushAudit('BRAND_UPDATED', 'BrandMaster', updated.id, `Updated brand ${updated.name}`);
  };

  const deleteBrand = (id: string): { success: boolean; message: string } => {
    const brand = brands.find((b) => b.id === id);
    if (!brand) return { success: false, message: 'Brand not found.' };

    const supplyingVendors = vendors.filter((v) =>
      (v.brandsSupplied || []).some((b) => b.toLowerCase().trim() === brand.name.toLowerCase().trim())
    );

    if (supplyingVendors.length > 0) {
      return {
        success: false,
        message: `Cannot delete "${brand.name}": it is actively supplied by ${supplyingVendors.length} vendor(s) (${supplyingVendors.map((v) => v.companyName).slice(0, 2).join(', ')}). Remove the brand from those vendors first.`,
      };
    }

    const nextBrands = brands.filter((b) => b.id !== id);
    setBrands(nextBrands);
    try {
      localStorage.setItem('erp_live_brands', JSON.stringify(nextBrands));
      localStorage.setItem(`${activePrefix}brands`, JSON.stringify(nextBrands));
    } catch {}
    fetchApi(`/api/brands/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
    pushMutationToCloud({ brands: nextBrands });
    pushAudit('BRAND_DELETED', 'BrandMaster', id, `Deleted brand ${brand.name}`);
    return { success: true, message: `Brand "${brand.name}" removed successfully.` };
  };

  // Add Vendor
  const addVendor = (vendData: Omit<Vendor, 'id' | 'createdAt'>): Vendor => {
    // Check if vendor with identical company name or GSTIN already exists
    const cleanName = vendData.companyName?.trim().toLowerCase();
    const cleanGst = vendData.gstin?.trim().toLowerCase();
    const existing = vendors.find(
      (v) =>
        (cleanName && v.companyName?.trim().toLowerCase() === cleanName) ||
        (cleanGst && v.gstin && v.gstin.trim().toLowerCase() === cleanGst)
    );
    if (existing) {
      console.warn(`[Duplicate Vendor] Vendor "${existing.companyName}" (${existing.id}) already exists. Blocking duplicate.`);
      pushNotification('Vendor Already Exists', `Vendor "${existing.companyName}" is already registered in the directory (${existing.id}).`, 'WARNING', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
      return existing;
    }

    const newId = `VEND-${String(vendors.length + 1).padStart(3, '0')}`;
    const newVend: Vendor = {
      ...vendData,
      id: newId,
      createdAt: new Date().toISOString().split('T')[0],
    };
    if (newVend.brandsSupplied && newVend.brandsSupplied.length > 0) {
      registerVendorBrands(newVend.brandsSupplied);
    }
    const nextVends = [newVend, ...vendors];
    setVendors(nextVends);
    try {
      localStorage.setItem('erp_live_vendors', JSON.stringify(nextVends));
      localStorage.setItem(`${activePrefix}vendors`, JSON.stringify(nextVends));
    } catch {}
    fetchApi('/api/vendors', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newVend),
    }).catch((e) => console.warn('[API] Add vendor sync warning:', e));
    pushMutationToCloud({ vendors: nextVends });
    pushAudit('VENDOR_CREATED', 'Vendor', newId, `Vendor ${newVend.companyName} registered by ${currentUser.name}`);
    return newVend;
  };

  // Add Product
  const addProduct = (prdData: Omit<ProductItem, 'id'>): ProductItem => {
    const newId = `PRD-${String(products.length + 1).padStart(3, '0')}`;
    const newProduct: ProductItem = {
      ...prdData,
      id: newId,
    };
    const nextProds = [newProduct, ...products];
    setProducts(nextProds);
    try {
      localStorage.setItem('erp_live_products', JSON.stringify(nextProds));
      localStorage.setItem(`${activePrefix}products`, JSON.stringify(nextProds));
    } catch {}
    fetchApi('/api/products', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newProduct),
    }).catch((e) => console.warn('[API] Add product sync warning:', e));
    pushMutationToCloud({ products: nextProds });
    pushAudit('PRODUCT_CREATED', 'ProductItem', newId, `New item ${newProduct.itemName} added to Master catalogue.`);
    return newProduct;
  };

  // Master Data Operations: Update & Delete
  const updateCustomer = (updated: Customer) => {
    setCustomers((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    fetchApi(`/api/customers/${encodeURIComponent(updated.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).catch(() => {});
    pushMutationToCloud();
    pushAudit('CUSTOMER_UPDATED', 'Customer', updated.id, `Updated profile for ${updated.companyName}`);
    pushNotification('Customer Updated', `${updated.companyName} details updated successfully.`, 'INFO', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
  };

  const deleteCustomer = (id: string) => {
    const target = customers.find((c) => c.id === id);
    const nextCusts = customers.filter((c) => c.id !== id);
    setCustomers(nextCusts);
    try {
      localStorage.setItem('erp_live_customers', JSON.stringify(nextCusts));
    } catch {}
    fetchApi(`/api/customers/${encodeURIComponent(id)}`, {
      method: 'DELETE',
    }).catch(() => {});
    pushMutationToCloud({ customers: nextCusts });
    pushAudit('CUSTOMER_DELETED', 'Customer', id, `Removed customer ${target?.companyName || id}`);
    pushNotification('Customer Removed', `${target?.companyName || id} removed from registry.`, 'WARNING', ['SUPER_ADMIN']);
  };

  const importCustomersList = (newCusts: (Omit<Customer, 'id' | 'createdAt'> | Customer)[]): number => {
    let importedCount = 0;
    const itemsToAdd: Customer[] = [];

    newCusts.forEach((c) => {
      const existing = customers.find(
        (ex) =>
          ex.companyName.toLowerCase().trim() === c.companyName.toLowerCase().trim() ||
          (c.gstin && c.gstin.trim() !== '' && ex.gstin.toLowerCase().trim() === c.gstin.toLowerCase().trim())
      );
      if (!existing) {
        const id = (c as Customer).id || `CUST-${String(customers.length + itemsToAdd.length + 1).padStart(3, '0')}`;
        itemsToAdd.push({
          ...c,
          id,
          createdAt: (c as Customer).createdAt || new Date().toISOString().split('T')[0],
        });
        importedCount++;
      }
    });

    if (itemsToAdd.length > 0) {
      setCustomers((prev) => [...itemsToAdd, ...prev]);
      fetchApi('/api/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(itemsToAdd),
      }).catch(() => {});
      pushMutationToCloud();
      pushAudit('CUSTOMERS_IMPORTED', 'Customer', `${importedCount} records`, `Bulk imported ${importedCount} customers`);
      pushNotification('Customers Imported', `Imported ${importedCount} customers into your registry.`, 'SUCCESS', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
    }
    return importedCount;
  };

  const updateVendor = (updated: Vendor) => {
    if (updated.brandsSupplied && updated.brandsSupplied.length > 0) {
      registerVendorBrands(updated.brandsSupplied);
    }
    const nextVends = vendors.map((v) => (v.id === updated.id ? updated : v));
    setVendors(nextVends);
    try {
      localStorage.setItem('erp_live_vendors', JSON.stringify(nextVends));
      localStorage.setItem(`${activePrefix}vendors`, JSON.stringify(nextVends));
    } catch {}
    fetchApi(`/api/vendors/${encodeURIComponent(updated.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).catch((e) => console.warn('[API] Update vendor sync warning:', e));
    pushMutationToCloud({ vendors: nextVends });
    pushAudit('VENDOR_UPDATED', 'Vendor', updated.id, `Updated credentials for ${updated.companyName}`);
    pushNotification('Vendor Updated', `${updated.companyName} profile updated successfully.`, 'INFO', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
  };

  // Soft Delete Vendor (Permanent Database Protection)
  const deleteVendor = (id: string, reason?: string) => {
    const target = vendors.find((v) => v.id === id);
    const delReason = reason || 'User Archived Vendor';
    const now = new Date().toISOString();
    const nextVends = vendors.map((v) =>
      v.id === id
        ? {
            ...v,
            isDeleted: true,
            deletedAt: now,
            deletedBy: currentUser.name,
            deletedReason: delReason,
          }
        : v
    );
    setVendors(nextVends);
    try {
      localStorage.setItem('erp_live_vendors', JSON.stringify(nextVends));
    } catch {}
    fetchApi(`/api/vendors/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason: delReason, user: currentUser.name }),
    }).catch((e) => console.warn('[API] Soft delete vendor sync warning:', e));
    pushMutationToCloud({ vendors: nextVends });
    pushAudit('VENDOR_ARCHIVED', 'Vendor', id, `Soft-deleted vendor ${target?.companyName || id}: ${delReason}`);
    pushNotification('Vendor Archived', `${target?.companyName || id} moved to archived registry safely.`, 'WARNING', ['SUPER_ADMIN']);
  };

  // Restore Soft-Deleted Vendor
  const restoreVendor = async (id: string): Promise<boolean> => {
    const target = vendors.find((v) => v.id === id);
    const nextVends = vendors.map((v) =>
      v.id === id
        ? {
            ...v,
            isDeleted: false,
            deletedAt: undefined,
            deletedBy: undefined,
            deletedReason: undefined,
          }
        : v
    );
    setVendors(nextVends);
    try {
      localStorage.setItem('erp_live_vendors', JSON.stringify(nextVends));
    } catch {}
    try {
      await fetchApi(`/api/vendors/${encodeURIComponent(id)}/restore`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user: currentUser.name }),
      });
      pushMutationToCloud({ vendors: nextVends });
      pushAudit('VENDOR_RESTORED', 'Vendor', id, `Restored vendor ${target?.companyName || id} to active directory`);
      pushNotification('Vendor Restored', `${target?.companyName || id} restored successfully to active suppliers.`, 'SUCCESS', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
      return true;
    } catch (e) {
      console.warn('[API] Restore vendor error:', e);
      return false;
    }
  };

  // Permanently Hard Delete Vendor (Super Admin Only)
  const permanentlyDeleteVendor = async (id: string): Promise<boolean> => {
    const target = vendors.find((v) => v.id === id);
    const nextVends = vendors.filter((v) => v.id !== id);
    setVendors(nextVends);
    try {
      localStorage.setItem('erp_live_vendors', JSON.stringify(nextVends));
      localStorage.setItem(`${activePrefix}vendors`, JSON.stringify(nextVends));
    } catch {}
    try {
      await fetchApi(`/api/vendors/${encodeURIComponent(id)}?permanent=true`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ permanent: true, user: currentUser.name }),
      });
      pushMutationToCloud({ vendors: nextVends });
      pushAudit('VENDOR_PERMANENTLY_DELETED', 'Vendor', id, `Hard-deleted archived supplier ${target?.companyName || id} permanently`);
      pushNotification('Supplier Permanently Deleted', `Removed ${target?.companyName || id} permanently from ERP database.`, 'INFO', ['SUPER_ADMIN']);
      return true;
    } catch (e) {
      console.warn('[API] Permanent delete error:', e);
      return false;
    }
  };

  // Purge / Empty Recycle Bin (Archived Vendors)
  const purgeArchivedVendors = async (): Promise<{ success: boolean; count: number }> => {
    const archived = vendors.filter((v) => !!v.isDeleted);
    if (archived.length === 0) return { success: true, count: 0 };
    const nextVends = vendors.filter((v) => !v.isDeleted);
    setVendors(nextVends);
    try {
      localStorage.setItem('erp_live_vendors', JSON.stringify(nextVends));
      localStorage.setItem(`${activePrefix}vendors`, JSON.stringify(nextVends));
    } catch {}
    try {
      await fetchApi(`/api/vendors/purge/archived`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user: currentUser.name }),
      });
      pushMutationToCloud({ vendors: nextVends });
      pushAudit('VENDOR_ARCHIVE_PURGED', 'Vendor', 'BATCH', `Purged ${archived.length} archived suppliers from database`);
      pushNotification('Recycle Bin Emptied', `Permanently deleted ${archived.length} archived suppliers.`, 'INFO', ['SUPER_ADMIN']);
      return { success: true, count: archived.length };
    } catch (e) {
      console.warn('[API] Purge archive error:', e);
      return { success: false, count: 0 };
    }
  };

  const importVendorsList = (newVends: (Omit<Vendor, 'id' | 'createdAt'> | Vendor)[]): any => {
    let importedVendorCount = 0;
    let importedProductCount = 0;
    let skippedCount = 0;
    const errorDetails: string[] = [];

    const itemsToAdd: Vendor[] = [];
    const mappingsToAdd: VendorProductMapping[] = [];
    const productsToAdd: ProductItem[] = [];
    const brandsToRegister: string[] = [];

    // Scan highest existing vendor number for robust sequential ID generation
    let maxVendNum = 0;
    vendors.forEach((ex) => {
      const match = ex.id?.match(/VEND-(\d+)/i);
      if (match) {
        const n = parseInt(match[1], 10);
        if (n > maxVendNum) maxVendNum = n;
      }
    });

    newVends.forEach((v, vIdx) => {
      const rawName = (v.companyName || v.vendorName || '').trim();
      if (!rawName) {
        skippedCount++;
        errorDetails.push(`Row ${vIdx + 1}: Skipped due to missing Company Name.`);
        return;
      }

      // 1. Collect brands to register
      if (v.brandsSupplied && v.brandsSupplied.length > 0) {
        brandsToRegister.push(...v.brandsSupplied);
      }

      // 2. Identify vendor ID - check both existing vendors and itemsToAdd
      const normName = rawName.toLowerCase();
      const rawGstin = (v.gstin || '').trim().toUpperCase();
      const isRealGstin = rawGstin.length === 15 && !rawGstin.startsWith('27AAAPV0000');

      const existing = vendors.find(
        (ex) =>
          (normName && ex.companyName?.toLowerCase().trim() === normName) ||
          (isRealGstin && ex.gstin && ex.gstin.trim().toUpperCase() === rawGstin)
      ) || itemsToAdd.find(
        (ex) =>
          (normName && ex.companyName?.toLowerCase().trim() === normName) ||
          (isRealGstin && ex.gstin && ex.gstin.trim().toUpperCase() === rawGstin)
      );

      let vendorId: string;
      let targetVendorObj: Vendor;

      if (!existing) {
        maxVendNum++;
        vendorId = (v as Vendor).id || `VEND-${String(maxVendNum).padStart(3, '0')}`;
        targetVendorObj = {
          ...v,
          id: vendorId,
          companyName: rawName,
          gstin: isRealGstin ? rawGstin : '',
          isDeleted: false,
          createdAt: (v as Vendor).createdAt || new Date().toISOString().split('T')[0],
        };
        itemsToAdd.push(targetVendorObj);
        importedVendorCount++;
      } else {
        vendorId = existing.id;
        targetVendorObj = existing;
        skippedCount++;
        errorDetails.push(`Row ${vIdx + 1}: Skipped duplicate supplier "${rawName}" (already exists in ERP as ${existing.id}).`);
      }

      // 3. Process products from vendor row
      const prodsList: ParsedVendorProduct[] = (v as any).parsedProducts || [];
      if (prodsList.length > 0) {
        prodsList.forEach((prod, pIdx) => {
          const cleanName = (prod.productName || '').trim();
          if (!cleanName) return;

          const effectiveBrand = prod.brand || targetVendorObj.brandsSupplied?.[0] || 'Standard OEM';
          const brandEnrichment = getBrandEnrichment(effectiveBrand);
          const effectiveCat = prod.category || brandEnrichment.category || 'General MRO';
          const effectiveHsn = prod.hsnCode || brandEnrichment.defaultHsn || '84821010';
          const effectiveGst = prod.gstRate ?? brandEnrichment.defaultGst ?? 18;
          const effectiveUom = prod.uom || brandEnrichment.defaultUom || 'NOS';
          const partNo = prod.partNumber || `PN-${brandEnrichment.code}-${Date.now().toString().slice(-4)}${vIdx}-${pIdx}`;

          brandsToRegister.push(brandEnrichment.canonicalName);

          // A. Create Vendor Product Mapping (if not already mapped)
          const isMapped = vendorProductMappings.some(
            (m) =>
              m.vendorId === vendorId &&
              m.productName.toLowerCase().trim() === cleanName.toLowerCase() &&
              (!prod.brand || m.brand.toLowerCase().trim() === effectiveBrand.toLowerCase())
          ) || mappingsToAdd.some(
            (m) =>
              m.vendorId === vendorId &&
              m.productName.toLowerCase().trim() === cleanName.toLowerCase()
          );

          if (!isMapped) {
            mappingsToAdd.push({
              id: `VPM-${Date.now()}-${mappingsToAdd.length + 1}`,
              vendorId,
              vendorCode: targetVendorObj.vendorCode || vendorId,
              vendorName: targetVendorObj.companyName,
              productName: cleanName,
              category: effectiveCat,
              subCategory: prod.subCategory || '',
              productType: cleanName,
              brand: brandEnrichment.canonicalName,
              modelNumber: prod.modelNumber || partNo,
              partNumber: partNo,
              specification: prod.specification || `${brandEnrichment.canonicalName} certified engineering specification`,
              uom: effectiveUom,
              supplyType: 'Authorized Distributor',
              availability: 'Regular Stock',
              status: 'ACTIVE',
              remarks: 'Imported via Vendor Excel/CSV with Product Module',
              createdAt: new Date().toISOString().split('T')[0],
              updatedAt: new Date().toISOString().split('T')[0],
            });
            importedProductCount++;
          }

          // B. Create Central Catalog ProductItem (if not already exists)
          const isCatalogProd = products.some(
            (cp) =>
              (cp.partNumber && cp.partNumber.toLowerCase().trim() === partNo.toLowerCase().trim()) ||
              cp.itemName.toLowerCase().trim() === cleanName.toLowerCase().trim()
          ) || productsToAdd.some(
            (cp) => cp.itemName.toLowerCase().trim() === cleanName.toLowerCase().trim()
          );

          if (!isCatalogProd) {
            productsToAdd.push({
              id: `PRD-${String(products.length + productsToAdd.length + 1).padStart(3, '0')}`,
              itemName: cleanName,
              category: effectiveCat,
              subCategory: prod.subCategory || '',
              brand: brandEnrichment.canonicalName,
              partNumber: partNo,
              modelNumber: prod.modelNumber || partNo,
              specification: prod.specification || `${brandEnrichment.canonicalName} industrial standard specification`,
              uom: effectiveUom,
              description: `${brandEnrichment.canonicalName} genuine industrial item supplied by ${targetVendorObj.companyName}`,
              approxRate: prod.approxRate,
              hsnCode: effectiveHsn,
              gstRate: effectiveGst,
              stockQty: prod.stockQty ?? 50,
              lastVendorName: targetVendorObj.companyName,
              status: 'ACTIVE',
              isDeleted: false,
            });
          }
        });
      }
    });

    if (brandsToRegister.length > 0) {
      registerVendorBrands(brandsToRegister);
    }

    const nextVendors = [...itemsToAdd, ...vendors];
    const nextMappings = [...mappingsToAdd, ...vendorProductMappings];
    const nextProducts = [...productsToAdd, ...products];

    if (itemsToAdd.length > 0) {
      setVendors(nextVendors);
      try {
        localStorage.setItem('erp_live_vendors', JSON.stringify(nextVendors));
      } catch {}
      fetchApi('/api/vendors', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(itemsToAdd),
      }).catch((e) => console.warn('[API] Bulk vendors sync warning:', e));
    }

    if (mappingsToAdd.length > 0) {
      setVendorProductMappings(nextMappings);
      try {
        localStorage.setItem('erp_live_vendorProductMappings', JSON.stringify(nextMappings));
      } catch {}
      fetchApi('/api/vendor-products/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ mappings: mappingsToAdd, userName: currentUser.name }),
      }).catch((e) => console.warn('[API] Bulk mappings sync warning:', e));
    }

    if (productsToAdd.length > 0) {
      setProducts(nextProducts);
      try {
        localStorage.setItem('erp_live_products', JSON.stringify(nextProducts));
      } catch {}
      fetchApi('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(productsToAdd),
      }).catch((e) => console.warn('[API] Bulk products sync warning:', e));
    }

    // Immediately push full mutation to cloud with updated arrays so sync never uses stale data
    pushMutationToCloud({
      vendors: nextVendors,
      products: nextProducts,
      vendorProductMappings: nextMappings,
    });

    const notifMsg = importedProductCount > 0
      ? `Imported ${importedVendorCount} vendors and auto-linked ${importedProductCount} products to vendor catalogs & central product master as per brand.`
      : `Imported ${importedVendorCount} vendors into supplier registry.`;

    pushAudit('VENDORS_IMPORTED', 'Vendor', `${importedVendorCount} vendors, ${importedProductCount} products`, notifMsg);
    pushNotification('Vendors & Products Imported', notifMsg, 'SUCCESS', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);

    const resultObj = {
      totalUploaded: newVends.length,
      successfullyImported: importedVendorCount,
      skipped: skippedCount,
      failed: errorDetails.length,
      errorDetails,
      importedProductsCount: importedProductCount,
      valueOf(): number {
        return importedVendorCount > 0 ? importedVendorCount : importedProductCount;
      },
    };

    return resultObj;
  };

  const updateProduct = (updated: ProductItem) => {
    setProducts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
    fetchApi(`/api/products/${encodeURIComponent(updated.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).catch((e) => console.warn('[API] Update product sync warning:', e));
    pushAudit('PRODUCT_UPDATED', 'ProductItem', updated.id, `Updated item ${updated.itemName}`);
  };

  // Soft Delete Product (Permanent Database Protection)
  const deleteProduct = (id: string, reason?: string) => {
    const target = products.find((p) => p.id === id);
    const delReason = reason || 'User Archived Product';
    const now = new Date().toISOString();
    const nextProds = products.map((p) =>
      p.id === id
        ? {
            ...p,
            isDeleted: true,
            deletedAt: now,
            deletedBy: currentUser.name,
            deletedReason: delReason,
          }
        : p
    );
    setProducts(nextProds);
    try {
      localStorage.setItem('erp_live_products', JSON.stringify(nextProds));
    } catch {}
    fetchApi(`/api/products/${encodeURIComponent(id)}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ reason: delReason, user: currentUser.name }),
    }).catch((e) => console.warn('[API] Delete product sync warning:', e));
    pushMutationToCloud({ products: nextProds });
    pushAudit('PRODUCT_ARCHIVED', 'ProductItem', id, `Soft-deleted product ${target?.itemName || id}: ${delReason}`);
  };

  // Restore Soft-Deleted Product
  const restoreProduct = async (id: string): Promise<boolean> => {
    const target = products.find((p) => p.id === id);
    const nextProds = products.map((p) =>
      p.id === id
        ? {
            ...p,
            isDeleted: false,
            deletedAt: undefined,
            deletedBy: undefined,
            deletedReason: undefined,
          }
        : p
    );
    setProducts(nextProds);
    try {
      localStorage.setItem('erp_live_products', JSON.stringify(nextProds));
    } catch {}
    try {
      await fetchApi(`/api/products/${encodeURIComponent(id)}/restore`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ user: currentUser.name }),
      });
      pushMutationToCloud({ products: nextProds });
      pushAudit('PRODUCT_RESTORED', 'ProductItem', id, `Restored product ${target?.itemName || id} to active catalog`);
      return true;
    } catch {
      return false;
    }
  };

  const importProductsList = (newProds: (Omit<ProductItem, 'id'> | ProductItem)[]): any => {
    let importedCount = 0;
    let skippedCount = 0;
    const errorDetails: string[] = [];
    const itemsToAdd: ProductItem[] = [];

    // Scan highest existing product number
    let maxProdNum = 0;
    products.forEach((cp) => {
      const match = cp.id?.match(/PRD-(\d+)/i);
      if (match) {
        const n = parseInt(match[1], 10);
        if (n > maxProdNum) maxProdNum = n;
      }
    });

    newProds.forEach((p, pIdx) => {
      const rawName = (p.itemName || (p as any).name || (p as any).productName || (p as any).title || '').trim();
      if (!rawName) {
        skippedCount++;
        errorDetails.push(`Row ${pIdx + 1}: Skipped due to missing Product Name.`);
        return;
      }

      const rawPart = (p.partNumber || (p as any).sku || (p as any).code || '').trim();
      const normPart = rawPart.toLowerCase();
      const isAutoGeneratedPart = normPart.startsWith('pn-');
      const normName = rawName.toLowerCase();
      const normBrand = (p.brand || (p as any).make || '').toLowerCase().trim();

      const existing = products.find(
        (ex) =>
          (!isAutoGeneratedPart && normPart && (ex.partNumber || '').toLowerCase().trim() === normPart && (ex.brand || '').toLowerCase().trim() === normBrand) ||
          (ex.itemName && ex.itemName.toLowerCase().trim() === normName && (ex.brand || '').toLowerCase().trim() === normBrand)
      ) || itemsToAdd.find(
        (ex) =>
          (!isAutoGeneratedPart && normPart && (ex.partNumber || '').toLowerCase().trim() === normPart && (ex.brand || '').toLowerCase().trim() === normBrand) ||
          (ex.itemName && ex.itemName.toLowerCase().trim() === normName && (ex.brand || '').toLowerCase().trim() === normBrand)
      );

      if (!existing) {
        maxProdNum++;
        const id = (p as ProductItem).id || `PRD-${String(maxProdNum).padStart(3, '0')}`;
        const isCadBrand = normBrand.includes('parss cad') || normBrand.includes('part cad') || normBrand.includes('.cad') || normBrand.includes('.dwg') || normBrand.includes('drawing');
        const effectiveBrand = isCadBrand ? 'Standard OEM' : (p.brand || (p as any).make || 'Standard OEM');
        if (isCadBrand) {
          errorDetails.push(`Row ${pIdx + 1} ("${rawName}"): Brand "${p.brand || ''}" detected as CAD/drawing file name ('parss cad'). Standardized to 'Standard OEM'.`);
        }

        itemsToAdd.push({
          ...p,
          id,
          itemName: rawName,
          category: p.category || (p as any).materialCategory || 'General MRO',
          subCategory: p.subCategory || '',
          brand: effectiveBrand,
          partNumber: rawPart || `PN-${String(maxProdNum).padStart(4, '0')}-${Math.floor(Math.random() * 900 + 100)}`,
          modelNumber: p.modelNumber || (p as any).partNumber || 'STD',
          specification: p.specification || (p as any).specs || rawName,
          uom: p.uom || (p as any).unit || 'NOS',
          description: p.description || rawName,
          approxRate: p.approxRate,
          hsnCode: p.hsnCode || '8482',
          gstRate: p.gstRate ?? 18,
          stockQty: p.stockQty ?? 50,
          status: 'ACTIVE',
          isDeleted: false,
        });
        importedCount++;
      } else {
        skippedCount++;
        errorDetails.push(`Row ${pIdx + 1}: Skipped duplicate item "${rawName}" (${normBrand || 'Standard OEM'}) - already present in Product Master.`);
      }
    });

    if (itemsToAdd.length > 0) {
      const nextProds = [...itemsToAdd, ...products];
      setProducts(nextProds);
      try {
        localStorage.setItem('erp_live_products', JSON.stringify(nextProds));
      } catch {}
      fetchApi('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(itemsToAdd),
      }).catch((e) => console.warn('[API] Bulk products sync warning:', e));
      pushMutationToCloud({ products: nextProds });
      pushAudit('PRODUCTS_IMPORTED', 'ProductItem', `${importedCount} products`, `Bulk imported ${importedCount} items into catalog.`);
    }

    const resultObj = {
      totalUploaded: newProds.length,
      successfullyImported: importedCount,
      skipped: skippedCount,
      failed: errorDetails.length,
      errorDetails,
      valueOf(): number {
        return importedCount;
      },
    };

    return resultObj;
  };

  const lockQuotationCommercials = (quotationId: string, remarks?: string) => {
    const qtn = customerQuotations.find((q) => q.id === quotationId);
    if (!qtn) return;

    const totalSelling = qtn.subtotal || qtn.items.reduce((s, it) => s + it.totalTaxableAmount, 0);
    const totalBuying = qtn.items.reduce(
      (s, it) => s + (it.purchasePrice + (it.freightCost || 0) + (it.otherCost || 0)) * it.quantity,
      0
    );
    const earning = totalSelling - totalBuying;
    const margin = totalSelling > 0 ? (earning / totalSelling) * 100 : 0;

    const lockData = {
      isLocked: true,
      lockedBy: currentUser.name,
      lockedAt: new Date().toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      lockedRemarks: remarks || 'Commercial margin verified and locked against tampering.',
      lockedEarnings: earning,
      lockedMarginPercent: margin,
      unlockHistory: qtn.commercialLock?.unlockHistory || [],
    };

    setCustomerQuotations((prev) =>
      prev.map((q) => (q.id === quotationId ? { ...q, commercialLock: lockData } : q))
    );

    setRequirements((prev) =>
      prev.map((r) => (r.id === qtn.requirementId ? { ...r, commercialLock: lockData } : r))
    );

    pushAudit(
      'COMMERCIALS_LOCKED',
      'Quotation',
      quotationId,
      `Frozen gross earning ₹${earning.toLocaleString('en-IN')} (${margin.toFixed(1)}%) by ${currentUser.name}`
    );

    pushNotification(
      'Commercials Locked',
      `Quotation ${quotationId} earning ₹${earning.toLocaleString('en-IN')} locked and protected.`,
      'SUCCESS',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE', 'ACCOUNTS_USER']
    );
  };

  const unlockQuotationCommercials = (quotationId: string, reason: string) => {
    const qtn = customerQuotations.find((q) => q.id === quotationId);
    if (!qtn) return;

    const priorHistory = qtn.commercialLock?.unlockHistory || [];
    const updatedHistory = [
      {
        unlockedBy: currentUser.name,
        unlockedAt: new Date().toLocaleDateString('en-IN', {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        reason,
      },
      ...priorHistory,
    ];

    const unlockData = {
      isLocked: false,
      unlockHistory: updatedHistory,
    };

    setCustomerQuotations((prev) =>
      prev.map((q) => (q.id === quotationId ? { ...q, commercialLock: unlockData } : q))
    );

    setRequirements((prev) =>
      prev.map((r) => (r.id === qtn.requirementId ? { ...r, commercialLock: unlockData } : r))
    );

    pushAudit(
      'COMMERCIALS_UNLOCKED',
      'Quotation',
      quotationId,
      `Commercials unlocked by ${currentUser.name} - Reason: ${reason}`
    );

    pushNotification(
      'Commercials Unlocked',
      `Quotation ${quotationId} opened for amendment. Reason: ${reason}`,
      'WARNING',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']
    );
  };

  // Category Master Operations
  const addCategory = (catData: Omit<MaterialCategory, 'id' | 'createdAt' | 'updatedAt'>): MaterialCategory => {
    const newId = `CAT-${String(categories.length + 1).padStart(3, '0')}`;
    const now = new Date().toISOString().split('T')[0];
    const newCat: MaterialCategory = {
      ...catData,
      id: newId,
      createdAt: now,
      updatedAt: now,
    };
    setCategories((prev) => [newCat, ...prev]);
    fetchApi('/api/categories', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newCat),
    }).catch(() => {});
    pushMutationToCloud();
    pushAudit('CATEGORY_CREATED', 'MaterialCategory', newId, `Added category "${newCat.name}" with ${newCat.keywords.length} keywords`);
    pushNotification('Category Created', `Material category "${newCat.name}" created successfully.`, 'SUCCESS', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
    return newCat;
  };

  const updateCategory = (updated: MaterialCategory) => {
    const now = new Date().toISOString().split('T')[0];
    setCategories((prev) => prev.map((c) => (c.id === updated.id ? { ...updated, updatedAt: now } : c)));
    fetchApi(`/api/categories/${encodeURIComponent(updated.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).catch(() => {});
    pushMutationToCloud();
    pushAudit('CATEGORY_UPDATED', 'MaterialCategory', updated.id, `Updated category "${updated.name}"`);
    pushNotification('Category Updated', `Category "${updated.name}" updated.`, 'INFO', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
  };

  const deleteCategory = (id: string): { success: boolean; message: string } => {
    const target = categories.find((c) => c.id === id);
    if (!target) return { success: false, message: 'Category not found' };

    // Check if any vendor is mapped to this category
    const vendorsUsing = vendors.filter((v) => {
      const cats = v.materialCategories && v.materialCategories.length > 0 ? v.materialCategories : v.productCategories || [];
      return cats.some((c) => c.toLowerCase() === target.name.toLowerCase());
    });

    if (vendorsUsing.length > 0) {
      return {
        success: false,
        message: `Cannot delete category "${target.name}": It is currently assigned to ${vendorsUsing.length} vendor(s) (e.g. ${vendorsUsing[0].companyName}). Please unmap vendors first or disable the category.`,
      };
    }

    // Check if any requirement uses this category
    const reqsUsing = requirements.filter((r) =>
      r.items.some((i) => (i.category || '').toLowerCase() === target.name.toLowerCase() || (i.recommendedCategory || '').toLowerCase() === target.name.toLowerCase())
    );

    if (reqsUsing.length > 0) {
      return {
        success: false,
        message: `Cannot delete category "${target.name}": ${reqsUsing.length} existing requirement(s) are linked to it. Recommend disabling the category instead.`,
      };
    }

    setCategories((prev) => prev.filter((c) => c.id !== id));
    fetchApi(`/api/categories/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
    pushMutationToCloud();
    pushAudit('CATEGORY_DELETED', 'MaterialCategory', id, `Deleted category "${target.name}"`);
    pushNotification('Category Deleted', `Category "${target.name}" removed from catalog.`, 'WARNING', ['SUPER_ADMIN']);
    return { success: true, message: `Category "${target.name}" deleted successfully.` };
  };

  const toggleCategoryStatus = (id: string) => {
    setCategories((prev) =>
      prev.map((c) => {
        if (c.id === id) {
          const newStatus = !c.isActive;
          const updated = { ...c, isActive: newStatus, updatedAt: new Date().toISOString().split('T')[0] };
          fetchApi(`/api/categories/${encodeURIComponent(id)}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(updated),
          }).catch(() => {});
          pushMutationToCloud();
          pushAudit('CATEGORY_STATUS_TOGGLED', 'MaterialCategory', id, `Category "${c.name}" ${newStatus ? 'Activated' : 'Disabled'}`);
          return updated;
        }
        return c;
      })
    );
  };

  const addKeywordToCategory = (categoryId: string, keyword: string) => {
    const cleanKw = keyword.trim().toLowerCase();
    if (!cleanKw) return;

    setCategories((prev) =>
      prev.map((c) => {
        if (c.id === categoryId) {
          if (c.keywords.some((k) => k.toLowerCase() === cleanKw)) return c;
          const updatedKeywords = [...c.keywords, cleanKw];
          pushAudit('CATEGORY_KEYWORD_LEARNED', 'MaterialCategory', categoryId, `Added learned keyword "${cleanKw}" to category "${c.name}"`);
          return { ...c, keywords: updatedKeywords, updatedAt: new Date().toISOString().split('T')[0] };
        }
        return c;
      })
    );
    pushNotification('Keyword Added', `Added "${keyword}" to category keywords for smarter auto-recommendations.`, 'SUCCESS', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
  };

  const bulkImportRequirements = (newReqs: Omit<CustomerRequirement, 'id' | 'createdAt'>[]): number => {
    let importedCount = 0;
    const itemsToAdd: CustomerRequirement[] = [];

    newReqs.forEach((r, idx) => {
      const newId = `REQ-2026-${String(requirements.length + itemsToAdd.length + 1).padStart(5, '0')}`;
      const now = new Date().toISOString().split('T')[0];

      // Auto-classify items if not set
      const enrichedItems = r.items.map((item, itemIdx) => {
        const catRec = recommendCategoryForRequirement(item, categories);
        const vendorRecs = recommendVendorsForRequirement(
          {
            category: item.category || catRec.category,
            subCategory: item.subCategory || catRec.subCategory,
            itemName: item.itemName,
            description: item.description,
          },
          vendors
        );

        return {
          ...item,
          id: `ITEM-${String(itemIdx + 1).padStart(3, '0')}`,
          category: item.category || catRec.category,
          recommendedCategory: catRec.category,
          subCategory: item.subCategory || catRec.subCategory,
          recommendedVendors: vendorRecs,
          confidenceScore: catRec.confidence,
        };
      });

      itemsToAdd.push({
        ...r,
        id: newId,
        createdAt: now,
        items: enrichedItems,
        isBulkImported: true,
      });
      importedCount++;
    });

    if (itemsToAdd.length > 0) {
      setRequirements((prev) => [...itemsToAdd, ...prev]);
      pushAudit('BULK_REQUIREMENTS_IMPORTED', 'CustomerRequirement', `${importedCount} records`, `Imported ${importedCount} bulk requirements via Excel`);
      pushNotification('Requirements Imported', `Successfully imported ${importedCount} requirements with auto-category classification.`, 'SUCCESS', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
    }
    return importedCount;
  };

  const assignVendorToRequirementItem = (requirementId: string, itemId: string, vendorId: string, vendorName: string) => {
    setRequirements((prev) =>
      prev.map((req) => {
        if (req.id !== requirementId) return req;
        const updatedItems = req.items.map((it) => {
          if (it.id === itemId) {
            return {
              ...it,
              selectedVendorId: vendorId,
              selectedVendorName: vendorName,
            };
          }
          return it;
        });
        return {
          ...req,
          items: updatedItems,
        };
      })
    );

    pushAudit('VENDOR_ASSIGNED_TO_ITEM', 'CustomerRequirement', requirementId, `Assigned supplier ${vendorName} (${vendorId}) to item ${itemId}`);
    pushNotification('Supplier Assigned', `${vendorName} assigned to requirement ${requirementId}.`, 'SUCCESS', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
  };

  // AI Vendor Catalog Analyzer & Learning Methods
  const analyzeVendorCatalogFiles = async (
    vendorId: string,
    files: Array<{ name: string; type: string; size?: number; textContent?: string }>
  ): Promise<number> => {
    const targetVendor = vendors.find((v) => v.id === vendorId);
    if (!targetVendor) throw new Error('Vendor not found');

    let totalNewProducts = 0;
    const newCatalogFiles: VendorCatalogFile[] = [];
    const newCatalogProducts: VendorCatalogProduct[] = [];
    const newSuggestedCategories: VendorMaterialCategory[] = [];

    const existingProducts = targetVendor.catalogProducts || [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const analysisResult = await analyzeVendorCatalog({
        vendorId,
        vendorName: targetVendor.companyName,
        file,
      });

      const fileId = `CATFILE-${Date.now()}-${i + 1}`;
      const catalogFileEntry: VendorCatalogFile = {
        id: fileId,
        vendorId,
        fileName: file.name,
        fileType: analysisResult.fileType,
        fileSize: file.size ? `${(file.size / 1024).toFixed(1)} KB` : '1.8 MB',
        uploadDate: new Date().toISOString().split('T')[0],
        processingStatus: 'ANALYZED',
        aiAnalysisStatus: 'COMPLETED',
        productsIdentifiedCount: analysisResult.products.length,
      };
      newCatalogFiles.push(catalogFileEntry);

      // Process products and check for duplicates
      analysisResult.products.forEach((p, pIdx) => {
        const prodId = `CPRD-${Date.now()}-${i}-${pIdx + 1}`;
        const dupCheck = detectDuplicateProduct(p, [...existingProducts, ...newCatalogProducts]);

        const prodEntry: VendorCatalogProduct = {
          ...p,
          id: prodId,
          catalogFileId: fileId,
          isDuplicate: dupCheck.isDuplicate,
          duplicateOfId: dupCheck.duplicateOf?.id,
        };
        newCatalogProducts.push(prodEntry);
        totalNewProducts++;
      });

      // Suggested categories
      analysisResult.suggestedCategories.forEach((sc, scIdx) => {
        const catId = `AICAT-${Date.now()}-${i}-${scIdx + 1}`;
        newSuggestedCategories.push({
          ...sc,
          id: catId,
        });
      });
    }

    const updatedVendors = vendors.map((v) => {
      if (v.id !== vendorId) return v;
      return {
        ...v,
        lastAiAnalysisDate: new Date().toLocaleString('en-IN', {
          day: 'numeric',
          month: 'short',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        catalogFiles: [...(v.catalogFiles || []), ...newCatalogFiles],
        catalogProducts: [...(v.catalogProducts || []), ...newCatalogProducts],
        aiMaterialCategories: [...(v.aiMaterialCategories || []), ...newSuggestedCategories],
      };
    });

    setVendors(updatedVendors);

    // AI Activity Log entry
    const newLog: AIActivityLog = {
      id: `AILOG-${Date.now()}`,
      timestamp: new Date().toLocaleString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      vendorId,
      vendorName: targetVendor.companyName,
      fileName: files.map((f) => f.name).join(', '),
      action: 'CATALOG_ANALYZED',
      productsCount: totalNewProducts,
      categoriesSuggested: newSuggestedCategories.map((c) => c.category),
      userAction: `Analyzed ${files.length} catalog files via Gemini AI`,
      confidence: Math.round(
        newSuggestedCategories.reduce((acc, c) => acc + c.confidence, 0) / (newSuggestedCategories.length || 1)
      ),
      details: `Identified ${totalNewProducts} products and ${newSuggestedCategories.length} categories. Awaiting user approval.`,
    };

    setAiActivityLogs((prev) => [newLog, ...prev]);

    pushAudit(
      'CATALOG_ANALYZED',
      'Vendor',
      vendorId,
      `AI analyzed ${files.length} catalog file(s) for ${targetVendor.companyName}: identified ${totalNewProducts} items across ${newSuggestedCategories.length} categories`
    );

    pushNotification(
      'Catalog Analysis Complete',
      `Identified ${totalNewProducts} products for ${targetVendor.companyName}. Review suggested categories.`,
      'ACTION_REQUIRED',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']
    );

    return totalNewProducts;
  };

  const approveVendorMaterialCategory = (vendorId: string, categoryId: string) => {
    let approvedCategoryName = '';
    let approvedSubCategory = '';
    let approvedBrands: string[] = [];

    setVendors((prev) =>
      prev.map((v) => {
        if (v.id !== vendorId) return v;

        const targetCat = v.aiMaterialCategories?.find((c) => c.id === categoryId);
        if (!targetCat) return v;

        approvedCategoryName = targetCat.category;
        approvedSubCategory = targetCat.subCategory || '';
        approvedBrands = targetCat.brands || [];

        const updatedAiCategories = (v.aiMaterialCategories || []).map((c) => {
          if (c.id === categoryId) {
            return {
              ...c,
              status: 'APPROVED' as const,
              approvedBy: currentUser.name,
              approvedAt: new Date().toLocaleString('en-IN', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
              }),
            };
          }
          return c;
        });

        // Add to approved materialCategories
        const existingCats = v.materialCategories || v.productCategories || [];
        const nextCats = existingCats.includes(approvedCategoryName)
          ? existingCats
          : [...existingCats, approvedCategoryName];

        // Add to subCategories
        const existingSubCats = v.subCategories || [];
        const nextSubCats =
          approvedSubCategory && !existingSubCats.includes(approvedSubCategory)
            ? [...existingSubCats, approvedSubCategory]
            : existingSubCats;

        // Add to brandsSupplied
        const existingBrands = v.brandsSupplied || [];
        const nextBrands = Array.from(new Set([...existingBrands, ...approvedBrands]));

        // Mark associated products as approved
        const updatedProducts = (v.catalogProducts || []).map((p) => {
          if (p.category === approvedCategoryName) {
            return { ...p, approvalStatus: 'APPROVED' as const };
          }
          return p;
        });

        return {
          ...v,
          materialCategories: nextCats,
          productCategories: nextCats,
          subCategories: nextSubCats,
          brandsSupplied: nextBrands,
          aiMaterialCategories: updatedAiCategories,
          catalogProducts: updatedProducts,
        };
      })
    );

    const targetVendor = vendors.find((v) => v.id === vendorId);
    const newLog: AIActivityLog = {
      id: `AILOG-${Date.now()}`,
      timestamp: new Date().toLocaleString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      vendorId,
      vendorName: targetVendor?.companyName || vendorId,
      action: 'CATEGORY_APPROVED',
      productsCount: 1,
      categoriesSuggested: [approvedCategoryName],
      userAction: `Approved by ${currentUser.name}`,
      confidence: 100,
      details: `User approved category "${approvedCategoryName}" and added to vendor material profile.`,
    };
    setAiActivityLogs((prev) => [newLog, ...prev]);

    pushAudit('CATEGORY_APPROVED', 'Vendor', vendorId, `Approved material category ${approvedCategoryName} for ${targetVendor?.companyName || vendorId}`);
    pushNotification('Material Profile Updated', `Added approved category "${approvedCategoryName}" to ${targetVendor?.companyName}.`, 'SUCCESS', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
  };

  const rejectVendorMaterialCategory = (vendorId: string, categoryId: string) => {
    let rejectedCatName = '';
    setVendors((prev) =>
      prev.map((v) => {
        if (v.id !== vendorId) return v;
        const targetCat = v.aiMaterialCategories?.find((c) => c.id === categoryId);
        rejectedCatName = targetCat?.category || '';
        return {
          ...v,
          aiMaterialCategories: (v.aiMaterialCategories || []).map((c) =>
            c.id === categoryId ? { ...c, status: 'REJECTED' as const } : c
          ),
        };
      })
    );

    const targetVendor = vendors.find((v) => v.id === vendorId);
    const newLog: AIActivityLog = {
      id: `AILOG-${Date.now()}`,
      timestamp: new Date().toLocaleString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      vendorId,
      vendorName: targetVendor?.companyName || vendorId,
      action: 'CATEGORY_REJECTED',
      productsCount: 0,
      categoriesSuggested: [rejectedCatName],
      userAction: `Rejected by ${currentUser.name}`,
      confidence: 0,
      details: `User rejected AI suggested category "${rejectedCatName}". Vendor profile unchanged.`,
    };
    setAiActivityLogs((prev) => [newLog, ...prev]);

    pushAudit('CATEGORY_REJECTED', 'Vendor', vendorId, `Rejected suggested category ${rejectedCatName} for ${targetVendor?.companyName}`);
  };

  const editVendorMaterialCategory = (vendorId: string, categoryId: string, updated: Partial<VendorMaterialCategory>) => {
    setVendors((prev) =>
      prev.map((v) => {
        if (v.id !== vendorId) return v;
        return {
          ...v,
          aiMaterialCategories: (v.aiMaterialCategories || []).map((c) =>
            c.id === categoryId ? { ...c, ...updated } : c
          ),
        };
      })
    );

    pushAudit('CATEGORY_EDITED', 'Vendor', vendorId, `Modified suggested category details in vendor ${vendorId}`);
  };

  const approveAllVendorMaterialCategories = (vendorId: string) => {
    const targetVendor = vendors.find((v) => v.id === vendorId);
    if (!targetVendor) return;

    const pending = (targetVendor.aiMaterialCategories || []).filter((c) => c.status === 'PENDING_APPROVAL');
    if (pending.length === 0) return;

    pending.forEach((c) => {
      approveVendorMaterialCategory(vendorId, c.id);
    });
  };

  const approveVendorCatalogProduct = (vendorId: string, productId: string) => {
    setVendors((prev) =>
      prev.map((v) => {
        if (v.id !== vendorId) return v;
        return {
          ...v,
          catalogProducts: (v.catalogProducts || []).map((p) =>
            p.id === productId ? { ...p, approvalStatus: 'APPROVED' as const } : p
          ),
        };
      })
    );
  };

  const rejectVendorCatalogProduct = (vendorId: string, productId: string) => {
    setVendors((prev) =>
      prev.map((v) => {
        if (v.id !== vendorId) return v;
        return {
          ...v,
          catalogProducts: (v.catalogProducts || []).map((p) =>
            p.id === productId ? { ...p, approvalStatus: 'REJECTED' as const } : p
          ),
        };
      })
    );
  };

  const learnCategoryFromVendorQuotation = (
    vendorId: string,
    categoryName: string,
    subCategoryName?: string,
    sourceDoc: string = 'Vendor RFQ Quotation'
  ) => {
    const targetVendor = vendors.find((v) => v.id === vendorId);
    if (!targetVendor) return;

    const existingCats = targetVendor.materialCategories || targetVendor.productCategories || [];
    if (existingCats.includes(categoryName)) return;

    const catId = `AICAT-LEARN-${Date.now()}`;
    const newCat: VendorMaterialCategory = {
      id: catId,
      vendorId,
      category: categoryName,
      subCategory: subCategoryName,
      brands: targetVendor.brandsSupplied || [],
      productsFoundCount: 1,
      confidence: 96,
      sourceDocument: sourceDoc,
      status: 'APPROVED',
      approvedBy: currentUser.name,
      approvedAt: new Date().toLocaleString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
    };

    setVendors((prev) =>
      prev.map((v) => {
        if (v.id !== vendorId) return v;
        const nextCats = [...(v.materialCategories || v.productCategories || []), categoryName];
        const nextSubCats = subCategoryName && !(v.subCategories || []).includes(subCategoryName)
          ? [...(v.subCategories || []), subCategoryName]
          : v.subCategories || [];
        return {
          ...v,
          materialCategories: nextCats,
          productCategories: nextCats,
          subCategories: nextSubCats,
          aiMaterialCategories: [...(v.aiMaterialCategories || []), newCat],
        };
      })
    );

    const newLog: AIActivityLog = {
      id: `AILOG-${Date.now()}`,
      timestamp: new Date().toLocaleString('en-IN', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      }),
      vendorId,
      vendorName: targetVendor.companyName,
      action: 'RFQ_LEARNING_ACCEPTED',
      productsCount: 1,
      categoriesSuggested: [categoryName],
      userAction: `Learned and approved from quotation by ${currentUser.name}`,
      confidence: 96,
      details: `AI detected new dealing category "${categoryName}" from quotation and updated vendor profile.`,
    };
    setAiActivityLogs((prev) => [newLog, ...prev]);

    pushAudit('VENDOR_LEARNING_APPROVED', 'Vendor', vendorId, `Learned new category "${categoryName}" from quotation for ${targetVendor.companyName}`);
    pushNotification('Supplier Profile Expanded', `Added "${categoryName}" to ${targetVendor.companyName} based on quotation response.`, 'SUCCESS', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
  };

  const deleteVendorCatalogFile = (vendorId: string, fileId: string) => {
    setVendors((prev) =>
      prev.map((v) => {
        if (v.id !== vendorId) return v;
        const targetFile = v.catalogFiles?.find((f) => f.id === fileId);
        return {
          ...v,
          catalogFiles: (v.catalogFiles || []).filter((f) => f.id !== fileId),
          catalogProducts: (v.catalogProducts || []).filter((p) => p.catalogFileId !== fileId || p.approvalStatus === 'APPROVED'),
          aiMaterialCategories: (v.aiMaterialCategories || []).filter((c) => c.sourceDocument !== targetFile?.fileName || c.status === 'APPROVED'),
        };
      })
    );
    pushAudit('CATALOG_FILE_DELETED', 'Vendor', vendorId, `Deleted catalog file ${fileId} from vendor ${vendorId}`);
  };

  const saveCatalogAnalysisToVendor = async (
    vendorId: string,
    payload: {
      catalogFile?: any;
      catalogProducts?: any[];
      suggestedCategories?: any[];
      vendorProfile?: any;
    }
  ): Promise<boolean> => {
    try {
      const targetVendor = vendors.find((v) => v.id === vendorId);
      if (!targetVendor) return false;

      const approvedProds = payload.catalogProducts || [];
      const suggestedCats = payload.suggestedCategories || [];
      const distinctBrands = payload.vendorProfile?.distinctBrands || [];

      // Create vendor product mappings locally
      const newMappings: VendorProductMapping[] = approvedProds.map((p, idx) => ({
        id: `VPM-${Date.now()}-${idx + 1}`,
        vendorId,
        vendorCode: targetVendor.vendorCode || targetVendor.id,
        vendorName: targetVendor.companyName,
        productName: p.productName,
        category: p.category,
        subCategory: p.subCategory,
        productType: p.subCategory,
        brand: p.brand,
        modelNumber: p.modelNumber || p.partNumber,
        partNumber: p.partNumber || p.modelNumber,
        specification: p.specification,
        description: p.description,
        uom: p.uom || 'NOS',
        supplyType: 'Authorized Distributor',
        availability: 'Regular Stock',
        status: 'ACTIVE',
        remarks: `Imported from catalog: ${payload.catalogFile?.fileName || 'Catalog File'}`,
        createdAt: new Date().toISOString().split('T')[0],
      }));

      setVendorProductMappings((prev) => {
        const filtered = prev.filter(
          (m) =>
            !newMappings.some(
              (nm) =>
                nm.vendorId === m.vendorId &&
                nm.productName.toLowerCase() === m.productName.toLowerCase() &&
                nm.brand.toLowerCase() === m.brand.toLowerCase()
            )
        );
        return [...newMappings, ...filtered];
      });

      // Also register newly discovered brands
      if (distinctBrands.length > 0) {
        registerVendorBrands(distinctBrands);
      }

      // Update vendor record
      setVendors((prev) =>
        prev.map((v) => {
          if (v.id !== vendorId) return v;
          const mergedBrands = Array.from(new Set([...(v.brandsSupplied || []), ...distinctBrands]));
          const existingCats = v.materialCategories || v.productCategories || [];
          const newCatNames = suggestedCats.map((c: any) => c.category);
          const mergedCats = Array.from(new Set([...existingCats, ...newCatNames]));

          return {
            ...v,
            brandsSupplied: mergedBrands,
            materialCategories: mergedCats,
            productCategories: mergedCats,
            lastAiAnalysisDate: new Date().toLocaleString('en-IN', {
              day: 'numeric',
              month: 'short',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            }),
            catalogFiles: payload.catalogFile ? [payload.catalogFile, ...(v.catalogFiles || [])] : v.catalogFiles,
            catalogProducts: [...approvedProds, ...(v.catalogProducts || [])],
            aiMaterialCategories: [...suggestedCats, ...(v.aiMaterialCategories || [])],
            productsSupplied: [...newMappings, ...(v.productsSupplied || [])],
          };
        })
      );

      // Add to Product Master catalogue if not already present
      approvedProds.forEach((p) => {
        const exists = products.some(
          (prod) =>
            prod.itemName.toLowerCase().trim() === p.productName.toLowerCase().trim() ||
            (p.partNumber && prod.partNumber?.toLowerCase().trim() === p.partNumber.toLowerCase().trim())
        );
        if (!exists) {
          addProduct({
            itemName: p.productName,
            category: p.category,
            subCategory: p.subCategory,
            brand: p.brand,
            partNumber: p.partNumber || p.modelNumber || '',
            modelNumber: p.modelNumber || '',
            specification: p.specification || '',
            uom: p.uom || 'NOS',
            hsnCode: '8482',
            approxRate: 0,
            gstRate: 18,
            status: 'ACTIVE',
            description: p.description || p.specification || '',
          });
        }
      });

      // Persist to central production backend
      const res = await fetchApi(`/api/vendors/${encodeURIComponent(vendorId)}/catalog`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      pushAudit(
        'CATALOG_SAVED_TO_VENDOR',
        'Vendor',
        vendorId,
        `Saved catalog ${payload.catalogFile?.fileName || ''} with ${approvedProds.length} products to vendor ${targetVendor.companyName}`
      );
      pushNotification(
        'Catalog Saved Successfully',
        `Added ${approvedProds.length} products & updated profile for ${targetVendor.companyName}.`,
        'SUCCESS',
        ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']
      );

      return res.ok;
    } catch (err) {
      console.error('Error saving catalog to vendor:', err);
      return false;
    }
  };

  const addVendorProductMapping = async (
    mapping: Omit<VendorProductMapping, 'id' | 'createdAt'>
  ): Promise<VendorProductMapping> => {
    const targetVendor = vendors.find((v) => v.id === mapping.vendorId);
    const newMapping: VendorProductMapping = {
      ...mapping,
      id: `VPM-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      vendorCode: targetVendor?.vendorCode || mapping.vendorCode || mapping.vendorId,
      vendorName: targetVendor?.companyName || mapping.vendorName,
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };

    setVendorProductMappings((prev) => [newMapping, ...prev]);

    if (newMapping.brand) {
      registerVendorBrands([newMapping.brand]);
    }

    try {
      await fetchApi('/api/vendor-products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...newMapping, userName: currentUser.name }),
      });
    } catch (e) {
      console.warn('Backend save mapping warning:', e);
    }

    pushAudit(
      'VENDOR_PRODUCT_MAPPED',
      'VendorProductMapping',
      newMapping.id,
      `Mapped product "${newMapping.productName}" (${newMapping.brand}) to vendor ${newMapping.vendorName}`
    );

    return newMapping;
  };

  const updateVendorProductMapping = async (mapping: VendorProductMapping): Promise<void> => {
    const updated = {
      ...mapping,
      updatedAt: new Date().toISOString().split('T')[0],
    };

    setVendorProductMappings((prev) => prev.map((m) => (m.id === updated.id ? updated : m)));

    if (updated.brand) {
      registerVendorBrands([updated.brand]);
    }

    try {
      await fetchApi(`/api/vendor-products/${encodeURIComponent(updated.id)}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...updated, userName: currentUser.name }),
      });
    } catch (e) {
      console.warn('Backend update mapping warning:', e);
    }

    pushAudit(
      'VENDOR_PRODUCT_UPDATED',
      'VendorProductMapping',
      updated.id,
      `Updated product mapping "${updated.productName}" for ${updated.vendorName}`
    );
  };

  const deleteVendorProductMapping = async (id: string): Promise<void> => {
    setVendorProductMappings((prev) =>
      prev.map((m) => (m.id === id ? { ...m, status: 'INACTIVE' as const } : m))
    );

    try {
      await fetchApi(`/api/vendor-products/${encodeURIComponent(id)}?user=${encodeURIComponent(currentUser.name)}`, {
        method: 'DELETE',
      });
    } catch (e) {
      console.warn('Backend delete mapping warning:', e);
    }

    pushAudit('VENDOR_PRODUCT_DEACTIVATED', 'VendorProductMapping', id, `Deactivated vendor product mapping ${id}`);
  };

  const bulkAddVendorProductMappings = async (
    vendorId: string,
    mappings: Partial<VendorProductMapping>[]
  ): Promise<{ added: number; updated: number; skipped: number }> => {
    const targetVendor = vendors.find((v) => v.id === vendorId);
    let added = 0;
    let updated = 0;

    const newMappingsList: VendorProductMapping[] = [];

    mappings.forEach((m, idx) => {
      if (!m.productName) return;
      const existing = vendorProductMappings.find(
        (ex) =>
          ex.vendorId === vendorId &&
          ex.productName.toLowerCase().trim() === m.productName?.toLowerCase().trim() &&
          (!m.brand || ex.brand.toLowerCase().trim() === m.brand?.toLowerCase().trim())
      );

      if (existing) {
        updated++;
      } else {
        added++;
        newMappingsList.push({
          id: `VPM-${Date.now()}-${idx + 1}`,
          vendorId,
          vendorCode: targetVendor?.vendorCode || vendorId,
          vendorName: targetVendor?.companyName || 'Supplier',
          productName: m.productName,
          category: m.category || 'General Industrial Spares',
          subCategory: m.subCategory || '',
          productType: m.productType || m.subCategory || '',
          brand: m.brand || 'Generic',
          modelNumber: m.modelNumber || m.partNumber || '',
          partNumber: m.partNumber || m.modelNumber || '',
          specification: m.specification || '',
          rating: m.rating || '',
          size: m.size || '',
          description: m.description || '',
          uom: m.uom || 'NOS',
          supplyType: m.supplyType || 'Authorized Distributor',
          availability: m.availability || 'Regular Stock',
          status: m.status || 'ACTIVE',
          remarks: m.remarks || 'Bulk Excel Import',
          createdAt: new Date().toISOString().split('T')[0],
          updatedAt: new Date().toISOString().split('T')[0],
        });
      }
    });

    if (newMappingsList.length > 0) {
      setVendorProductMappings((prev) => [...newMappingsList, ...prev]);

      const brandsToRegister = Array.from(new Set(newMappingsList.map((m) => m.brand).filter(Boolean)));
      if (brandsToRegister.length > 0) {
        registerVendorBrands(brandsToRegister);
      }
    }

    try {
      await fetchApi('/api/vendor-products/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ vendorId, mappings, userName: currentUser.name }),
      });
    } catch (e) {
      console.warn('Backend bulk mapping warning:', e);
    }

    pushNotification(
      'Products Imported to Vendor',
      `Imported ${added} new and updated ${updated} products for ${targetVendor?.companyName || vendorId}`,
      'SUCCESS',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']
    );

    return { added, updated, skipped: 0 };
  };

  // Global Product Type Master & One-Click Vendor Linking Methods
  const addProductTypeToMaster = async (name: string, category?: string): Promise<ProductTypeMasterItem> => {
    const cleanName = (name || '').trim();
    if (!cleanName) throw new Error('Product type name cannot be empty');

    const norm = cleanName.toLowerCase();
    const existing = productTypes.find((pt) => pt.name.toLowerCase().trim() === norm);
    if (existing) return existing;

    const newPT: ProductTypeMasterItem = {
      id: `PT-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 1000)}`,
      name: cleanName,
      category: category || 'General',
      isActive: true,
      createdAt: new Date().toISOString(),
    };

    setProductTypes((prev) => [...prev, newPT]);

    try {
      const res = await fetchApi('/api/product-types', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: cleanName, category, userName: currentUser.name }),
      });
      if (res.ok) {
        const d = await res.json();
        if (d.productType) {
          setProductTypes((prev) => prev.map((pt) => (pt.id === newPT.id ? d.productType : pt)));
          return d.productType;
        }
      }
    } catch (e) {
      console.warn('Backend product type sync notice:', e);
    }

    return newPT;
  };

  const addProductTypeToVendor = async (
    vendorId: string,
    productTypeName: string,
    category?: string,
    brand?: string
  ): Promise<{ productType: ProductTypeMasterItem; mapping: VendorProductMapping }> => {
    const cleanName = (productTypeName || '').trim();
    if (!cleanName) throw new Error('Please enter a product type.');

    const cleanBrand = (brand || '').trim();
    const cleanCategory = (category || '').trim();
    const targetVendor = vendors.find((v) => v.id === vendorId);
    if (!targetVendor) throw new Error(`Vendor ${vendorId} not found.`);

    const normName = cleanName.toLowerCase();
    const normBrand = cleanBrand.toLowerCase();

    // Prevent duplicate associations
    const isAlreadyAdded = vendorProductMappings.some(
      (m) =>
        m.vendorId === vendorId &&
        m.status !== 'INACTIVE' &&
        (m.productName || m.productType || '').trim().toLowerCase() === normName &&
        ((!cleanBrand && (!m.brand || m.brand === 'Generic')) ||
          (cleanBrand && (m.brand || '').trim().toLowerCase() === normBrand))
    );

    if (isAlreadyAdded) {
      throw new Error(`"${cleanName}" is already added to ${targetVendor.companyName}${cleanBrand ? ` under brand "${cleanBrand}"` : ''}.`);
    }

    // 1. Ensure product type exists in local Product Type Master immediately
    let matchedPT = productTypes.find((pt) => pt.name.toLowerCase().trim() === normName);
    if (!matchedPT) {
      matchedPT = {
        id: `PT-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 1000)}`,
        name: cleanName,
        category: cleanCategory || 'General',
        isActive: true,
        createdAt: new Date().toISOString(),
      };
      setProductTypes((prev) => [...prev, matchedPT!]);
    }

    // 2. Create local mapping immediately for snappy UI
    const tempMappingId = `VPM-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const newMapping: VendorProductMapping = {
      id: tempMappingId,
      vendorId,
      vendorCode: targetVendor.vendorCode || vendorId,
      vendorName: targetVendor.companyName,
      productName: cleanName,
      productType: cleanName,
      category: cleanCategory || matchedPT.category || 'General',
      brand: cleanBrand || 'Generic',
      uom: 'NOS',
      supplyType: 'Authorized Distributor',
      availability: 'Regular Stock',
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setVendorProductMappings((prev) => [newMapping, ...prev]);

    // Update vendor in memory
    setVendors((prev) =>
      prev.map((v) => {
        if (v.id !== vendorId) return v;
        const nextProducts = [newMapping, ...(v.productsSupplied || [])];
        const nextBrands = cleanBrand && !(v.brandsSupplied || []).some((b) => b.toLowerCase().trim() === normBrand)
          ? [...(v.brandsSupplied || []), cleanBrand]
          : v.brandsSupplied || [];
        const nextCats = cleanCategory && !(v.materialCategories || []).some((c) => c.toLowerCase().trim() === cleanCategory.toLowerCase())
          ? [...(v.materialCategories || []), cleanCategory]
          : v.materialCategories || [];
        return {
          ...v,
          productsSupplied: nextProducts,
          brandsSupplied: nextBrands,
          materialCategories: nextCats,
        };
      })
    );

    if (cleanBrand) {
      registerVendorBrands([cleanBrand]);
    }

    // 3. Persist to real backend database via One-Click API
    try {
      const res = await fetchApi('/api/vendor-product-types', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          vendorId,
          productTypeName: cleanName,
          category: cleanCategory || undefined,
          brand: cleanBrand || undefined,
          userName: currentUser.name,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to save product type to database.');
      }

      const data = await res.json();
      if (data.mapping) {
        setVendorProductMappings((prev) =>
          prev.map((m) => (m.id === tempMappingId ? data.mapping : m))
        );
      }
      if (data.productType) {
        setProductTypes((prev) => {
          const idx = prev.findIndex((pt) => pt.name.toLowerCase().trim() === normName);
          if (idx !== -1) {
            const copy = [...prev];
            copy[idx] = data.productType;
            return copy;
          }
          return [...prev, data.productType];
        });
      }

      pushAudit(
        'VENDOR_PRODUCT_MAPPED',
        'VendorMaster',
        data.mapping?.id || tempMappingId,
        `Mapped product type "${cleanName}" (${cleanBrand || 'No Brand'}) to vendor ${targetVendor.companyName}`
      );

      return {
        productType: data.productType || matchedPT,
        mapping: data.mapping || newMapping,
      };
    } catch (err: any) {
      console.error('Error in addProductTypeToVendor:', err);
      // Rollback on failure
      setVendorProductMappings((prev) => prev.filter((m) => m.id !== tempMappingId));
      throw err;
    }
  };

  const removeProductTypeFromVendor = async (mappingId: string): Promise<void> => {
    const targetMapping = vendorProductMappings.find((m) => m.id === mappingId);
    if (!targetMapping) return;

    // Remove from local vendor mappings
    setVendorProductMappings((prev) => prev.filter((m) => m.id !== mappingId));

    // Remove from vendor's productsSupplied
    setVendors((prev) =>
      prev.map((v) => {
        if (v.id === targetMapping.vendorId && Array.isArray(v.productsSupplied)) {
          return {
            ...v,
            productsSupplied: v.productsSupplied.filter((p) => p.id !== mappingId),
          };
        }
        return v;
      })
    );

    // Call backend DELETE endpoint
    try {
      await fetchApi(
        `/api/vendor-products/${encodeURIComponent(mappingId)}?user=${encodeURIComponent(currentUser.name)}`,
        { method: 'DELETE' }
      );
    } catch (e) {
      console.warn('Backend delete mapping warning:', e);
    }

    pushAudit(
      'VENDOR_PRODUCT_UNMAPPED',
      'VendorMaster',
      mappingId,
      `Removed product type "${targetMapping.productName}" from vendor ${targetMapping.vendorName} (global master preserved)`
    );
  };

  // Automated Cloud Backup & Recovery Methods
  const triggerManualBackup = (): BackupRecord => {
    try {
      const bkp = createBackupSnapshot({
        vendors,
        categories,
        requirements,
        quotations: customerQuotations,
        customerPOs,
        vendorPOs,
        auditLogs,
        documents,
      }, 'MANUAL');
      setBackups(getSavedBackups());
      setBackupSettings(getBackupSettings());
      setBackupFailureAlert(null);
      pushAudit('BACKUP_CREATED', 'BackupRecord', bkp.id, `Manual cloud backup snapshot created (${bkp.sizeFormatted})`);
      pushNotification('Cloud Backup Successful', `Application snapshot ${bkp.id} backed up securely (${bkp.sizeFormatted}).`, 'SUCCESS', ['SUPER_ADMIN']);
      return bkp;
    } catch (err: any) {
      setBackupFailureAlert({
        timestamp: new Date().toISOString(),
        error: err?.message || 'Manual backup generation failed',
      });
      pushNotification('Backup Failed', 'Your latest data could not be backed up. Please check storage capacity.', 'WARNING', ['SUPER_ADMIN']);
      throw err;
    }
  };

  const updateBackupSettingsState = (newSettings: Partial<BackupSettings>) => {
    const updated = { ...backupSettings, ...newSettings };
    setBackupSettings(updated);
    localStorage.setItem('mro_backup_settings_v1', JSON.stringify(updated));
    pushAudit('BACKUP_SETTINGS_UPDATED', 'Settings', 'BackupConfig', 'Updated automated backup schedule configuration');
  };

  const restoreFromBackupRecord = (backupId: string): boolean => {
    const target = backups.find((b) => b.id === backupId);
    if (!target || !target.dataSnapshot) return false;

    try {
      const parsed = JSON.parse(target.dataSnapshot);
      if (parsed.vendors) setVendors(parsed.vendors);
      if (parsed.categories) setCategories(parsed.categories);
      if (parsed.requirements) setRequirements(parsed.requirements);
      if (parsed.quotations) setCustomerQuotations(parsed.quotations);
      if (parsed.customerPOs) setCustomerPOs(parsed.customerPOs);
      if (parsed.vendorPOs) setVendorPOs(parsed.vendorPOs);
      if (parsed.auditLogs) setAuditLogs(parsed.auditLogs);
      if (parsed.documents) setDocuments(parsed.documents);

      pushAudit('DATA_RESTORED', 'BackupRecord', backupId, `Restored full system state from backup snapshot ${target.versionLabel}`);
      pushNotification('System Restored', `All application data restored successfully from ${target.versionLabel}.`, 'SUCCESS', ['SUPER_ADMIN']);
      return true;
    } catch (err: any) {
      console.error('Failed to restore from backup', err);
      pushNotification('Restore Failed', `Could not parse backup snapshot: ${err.message}`, 'WARNING', ['SUPER_ADMIN']);
      return false;
    }
  };

  const testBackupRecord = (backupId: string) => {
    const target = backups.find((b) => b.id === backupId);
    if (!target) return { valid: false, message: 'Backup record not found', details: {} };
    return testBackupIntegrity(target);
  };

  const clearBackupFailureAlert = () => {
    clearBackupFailure();
    setBackupFailureAlert(null);
  };

  // Dual-mode Engine Actions
  const setDataMode = (newMode: DataMode) => {
    if (newMode === dataMode) return;

    // 1. Flush and save current memory state to current mode
    const curPrefix = getStoragePrefix(dataMode);
    localStorage.setItem(`${curPrefix}customers`, JSON.stringify(customers));
    localStorage.setItem(`${curPrefix}vendors`, JSON.stringify(vendors));
    localStorage.setItem(`${curPrefix}products`, JSON.stringify(products));
    localStorage.setItem(`${curPrefix}requirements`, JSON.stringify(requirements));
    localStorage.setItem(`${curPrefix}quotations`, JSON.stringify(customerQuotations));
    localStorage.setItem(`${curPrefix}customer_pos`, JSON.stringify(customerPOs));
    localStorage.setItem(`${curPrefix}vendor_pos`, JSON.stringify(vendorPOs));
    localStorage.setItem(`${curPrefix}proforma_invoices`, JSON.stringify(proformaInvoices));
    localStorage.setItem(`${curPrefix}payments`, JSON.stringify(payments));
    localStorage.setItem(`${curPrefix}dispatches`, JSON.stringify(dispatches));
    localStorage.setItem(`${curPrefix}deliveries`, JSON.stringify(deliveries));
    localStorage.setItem(`${curPrefix}rfqs`, JSON.stringify(rfqs));
    localStorage.setItem(`${curPrefix}vendor_quotes`, JSON.stringify(vendorQuotes));

    // 2. Hydrate target mode
    const targetCust = loadCollection('customers', newMode, newMode === 'LOCAL_BUSINESS' ? INITIAL_LOCAL_CUSTOMERS : INITIAL_CUSTOMERS);
    const targetVend = loadCollection('vendors', newMode, newMode === 'LOCAL_BUSINESS' ? INITIAL_LOCAL_VENDORS : INITIAL_VENDORS);
    const targetProd = loadCollection('products', newMode, INITIAL_PRODUCTS);
    const targetReqs = loadCollection(
      'requirements',
      newMode,
      newMode === 'LOCAL_BUSINESS' ? [] : [INITIAL_REQUIREMENT_001, INITIAL_REQUIREMENT_002, INITIAL_REQUIREMENT_003, INITIAL_REQUIREMENT_004]
    );
    const targetRfqs = loadCollection('rfqs', newMode, newMode === 'LOCAL_BUSINESS' ? [] : [INITIAL_RFQ_001, INITIAL_RFQ_002, INITIAL_RFQ_003]);
    const targetVq = loadCollection(
      'vendor_quotes',
      newMode,
      newMode === 'LOCAL_BUSINESS' ? [] : [...INITIAL_VENDOR_QUOTES_001, ...INITIAL_VENDOR_QUOTES_002, ...INITIAL_VENDOR_QUOTES_003]
    );
    const targetQtns = loadCollection('quotations', newMode, newMode === 'LOCAL_BUSINESS' ? [] : [INITIAL_CUSTOMER_QUOTATION_001, INITIAL_CUSTOMER_QUOTATION_002]);
    const targetCpo = loadCollection('customer_pos', newMode, newMode === 'LOCAL_BUSINESS' ? [] : [INITIAL_CUSTOMER_PO_001, INITIAL_CUSTOMER_PO_002]);
    const targetVpo = loadCollection('vendor_pos', newMode, newMode === 'LOCAL_BUSINESS' ? [] : [INITIAL_VENDOR_PO_001, INITIAL_VENDOR_PO_002]);
    const targetPi = loadCollection('proforma_invoices', newMode, newMode === 'LOCAL_BUSINESS' ? [] : [INITIAL_PROFORMA_INVOICE_001, INITIAL_PROFORMA_INVOICE_002]);
    const targetPay = loadCollection('payments', newMode, newMode === 'LOCAL_BUSINESS' ? [] : [INITIAL_PAYMENT_001, INITIAL_PAYMENT_002]);
    const targetDsp = loadCollection('dispatches', newMode, newMode === 'LOCAL_BUSINESS' ? [] : [INITIAL_DISPATCH_001, INITIAL_DISPATCH_002]);
    const targetDel = loadCollection('deliveries', newMode, newMode === 'LOCAL_BUSINESS' ? [] : [INITIAL_DELIVERY_001, INITIAL_DELIVERY_002]);

    setCustomers(targetCust);
    setVendors(targetVend);
    setProducts(targetProd);
    setRequirements(targetReqs);
    setRfqs(targetRfqs);
    setVendorQuotes(targetVq);
    setCustomerQuotations(targetQtns);
    setCustomerPOs(targetCpo);
    setVendorPOs(targetVpo);
    setProformaInvoices(targetPi);
    setPayments(targetPay);
    setDispatches(targetDsp);
    setDeliveries(targetDel);

    setDataModeState(newMode);
    localStorage.setItem('mro_active_data_mode', newMode);

    pushNotification(
      'Data Mode Switched',
      newMode === 'LOCAL_BUSINESS'
        ? 'Switched to My Local Business Mode. All entries are saved locally on your device.'
        : 'Switched to Demo Sandbox Mode with mock industrial pipeline.',
      'INFO',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE', 'ACCOUNTS_USER']
    );
    pushAudit('DATA_MODE_CHANGED', 'System', newMode, `Switched storage engine to ${newMode}`);
  };

  const copyDemoToLocalBusiness = () => {
    setCustomers(INITIAL_CUSTOMERS);
    setVendors(INITIAL_VENDORS);
    setProducts(INITIAL_PRODUCTS);
    setRequirements([INITIAL_REQUIREMENT_001, INITIAL_REQUIREMENT_002, INITIAL_REQUIREMENT_003, INITIAL_REQUIREMENT_004]);
    setRfqs([INITIAL_RFQ_001, INITIAL_RFQ_002, INITIAL_RFQ_003]);
    setVendorQuotes([...INITIAL_VENDOR_QUOTES_001, ...INITIAL_VENDOR_QUOTES_002, ...INITIAL_VENDOR_QUOTES_003]);
    setCustomerQuotations([INITIAL_CUSTOMER_QUOTATION_001, INITIAL_CUSTOMER_QUOTATION_002]);
    setCustomerPOs([INITIAL_CUSTOMER_PO_001, INITIAL_CUSTOMER_PO_002]);
    setVendorPOs([INITIAL_VENDOR_PO_001, INITIAL_VENDOR_PO_002]);
    setProformaInvoices([INITIAL_PROFORMA_INVOICE_001, INITIAL_PROFORMA_INVOICE_002]);
    setPayments([INITIAL_PAYMENT_001, INITIAL_PAYMENT_002]);
    setDispatches([INITIAL_DISPATCH_001, INITIAL_DISPATCH_002]);
    setDeliveries([INITIAL_DELIVERY_001, INITIAL_DELIVERY_002]);

    pushNotification('Demo Seeded to Local', 'Demo customer and vendor catalog copied into your private local workspace.', 'SUCCESS', ['SUPER_ADMIN']);
    pushAudit('DATA_CLONED', 'System', 'LOCAL_BUSINESS', 'Copied demo catalog into local business workspace');
  };

  const resetCurrentModeData = () => {
    if (dataMode === 'LOCAL_BUSINESS') {
      setCustomers(INITIAL_LOCAL_CUSTOMERS);
      setVendors(INITIAL_LOCAL_VENDORS);
      setProducts(INITIAL_PRODUCTS);
      setRequirements([]);
      setRfqs([]);
      setVendorQuotes([]);
      setCustomerQuotations([]);
      setCustomerPOs([]);
      setVendorPOs([]);
      setProformaInvoices([]);
      setPayments([]);
      setDispatches([]);
      setDeliveries([]);
    } else {
      setCustomers(INITIAL_CUSTOMERS);
      setVendors(INITIAL_VENDORS);
      setProducts(INITIAL_PRODUCTS);
      setRequirements([INITIAL_REQUIREMENT_001, INITIAL_REQUIREMENT_002, INITIAL_REQUIREMENT_003, INITIAL_REQUIREMENT_004]);
      setRfqs([INITIAL_RFQ_001, INITIAL_RFQ_002, INITIAL_RFQ_003]);
      setVendorQuotes([...INITIAL_VENDOR_QUOTES_001, ...INITIAL_VENDOR_QUOTES_002, ...INITIAL_VENDOR_QUOTES_003]);
      setCustomerQuotations([INITIAL_CUSTOMER_QUOTATION_001, INITIAL_CUSTOMER_QUOTATION_002]);
      setCustomerPOs([INITIAL_CUSTOMER_PO_001, INITIAL_CUSTOMER_PO_002]);
      setVendorPOs([INITIAL_VENDOR_PO_001, INITIAL_VENDOR_PO_002]);
      setProformaInvoices([INITIAL_PROFORMA_INVOICE_001, INITIAL_PROFORMA_INVOICE_002]);
      setPayments([INITIAL_PAYMENT_001, INITIAL_PAYMENT_002]);
      setDispatches([INITIAL_DISPATCH_001, INITIAL_DISPATCH_002]);
      setDeliveries([INITIAL_DELIVERY_001, INITIAL_DELIVERY_002]);
    }
    pushNotification('Workspace Reset', `Active records in ${dataMode === 'LOCAL_BUSINESS' ? 'Local Business' : 'Demo Sandbox'} reset to defaults.`, 'WARNING', ['SUPER_ADMIN']);
    pushAudit('DATA_RESET', 'System', dataMode, `Reset active dataset in ${dataMode}`);
  };

  const exportFullBackup = () => {
    const backup = {
      app: 'ProcureMRO Supply Chain ERP',
      version: '2.6',
      exportedAt: new Date().toISOString(),
      mode: dataMode,
      data: {
        customers,
        vendors,
        products,
        requirements,
        rfqs,
        vendorQuotes,
        customerQuotations,
        customerPOs,
        vendorPOs,
        proformaInvoices,
        payments,
        dispatches,
        deliveries,
      },
    };
    exportDataToJSON(backup, `ProcureMRO_Database_Backup_${dataMode}_${new Date().toISOString().split('T')[0]}.json`);
    pushAudit('BACKUP_EXPORTED', 'System', dataMode, `Full JSON database backup downloaded for ${dataMode}`);
  };

  const restoreFullBackup = (jsonContent: string): boolean => {
    try {
      const parsed = JSON.parse(jsonContent);
      const d = parsed.data || parsed;
      if (d.customers && Array.isArray(d.customers)) setCustomers(d.customers);
      if (d.vendors && Array.isArray(d.vendors)) setVendors(d.vendors);
      if (d.products && Array.isArray(d.products)) setProducts(d.products);
      if (d.requirements && Array.isArray(d.requirements)) setRequirements(d.requirements);
      if (d.rfqs && Array.isArray(d.rfqs)) setRfqs(d.rfqs);
      if (d.vendorQuotes && Array.isArray(d.vendorQuotes)) setVendorQuotes(d.vendorQuotes);
      if (d.customerQuotations && Array.isArray(d.customerQuotations)) setCustomerQuotations(d.customerQuotations);
      if (d.customerPOs && Array.isArray(d.customerPOs)) setCustomerPOs(d.customerPOs);
      if (d.vendorPOs && Array.isArray(d.vendorPOs)) setVendorPOs(d.vendorPOs);
      if (d.proformaInvoices && Array.isArray(d.proformaInvoices)) setProformaInvoices(d.proformaInvoices);
      if (d.payments && Array.isArray(d.payments)) setPayments(d.payments);
      if (d.dispatches && Array.isArray(d.dispatches)) setDispatches(d.dispatches);
      if (d.deliveries && Array.isArray(d.deliveries)) setDeliveries(d.deliveries);

      pushNotification('Backup Restored', 'Full dataset successfully restored into current workspace.', 'SUCCESS', ['SUPER_ADMIN']);
      pushAudit('BACKUP_RESTORED', 'System', dataMode, 'Restored database from JSON backup file');
      return true;
    } catch (err) {
      console.error('Failed to parse backup JSON:', err);
      return false;
    }
  };

  // Company Master Operations
  const addCompany = (compData: Omit<Company, 'id' | 'createdAt' | 'companyCode'>): Company => {
    const count = companies.length + 1;
    const newId = `CMP-${String(count).padStart(3, '0')}`;
    const newComp: Company = {
      ...compData,
      id: newId,
      companyCode: newId,
      status: compData.status || 'ACTIVE',
      createdAt: new Date().toISOString().split('T')[0],
    };
    setCompanies((prev) => [newComp, ...prev]);

    // Mirror to customers list for unified backwards compatibility
    const mirrorCust: Customer = {
      id: newId,
      companyName: newComp.companyName,
      contactPerson: newComp.contactPerson || 'Purchase Incharge',
      mobile: newComp.mobile || '',
      email: newComp.email || '',
      address: newComp.address || '',
      city: newComp.city || '',
      state: newComp.state || '',
      pincode: newComp.pincode || '',
      gstin: newComp.gstin || '',
      pan: newComp.pan || '',
      paymentTerms: newComp.paymentTerms || '30 Days Net',
      deliveryAddress: newComp.deliveryAddress || newComp.address || '',
      remarks: newComp.remarks,
      status: newComp.status,
      companyCode: newId,
      createdAt: newComp.createdAt,
    };
    setCustomers((prev) => {
      if (prev.some((c) => c.id === newId)) return prev;
      return [mirrorCust, ...prev];
    });

    fetchApi('/api/companies', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newComp),
    }).catch(() => {});

    pushAudit('COMPANY_CREATED', 'Company', newId, `Company ${newComp.companyName} registered with code ${newId}`);
    return newComp;
  };

  const updateCompany = (updated: Company) => {
    setCompanies((prev) => prev.map((c) => (c.id === updated.id ? updated : c)));
    // Also update matching customer if present
    setCustomers((prev) =>
      prev.map((c) =>
        c.id === updated.id
          ? {
              ...c,
              companyName: updated.companyName,
              address: updated.address,
              city: updated.city,
              state: updated.state,
              pincode: updated.pincode,
              gstin: updated.gstin,
              remarks: updated.remarks,
              status: updated.status,
            }
          : c
      )
    );
    // Also update companyName in linked purchase executives
    setPurchaseExecutives((prev) =>
      prev.map((pe) => (pe.companyId === updated.id ? { ...pe, companyName: updated.companyName } : pe))
    );

    fetchApi('/api/companies', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).catch(() => {});

    pushAudit('COMPANY_UPDATED', 'Company', updated.id, `Updated company ${updated.companyName}`);
  };

  const deleteCompany = (id: string): { success: boolean; message: string } => {
    const comp = companies.find((c) => c.id === id);
    if (!comp) return { success: false, message: 'Company not found' };

    const linkedReqs = requirements.filter((r) => r.companyId === id || r.customerId === id);
    if (linkedReqs.length > 0) {
      updateCompany({ ...comp, status: 'INACTIVE' });
      return {
        success: true,
        message: `Company "${comp.companyName}" has ${linkedReqs.length} linked requirement(s). Status set to INACTIVE for audit integrity.`,
      };
    }

    setCompanies((prev) => prev.filter((c) => c.id !== id));
    setCustomers((prev) => prev.filter((c) => c.id !== id));

    fetchApi(`/api/companies/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});

    pushAudit('COMPANY_DELETED', 'Company', id, `Removed company ${comp.companyName}`);
    return { success: true, message: `Company "${comp.companyName}" removed successfully.` };
  };

  // Purchase Executive Master Operations
  const addPurchaseExecutive = (execData: Omit<PurchaseExecutive, 'id' | 'createdAt'>): PurchaseExecutive => {
    const count = purchaseExecutives.length + 1;
    const newId = `PE-${String(count).padStart(3, '0')}`;
    const targetComp = companies.find((c) => c.id === execData.companyId);
    const newExec: PurchaseExecutive = {
      ...execData,
      id: newId,
      companyName: targetComp?.companyName || execData.companyName,
      status: execData.status || 'ACTIVE',
      createdAt: new Date().toISOString().split('T')[0],
      updatedAt: new Date().toISOString().split('T')[0],
    };
    setPurchaseExecutives((prev) => [newExec, ...prev]);

    fetchApi('/api/purchase-executives', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newExec),
    }).catch(() => {});

    pushAudit(
      'PURCHASE_EXECUTIVE_CREATED',
      'PurchaseExecutive',
      newId,
      `Added ${newExec.name} (${newExec.designation}) for ${newExec.companyName}`
    );
    return newExec;
  };

  const updatePurchaseExecutive = (updated: PurchaseExecutive) => {
    setPurchaseExecutives((prev) =>
      prev.map((e) => (e.id === updated.id ? { ...updated, updatedAt: new Date().toISOString().split('T')[0] } : e))
    );

    fetchApi('/api/purchase-executives', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updated),
    }).catch(() => {});

    pushAudit('PURCHASE_EXECUTIVE_UPDATED', 'PurchaseExecutive', updated.id, `Updated ${updated.name} for ${updated.companyName}`);
  };

  const deletePurchaseExecutive = (id: string): { success: boolean; message: string } => {
    const exec = purchaseExecutives.find((e) => e.id === id);
    if (!exec) return { success: false, message: 'Executive not found' };

    const linkedReqs = requirements.filter((r) => r.purchaseExecutiveId === id);
    if (linkedReqs.length > 0) {
      updatePurchaseExecutive({ ...exec, status: 'INACTIVE' });
      return {
        success: true,
        message: `Executive "${exec.name}" has ${linkedReqs.length} linked requirement(s). Status set to INACTIVE to preserve audit trail.`,
      };
    }

    setPurchaseExecutives((prev) => prev.filter((e) => e.id !== id));

    fetchApi(`/api/purchase-executives/${encodeURIComponent(id)}`, { method: 'DELETE' }).catch(() => {});
    pushAudit('PURCHASE_EXECUTIVE_DELETED', 'PurchaseExecutive', id, `Removed executive ${exec.name}`);
    return { success: true, message: `Executive "${exec.name}" removed.` };
  };

  const getExecutivesByCompany = (companyId: string): PurchaseExecutive[] => {
    return purchaseExecutives.filter((e) => e.companyId === companyId);
  };

  // Add Requirement with Atomic Sequence ID & Permanent Cloud Persistence
  const addRequirement = (reqData: {
    customerId: string;
    customerName: string;
    contactPerson: string;
    customerEmail: string;
    customerMobile: string;
    requirementDate: string;
    requiredDeliveryDate: string;
    receivedRequirementDate?: string;
    expectedDeliveryDate?: string;
    priority?: 'High' | 'Medium' | 'Low';
    items: Omit<RequirementItem, 'id'>[];
    remarks?: string;
    companyId?: string;
    companyName?: string;
    companyCode?: string;
    purchaseExecutiveId?: string;
    purchaseExecutiveName?: string;
    purchaseExecutiveDesignation?: string;
    purchaseExecutiveMobile?: string;
    purchaseExecutiveEmail?: string;
    rfqNumber?: string;
    requirementSource?: 'Email' | 'WhatsApp' | 'Phone' | 'Manual' | 'Other' | string;
    referenceNumber?: string;
  }): CustomerRequirement => {
    const year = new Date().getFullYear();

    // Scan all existing requirement IDs and RFQ numbers to find the true maximum sequence
    let maxSeq = 0;
    const allSeen = [...requirements];
    try {
      const ls = localStorage.getItem('erp_live_requirements');
      if (ls) {
        const parsed = JSON.parse(ls);
        if (Array.isArray(parsed)) allSeen.push(...parsed);
      }
    } catch {}

    allSeen.forEach((r) => {
      const match = (r.rfqNumber || r.id || '').match(/(\d+)$/);
      if (match) {
        const num = parseInt(match[1], 10);
        if (!isNaN(num) && num > maxSeq) maxSeq = num;
      }
    });

    const nextSeq = Math.max(maxSeq + 1, 5);
    const reqId = `REQ-${year}-${String(nextSeq).padStart(5, '0')}`;
    const generatedRfqNumber =
      reqData.rfqNumber && reqData.rfqNumber.trim() !== ''
        ? reqData.rfqNumber.trim()
        : `RFQ-${year}-${String(nextSeq).padStart(5, '0')}`;

    const targetCompanyId = reqData.companyId || reqData.customerId;
    const targetCompanyName = reqData.companyName || reqData.customerName;

    // Resolve executive info
    let execName = reqData.purchaseExecutiveName;
    let execDesig = reqData.purchaseExecutiveDesignation;
    let execMobile = reqData.purchaseExecutiveMobile;
    let execEmail = reqData.purchaseExecutiveEmail;

    if (reqData.purchaseExecutiveId) {
      const matched = purchaseExecutives.find((pe) => pe.id === reqData.purchaseExecutiveId);
      if (matched) {
        execName = matched.name;
        execDesig = matched.designation;
        execMobile = matched.mobile;
        execEmail = matched.email;
      }
    }

    const itemsWithIds: RequirementItem[] = reqData.items.map((item, idx) => ({
      ...item,
      id: `ITEM-${String(nextSeq).padStart(3, '0')}-${String.fromCharCode(65 + idx)}`,
      purchaseExecutiveId: item.purchaseExecutiveId || reqData.purchaseExecutiveId,
      purchaseExecutiveName: item.purchaseExecutiveName || execName,
      purchaseExecutiveDesignation: item.purchaseExecutiveDesignation || execDesig,
    }));

    const nowIso = new Date().toISOString();
    const newReq: CustomerRequirement = {
      id: reqId,
      customerId: targetCompanyId,
      customerName: targetCompanyName,
      companyId: targetCompanyId,
      companyName: targetCompanyName,
      companyCode: reqData.companyCode || targetCompanyId,
      purchaseExecutiveId: reqData.purchaseExecutiveId,
      purchaseExecutiveName: execName || reqData.contactPerson,
      purchaseExecutiveDesignation: execDesig || 'Purchase Executive',
      purchaseExecutiveMobile: execMobile || reqData.customerMobile,
      purchaseExecutiveEmail: execEmail || reqData.customerEmail,
      rfqNumber: generatedRfqNumber,
      requirementSource: reqData.requirementSource || 'Email',
      referenceNumber: reqData.referenceNumber,
      contactPerson: execName || reqData.contactPerson,
      customerEmail: execEmail || reqData.customerEmail,
      customerMobile: execMobile || reqData.customerMobile,
      requirementDate: reqData.requirementDate || reqData.receivedRequirementDate || nowIso.split('T')[0],
      requiredDeliveryDate: reqData.requiredDeliveryDate || reqData.receivedRequirementDate || nowIso.split('T')[0],
      receivedRequirementDate: reqData.receivedRequirementDate || reqData.requirementDate || nowIso.split('T')[0],
      expectedDeliveryDate: reqData.expectedDeliveryDate,
      priority: reqData.priority || 'Medium',
      items: itemsWithIds,
      attachments: [
        {
          name: `Indent_Doc_${reqId}.pdf`,
          type: 'PDF',
          size: '1.2 MB',
          url: '#',
          uploadedAt: 'Just now',
        },
      ],
      status: 'NEW_REQUIREMENT',
      createdBy: currentUser.name,
      createdAt: nowIso,
      lastModifiedAt: nowIso,
      lastModifiedBy: currentUser.name,
      isDeleted: false,
      dbSaveStatus: 'COMMITTED',
      cloudSyncStatus: 'SYNCED',
      remarks: reqData.remarks,
    };

    const nextReqs = [newReq, ...requirements.filter((r) => r.id !== reqId && r.rfqNumber !== generatedRfqNumber)];
    setRequirements(nextReqs);

    try {
      localStorage.setItem('erp_live_requirements', JSON.stringify(nextReqs));
      localStorage.setItem(`${activePrefix}requirements`, JSON.stringify(nextReqs));
    } catch {}

    // Persist new requirement to authoritative backend database immediately
    fetchApi('/api/requirements', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...newReq, createdBy: currentUser.name, userRole: currentUser.role }),
    }).catch((err) => console.warn('[API] Add requirement sync warning:', err));

    pushMutationToCloud({ requirements: nextReqs });

    pushAudit(
      'REQUIREMENT_CREATED',
      'CustomerRequirement',
      reqId,
      `New requirement ${reqId} (${generatedRfqNumber}) permanently saved for ${targetCompanyName} by ${execName || reqData.contactPerson} (${itemsWithIds.length} items)`
    );
    pushNotification(
      'New Requirement Logged',
      `${targetCompanyName} (${execName || reqData.contactPerson}) submitted ${reqId}. Saved to database successfully.`,
      'SUCCESS',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE'],
      'requirements',
      reqId
    );

    return newReq;
  };

  const updateRequirement = (updated: CustomerRequirement) => {
    const nowIso = new Date().toISOString();
    const cleanUpdated: CustomerRequirement = {
      ...updated,
      lastModifiedAt: nowIso,
      lastModifiedBy: currentUser.name,
      dbSaveStatus: 'COMMITTED',
      cloudSyncStatus: 'SYNCED',
    };

    const nextReqs = requirements.map((r) => (r.id === updated.id ? cleanUpdated : r));
    setRequirements(nextReqs);

    try {
      localStorage.setItem('erp_live_requirements', JSON.stringify(nextReqs));
      localStorage.setItem(`${activePrefix}requirements`, JSON.stringify(nextReqs));
    } catch {}

    // Persist update to authoritative backend database
    fetchApi(`/api/requirements/${encodeURIComponent(updated.id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...cleanUpdated, updatedBy: currentUser.name, userRole: currentUser.role }),
    }).catch((err) => console.warn('[API] Update requirement sync warning:', err));

    pushMutationToCloud({ requirements: nextReqs });
    pushAudit('REQUIREMENT_UPDATED', 'CustomerRequirement', updated.id, `Requirement ${updated.id} details updated.`);
  };

  // Soft Delete Requirement - Preserves record in database for Super Admin audit & recovery
  const deleteRequirement = (id: string, reason: string = 'Archived by user'): { success: boolean; message: string } => {
    const target = requirements.find((r) => r.id === id || r.rfqNumber === id);
    if (!target) return { success: false, message: 'Requirement not found' };

    const actualId = target.id;
    const actualRfq = target.rfqNumber || target.id;

    const hasPO =
      customerPOs.some((c) => c.requirementId === actualId) ||
      vendorPOs.some((v) => v.requirementId === actualId);
    if (hasPO) {
      return {
        success: false,
        message: `Cannot delete requirement ${actualRfq} as purchase orders have already been issued. Set status to CANCELLED instead.`,
      };
    }

    const nowIso = new Date().toISOString();
    const softDeletedReq: CustomerRequirement = {
      ...target,
      isDeleted: true,
      deletedAt: nowIso,
      deletedBy: currentUser.name,
      deletedReason: reason,
      lastModifiedAt: nowIso,
      lastModifiedBy: currentUser.name,
    };

    const nextReqs = requirements.map((r) => (r.id === actualId ? softDeletedReq : r));
    setRequirements(nextReqs);

    try {
      localStorage.setItem('erp_live_requirements', JSON.stringify(nextReqs));
      localStorage.setItem(`${activePrefix}requirements`, JSON.stringify(nextReqs));
    } catch {}

    // Call server soft-delete endpoint with audit reason
    fetchApi(
      `/api/requirements/${encodeURIComponent(actualId)}?user=${encodeURIComponent(currentUser.name)}&role=${encodeURIComponent(currentUser.role)}&reason=${encodeURIComponent(reason)}`,
      { method: 'DELETE' }
    ).catch((err) => {
      console.error('[API] Server delete requirement failed:', err);
    });

    pushMutationToCloud({ requirements: nextReqs });

    pushAudit(
      'REQUIREMENT_SOFT_DELETED',
      'CustomerRequirement',
      actualRfq,
      `Requirement ${actualRfq} (${actualId}) soft-deleted by ${currentUser.name}. Reason: ${reason}. Record safely preserved in Deleted RFQs.`
    );
    return {
      success: true,
      message: `Requirement ${actualRfq} moved to Deleted RFQs archive. It can be restored anytime by Super Admin.`,
    };
  };

  // Restore Soft-Deleted Requirement back to Active Register
  const restoreRequirement = (id: string): { success: boolean; message: string } => {
    const target = requirements.find((r) => r.id === id || r.rfqNumber === id);
    if (!target) return { success: false, message: 'Requirement not found' };

    const actualId = target.id;
    const actualRfq = target.rfqNumber || target.id;
    const nowIso = new Date().toISOString();

    const restoredReq: CustomerRequirement = {
      ...target,
      isDeleted: false,
      deletedAt: undefined,
      deletedBy: undefined,
      deletedReason: undefined,
      lastModifiedAt: nowIso,
      lastModifiedBy: currentUser.name,
      dbSaveStatus: 'COMMITTED',
      cloudSyncStatus: 'SYNCED',
    };

    const nextReqs = requirements.map((r) => (r.id === actualId ? restoredReq : r));
    setRequirements(nextReqs);

    try {
      localStorage.setItem('erp_live_requirements', JSON.stringify(nextReqs));
      localStorage.setItem(`${activePrefix}requirements`, JSON.stringify(nextReqs));
    } catch {}

    // Call server restore endpoint
    fetchApi(
      `/api/requirements/${encodeURIComponent(actualId)}/restore?user=${encodeURIComponent(currentUser.name)}&role=${encodeURIComponent(currentUser.role)}`,
      { method: 'POST' }
    ).catch((err) => {
      console.error('[API] Server restore requirement failed:', err);
    });

    pushMutationToCloud({ requirements: nextReqs });

    pushAudit(
      'REQUIREMENT_RESTORED',
      'CustomerRequirement',
      actualRfq,
      `Requirement ${actualRfq} restored to active register by ${currentUser.name}.`
    );
    return {
      success: true,
      message: `Requirement ${actualRfq} successfully restored to active register.`,
    };
  };

  // Send RFQ to Vendors
  const sendVendorEnquiry = (requirementId: string, vendorIds: string[], notes?: string): VendorEnquiry => {
    const year = new Date().getFullYear();
    const count = rfqs.length + 1;
    const rfqId = `RFQ-${year}-${String(count).padStart(5, '0')}`;

    const newRfq: VendorEnquiry = {
      id: rfqId,
      requirementId,
      vendorIds,
      sentDate: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
      status: 'SENT',
      notes,
    };

    setRfqs((prev) => [newRfq, ...prev]);
    updateRequirementStage(requirementId, 'ENQUIRY_SENT');

    pushAudit('RFQ_SENT', 'VendorEnquiry', rfqId, `Enquiry sent to ${vendorIds.length} vendor(s) for requirement ${requirementId}`);
    pushNotification(
      'New RFQ Enquiry Received',
      `You have received enquiry ${rfqId} for requirement ${requirementId}. Please submit your competitive rates.`,
      'ACTION_REQUIRED',
      ['VENDOR'],
      'enquiries',
      rfqId
    );

    fetchApi('/api/rfqs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newRfq),
    }).catch((err) => console.warn('[API] RFQ sync warning:', err));

    return newRfq;
  };

  // Helper to determine exact rate completion status for a requirement
  const getRateCompletionStatus = (requirementId: string) => {
    const req = requirements.find((r) => r.id === requirementId);
    const rfq = rfqs.find((r) => r.requirementId === requirementId);
    const matchingQuotes = vendorQuotes.filter(
      (v) =>
        v.requirementId === requirementId ||
        v.enquiryId === requirementId ||
        (rfq && (v.requirementId === rfq.id || v.enquiryId === rfq.id))
    );

    if (!req) {
      return {
        status: (matchingQuotes.length > 0 ? 'COMPLETED' : 'PENDING') as 'COMPLETED' | 'PARTIALLY_COMPLETED' | 'PENDING',
        totalItems: 0,
        quotedItemsCount: 0,
        missingItems: [] as RequirementItem[],
        quotesCount: matchingQuotes.length,
        quotes: matchingQuotes,
      };
    }

    const totalItems = req.items.length;
    // Collect all requirement item IDs that have at least one rate entry in any quote
    const quotedItemIds = new Set<string>();
    matchingQuotes.forEach((q) => {
      q.items.forEach((qi) => {
        if (qi.requirementItemId) {
          quotedItemIds.add(qi.requirementItemId);
        }
        if (qi.itemName) {
          const matchedItem = req.items.find(
            (it) => it.itemName.trim().toLowerCase() === qi.itemName.trim().toLowerCase()
          );
          if (matchedItem) {
            quotedItemIds.add(matchedItem.id);
          }
        }
      });
    });

    const missingItems = req.items.filter((it) => !quotedItemIds.has(it.id));
    const quotedItemsCount = totalItems - missingItems.length;

    let status: 'COMPLETED' | 'PARTIALLY_COMPLETED' | 'PENDING' = 'PENDING';
    if (matchingQuotes.length === 0) {
      status = 'PENDING';
    } else if (missingItems.length === 0) {
      status = 'COMPLETED';
    } else {
      status = 'PARTIALLY_COMPLETED';
    }

    return {
      status,
      totalItems,
      quotedItemsCount,
      missingItems,
      quotesCount: matchingQuotes.length,
      quotes: matchingQuotes,
    };
  };

  // Vendor Rate Submission (Direct Rate Entry & Sourced Quotes)
  const submitVendorQuote = (quoteData: {
    id?: string;
    enquiryId?: string;
    requirementId: string;
    customerName?: string;
    vendorId: string;
    vendorName: string;
    items: any[];
    validUntil?: string;
    paymentTerms?: string;
    remarks?: string;
    attachmentName?: string;
  }): VendorQuote => {
    const year = new Date().getFullYear();
    const count = vendorQuotes.length + 1;
    const vqId = quoteData.id || `VQ-${year}-${String(count).padStart(5, '0')}`;

    const targetReq = requirements.find((r) => r.id === quoteData.requirementId);

    const newQuote: VendorQuote = {
      id: vqId,
      enquiryId: quoteData.enquiryId || 'DIRECT_ENTRY',
      requirementId: quoteData.requirementId,
      customerName: quoteData.customerName || targetReq?.customerName || '',
      vendorId: quoteData.vendorId,
      vendorName: quoteData.vendorName,
      submissionDate: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
      status: 'SUBMITTED',
      validUntil: quoteData.validUntil || '15 Days',
      paymentTerms: quoteData.paymentTerms || '',
      remarks: quoteData.remarks,
      attachmentName: quoteData.attachmentName,
      items: quoteData.items,
    };

    setVendorQuotes((prev) => {
      const filtered = prev.filter((q) => q.id !== vqId);
      return [newQuote, ...filtered];
    });

    // Update requirement stage if currently in early stage
    if (targetReq && (targetReq.status === 'NEW_REQUIREMENT' || targetReq.status === 'ENQUIRY_SENT' || targetReq.status === 'RATE_RECEIVED')) {
      updateRequirementStage(quoteData.requirementId, 'RATE_RECEIVED');
    }

    // Persist to backend API (graceful background sync)
    fetchApi('/api/vendor-quotes', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newQuote),
    }).catch((err) => {
      console.warn('Backend /api/vendor-quotes sync notice:', err.message);
    });

    pushAudit('RATE_SUBMITTED', 'VendorQuote', vqId, `Vendor rate recorded for ${quoteData.vendorName} against requirement ${quoteData.requirementId}`);
    pushNotification(
      'Vendor Rate Recorded',
      `Rate entry ${vqId} from ${quoteData.vendorName} saved. Ready for Rate Comparison & Client Quotation.`,
      'SUCCESS',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE', 'PURCHASE_MANAGER'],
      'rate-comparison',
      quoteData.requirementId
    );

    return newQuote;
  };

  // Edit / Update Vendor Rate Quote
  const updateVendorQuote = (quote: VendorQuote): VendorQuote => {
    setVendorQuotes((prev) => prev.map((q) => (q.id === quote.id ? quote : q)));

    // Persist to backend API
    fetchApi(`/api/vendor-quotes/${quote.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(quote),
    }).catch((err) => {
      console.warn('Backend /api/vendor-quotes sync notice:', err.message);
    });

    pushAudit('VENDOR_RATE_UPDATED', 'VendorQuote', quote.id, `Updated vendor rate quote details for ${quote.vendorName}`);
    return quote;
  };

  // Delete Vendor Rate Quote
  const deleteVendorQuote = (id: string): { success: boolean; message?: string } => {
    const target = vendorQuotes.find((q) => q.id === id);
    if (!target) return { success: false, message: 'Vendor quote not found' };

    setVendorQuotes((prev) => prev.filter((q) => q.id !== id));

    // Persist to backend API
    fetchApi(`/api/vendor-quotes/${id}`, {
      method: 'DELETE',
    }).catch((err) => {
      console.warn('Backend /api/vendor-quotes sync notice:', err.message);
    });

    // Re-check requirement rates
    const remainingQuotes = vendorQuotes.filter((q) => q.id !== id && q.requirementId === target.requirementId);
    if (remainingQuotes.length === 0) {
      const req = requirements.find((r) => r.id === target.requirementId);
      if (req && req.status === 'RATE_RECEIVED') {
        updateRequirementStage(target.requirementId, 'NEW_REQUIREMENT');
      }
    }

    pushAudit('VENDOR_RATE_DELETED', 'VendorQuote', id, `Deleted rate quote from ${target.vendorName}`);
    return { success: true };
  };

  // Create Customer Quotation
  const createCustomerQuotation = (quoteData: any): CustomerQuotation => {
    const year = new Date().getFullYear();
    const count = customerQuotations.length + 1;
    const qtnId = `QTN-${year}-${String(count).padStart(5, '0')}`;

    const newQtn: CustomerQuotation = {
      ...quoteData,
      id: qtnId,
      date: new Date().toISOString().split('T')[0],
      status: 'SENT',
      pdfGenerated: true,
    };

    setCustomerQuotations((prev) => [newQtn, ...prev]);
    updateRequirementStage(quoteData.requirementId, 'QUOTATION_SENT');

    // Add doc record
    const docRecord: DocumentRecord = {
      id: `DOC-${Date.now().toString().slice(-5)}`,
      name: `Quotation_${qtnId}.pdf`,
      type: 'PDF',
      category: 'QUOTATION',
      associatedTransactionId: quoteData.requirementId,
      customerOrVendorName: quoteData.customerName,
      uploadedAt: new Date().toLocaleString(),
      size: '640 KB',
      url: '#',
    };
    setDocuments((prev) => [docRecord, ...prev]);

    pushAudit('QUOTATION_ISSUED', 'CustomerQuotation', qtnId, `Quotation ${qtnId} issued to ${quoteData.customerName} totaling ₹${newQtn.grandTotal.toLocaleString('en-IN')}`);
    pushNotification(
      'Formal Quotation Generated',
      `Quotation ${qtnId} sent to customer ${quoteData.customerName}. Download PDF or share via WhatsApp.`,
      'SUCCESS',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE', 'CUSTOMER'],
      'quotations',
      qtnId
    );

    fetchApi('/api/quotations', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newQtn),
    }).catch((err) => console.warn('[API] Quotation sync warning:', err));

    return newQtn;
  };

  // Customer PO Received
  const recordCustomerPO = (poData: {
    quotationId: string;
    requirementId: string;
    customerPoNumber: string;
    poDate: string;
    customerId: string;
    customerName: string;
    poAmount: number;
    deliveryAddress: string;
    paymentTerms: string;
    remarks?: string;
  }): CustomerPO => {
    const year = new Date().getFullYear();
    const count = customerPOs.length + 1;
    const cpoId = `CPO-${year}-${String(count).padStart(5, '0')}`;

    const newCpo: CustomerPO = {
      ...poData,
      id: cpoId,
      receivedDate: new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' }),
    };

    setCustomerPOs((prev) => [newCpo, ...prev]);
    updateRequirementStage(poData.requirementId, 'PO_RECEIVED');

    // Add doc
    const docRecord: DocumentRecord = {
      id: `DOC-${Date.now().toString().slice(-5)}`,
      name: `Customer_PO_${poData.customerPoNumber.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`,
      type: 'PDF',
      category: 'PO',
      associatedTransactionId: poData.requirementId,
      customerOrVendorName: poData.customerName,
      uploadedAt: new Date().toLocaleString(),
      size: '1.4 MB',
      url: '#',
    };
    setDocuments((prev) => [docRecord, ...prev]);

    pushAudit('CUSTOMER_PO_RECORDED', 'CustomerPO', cpoId, `Customer PO ${poData.customerPoNumber} received for ₹${poData.poAmount.toLocaleString('en-IN')}`);
    pushNotification(
      'Customer PO Received!',
      `${poData.customerName} issued PO ${poData.customerPoNumber}. Ready to place Vendor Purchase Order.`,
      'ACTION_REQUIRED',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE'],
      'customer-pos',
      cpoId
    );

    fetchApi('/api/customer-pos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newCpo),
    }).catch((err) => console.warn('[API] Customer PO sync warning:', err));

    return newCpo;
  };

  // Vendor PO Creation
  const createVendorPO = (vpoData: {
    customerPoId: string;
    quotationId: string;
    requirementId: string;
    vendorId: string;
    vendorName: string;
    items: any[];
    subtotal: number;
    gstAmount: number;
    freight: number;
    totalAmount: number;
    deliveryAddress: string;
    deliveryDate: string;
    paymentTerms: string;
    remarks?: string;
  }): VendorPO => {
    const year = new Date().getFullYear();
    const count = vendorPOs.length + 1;
    const vpoId = `VPO-${year}-${String(count).padStart(5, '0')}`;

    const newVpo: VendorPO = {
      ...vpoData,
      id: vpoId,
      poDate: new Date().toISOString().split('T')[0],
      pdfGenerated: true,
    };

    setVendorPOs((prev) => [newVpo, ...prev]);
    updateRequirementStage(vpoData.requirementId, 'VENDOR_ORDER_PLACED');

    const docRecord: DocumentRecord = {
      id: `DOC-${Date.now().toString().slice(-5)}`,
      name: `Vendor_PO_${vpoId}.pdf`,
      type: 'PDF',
      category: 'PO',
      associatedTransactionId: vpoData.requirementId,
      customerOrVendorName: vpoData.vendorName,
      uploadedAt: new Date().toLocaleString(),
      size: '880 KB',
      url: '#',
    };
    setDocuments((prev) => [docRecord, ...prev]);

    pushAudit('VENDOR_PO_ISSUED', 'VendorPO', vpoId, `Vendor PO ${vpoId} placed with ${vpoData.vendorName} for ₹${vpoData.totalAmount.toLocaleString('en-IN')}`);
    pushNotification(
      'New Purchase Order Placed',
      `Vendor PO ${vpoId} has been issued to you. Please provide Proforma Invoice (PI).`,
      'ACTION_REQUIRED',
      ['VENDOR'],
      'vendor-pos',
      vpoId
    );

    fetchApi('/api/vendor-pos', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newVpo),
    }).catch((err) => console.warn('[API] Vendor PO sync warning:', err));

    return newVpo;
  };

  // Proforma Invoice Received
  const submitProformaInvoice = (piData: {
    vendorPoId: string;
    requirementId: string;
    vendorId: string;
    vendorName: string;
    piNumber: string;
    piDate: string;
    amount: number;
    gstAmount: number;
    freight: number;
    totalAmount: number;
    bankDetails: string;
    paymentDueDate: string;
    remarks?: string;
  }): ProformaInvoice => {
    const year = new Date().getFullYear();
    const count = proformaInvoices.length + 1;
    const piId = `PI-${year}-${String(count).padStart(5, '0')}`;

    const newPi: ProformaInvoice = {
      ...piData,
      id: piId,
    };

    setProformaInvoices((prev) => [newPi, ...prev]);
    updateRequirementStage(piData.requirementId, 'PI_RECEIVED');

    const docRecord: DocumentRecord = {
      id: `DOC-${Date.now().toString().slice(-5)}`,
      name: `Proforma_Invoice_${piData.piNumber.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`,
      type: 'PDF',
      category: 'PI',
      associatedTransactionId: piData.requirementId,
      customerOrVendorName: piData.vendorName,
      uploadedAt: new Date().toLocaleString(),
      size: '720 KB',
      url: '#',
    };
    setDocuments((prev) => [docRecord, ...prev]);

    pushAudit('PI_RECEIVED', 'ProformaInvoice', piId, `PI ${piData.piNumber} uploaded by ${piData.vendorName} for ₹${piData.totalAmount.toLocaleString('en-IN')}`);
    pushNotification(
      'Vendor PI Received',
      `Proforma Invoice ${piData.piNumber} received from ${piData.vendorName}. Payment pending.`,
      'ACTION_REQUIRED',
      ['SUPER_ADMIN', 'ACCOUNTS_USER'],
      'pi',
      piId
    );

    fetchApi('/api/proforma-invoices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newPi),
    }).catch((err) => console.warn('[API] Proforma invoice sync warning:', err));

    return newPi;
  };

  // Record Payment
  const recordPayment = (payData: {
    piId: string;
    vendorPoId: string;
    requirementId: string;
    vendorId: string;
    vendorName: string;
    totalPiAmount: number;
    amountPaid: number;
    paymentDate: string;
    paymentMode: any;
    transactionReference: string;
    remarks?: string;
  }): PaymentRecord => {
    const year = new Date().getFullYear();
    const count = payments.length + 1;
    const payId = `PAY-${year}-${String(count).padStart(5, '0')}`;

    const newPay: PaymentRecord = {
      ...payData,
      id: payId,
      status: 'PAYMENT_DONE',
      loggedBy: currentUser.name,
    };

    setPayments((prev) => [newPay, ...prev]);
    updateRequirementStage(payData.requirementId, 'PAYMENT_DONE');

    const docRecord: DocumentRecord = {
      id: `DOC-${Date.now().toString().slice(-5)}`,
      name: `Payment_Advice_${payId}.pdf`,
      type: 'PDF',
      category: 'PAYMENT',
      associatedTransactionId: payData.requirementId,
      customerOrVendorName: payData.vendorName,
      uploadedAt: new Date().toLocaleString(),
      size: '512 KB',
      url: '#',
    };
    setDocuments((prev) => [docRecord, ...prev]);

    pushAudit('PAYMENT_DISBURSED', 'PaymentRecord', payId, `Payment of ₹${payData.amountPaid.toLocaleString('en-IN')} released via ${payData.paymentMode} ref: ${payData.transactionReference}`);
    pushNotification(
      'Payment Released to Vendor',
      `Payment of ₹${payData.amountPaid.toLocaleString('en-IN')} released for ${payData.requirementId}. Vendor may proceed with dispatch.`,
      'SUCCESS',
      ['VENDOR', 'SUPER_ADMIN'],
      'payments',
      payId
    );

    fetchApi('/api/payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newPay),
    }).catch((err) => console.warn('[API] Payment sync warning:', err));

    return newPay;
  };

  // Record Dispatch
  const recordDispatch = (dspData: {
    vendorPoId: string;
    requirementId: string;
    vendorId: string;
    vendorName: string;
    dispatchDate: string;
    vendorInvoiceNumber: string;
    transporter: string;
    courierName?: string;
    lrNumber: string;
    awbNumber: string;
    trackingNumber: string;
    quantityDispatched: string;
    expectedDeliveryDate: string;
    remarks?: string;
  }): DispatchRecord => {
    const year = new Date().getFullYear();
    const count = dispatches.length + 1;
    const dspId = `DSP-${year}-${String(count).padStart(5, '0')}`;

    const newDsp: DispatchRecord = {
      ...dspData,
      id: dspId,
    };

    setDispatches((prev) => [newDsp, ...prev]);
    updateRequirementStage(dspData.requirementId, 'DISPATCHED');

    const docRecord: DocumentRecord = {
      id: `DOC-${Date.now().toString().slice(-5)}`,
      name: `Lorry_Receipt_LR_${dspData.lrNumber}.pdf`,
      type: 'PDF',
      category: 'DISPATCH',
      associatedTransactionId: dspData.requirementId,
      customerOrVendorName: dspData.vendorName,
      uploadedAt: new Date().toLocaleString(),
      size: '1.1 MB',
      url: '#',
    };
    setDocuments((prev) => [docRecord, ...prev]);

    pushAudit('CONSIGNMENT_DISPATCHED', 'DispatchRecord', dspId, `Order dispatched by ${dspData.vendorName} via ${dspData.transporter} LR: ${dspData.lrNumber}`);
    pushNotification(
      'Consignment Dispatched!',
      `Order ${dspData.requirementId} dispatched via ${dspData.transporter}. Tracking #: ${dspData.trackingNumber || dspData.lrNumber}`,
      'INFO',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE', 'CUSTOMER'],
      'dispatch',
      dspId
    );

    fetchApi('/api/dispatches', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newDsp),
    }).catch((err) => console.warn('[API] Dispatch sync warning:', err));

    return newDsp;
  };

  // Delivery & Tracking Update
  const updateDeliveryTracking = (delData: {
    dispatchId: string;
    requirementId: string;
    deliveryDate: string;
    receivedBy: string;
    customerAcknowledgement: string;
    status: any;
    remarks?: string;
  }): DeliveryRecord => {
    const year = new Date().getFullYear();
    const count = deliveries.length + 1;
    const delId = `DEL-${year}-${String(count).padStart(5, '0')}`;

    const newDel: DeliveryRecord = {
      ...delData,
      id: delId,
    };

    setDeliveries((prev) => {
      const existingIdx = prev.findIndex((d) => d.requirementId === delData.requirementId);
      if (existingIdx >= 0) {
        const copy = [...prev];
        copy[existingIdx] = newDel;
        return copy;
      }
      return [newDel, ...prev];
    });

    updateRequirementStage(delData.requirementId, delData.status);

    pushAudit('DELIVERY_STATUS_UPDATED', 'DeliveryRecord', delId, `Delivery status for ${delData.requirementId} set to ${delData.status} by ${currentUser.name}`);
    pushNotification(
      `Shipment Update: ${delData.status}`,
      `Order ${delData.requirementId} status updated to ${delData.status}.`,
      delData.status === 'DELIVERED' ? 'SUCCESS' : 'INFO',
      ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE', 'CUSTOMER'],
      'delivery',
      delId
    );

    fetchApi('/api/deliveries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newDel),
    }).catch(() => {});
    pushMutationToCloud();

    return newDel;
  };

  // Close Order
  const closeOrder = (requirementId: string, remarks?: string) => {
    updateRequirementStage(requirementId, 'ORDER_CLOSED');
    pushAudit('ORDER_CLOSED', 'CustomerRequirement', requirementId, `Order ${requirementId} fully completed, accounts reconciled, and closed. ${remarks || ''}`);
    pushNotification(
      'Order Successfully Closed',
      `Order ${requirementId} has been successfully closed with complete audit trail.`,
      'SUCCESS',
      ['SUPER_ADMIN', 'ACCOUNTS_USER'],
      'orders',
      requirementId
    );
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const addDocument = (docData: Omit<DocumentRecord, 'id' | 'uploadedAt'>) => {
    const newDoc: DocumentRecord = {
      ...docData,
      id: `DOC-${Date.now().toString().slice(-5)}`,
      uploadedAt: new Date().toLocaleString(),
    };
    setDocuments((prev) => [newDoc, ...prev]);
  };

  // Helper to get linked chain of documents and stages for any requirement
  const getLinkedOrderData = (requirementId: string) => {
    const req = requirements.find((r) => r.id === requirementId);
    const rfq = rfqs.find((r) => r.requirementId === requirementId);
    const quotes = vendorQuotes.filter(
      (v) =>
        v.requirementId === requirementId ||
        v.enquiryId === requirementId ||
        (rfq && (v.requirementId === rfq.id || v.enquiryId === rfq.id))
    );
    const quotation = customerQuotations.find((q) => q.requirementId === requirementId);
    const cpo = customerPOs.find((c) => c.requirementId === requirementId);
    const vpo = vendorPOs.find((v) => v.requirementId === requirementId);
    const pi = proformaInvoices.find((p) => p.requirementId === requirementId);
    const pay = payments.find((p) => p.requirementId === requirementId);
    const dsp = dispatches.find((d) => d.requirementId === requirementId);
    const del = deliveries.find((d) => d.requirementId === requirementId);
    const docs = documents.filter((d) => d.associatedTransactionId === requirementId);

    const sellingVal = quotation?.grandTotal || (cpo ? cpo.poAmount : 0);
    const purchaseVal = vpo?.totalAmount || (pi ? pi.totalAmount : 0);
    const margin = sellingVal > 0 && purchaseVal > 0 ? sellingVal - purchaseVal : 0;
    const marginPct = sellingVal > 0 ? (margin / sellingVal) * 100 : 0;

    return {
      requirement: req,
      rfq,
      vendorQuotes: quotes,
      quotation,
      customerPo: cpo,
      vendorPo: vpo,
      proformaInvoice: pi,
      payment: pay,
      dispatch: dsp,
      delivery: del,
      documents: docs,
      financials: {
        sellingVal,
        purchaseVal,
        grossMargin: margin,
        marginPercent: marginPct,
      },
    };
  };

  // User Management & RBAC Module (Admin Master)
  const addUser = (userData: Omit<User, 'id' | 'createdAt'>): User => {
    const nextSeq = availableUsers.length + 1;
    const newId = `USR-${String(nextSeq).padStart(3, '0')}`;
    const newUser: User = {
      ...userData,
      id: newId,
      status: userData.status || 'ACTIVE',
      createdAt: new Date().toISOString().split('T')[0],
      lastLogin: 'Never',
      permissions: userData.permissions || {
        modules: {
          dashboard: true,
          requirements: true,
          rfqs: true,
          rateComparison: true,
          quotations: true,
          customerPos: false,
          vendorPos: true,
          pi: true,
          payments: false,
          dispatch: true,
          delivery: true,
          customers: true,
          vendors: true,
          categories: true,
          materials: true,
          products: true,
          reports: true,
          documents: true,
          approvals: false,
          userManagement: false,
          auditTrail: false,
        },
        actions: {
          canView: true,
          canCreate: true,
          canEdit: false,
          canDelete: false,
          canApprove: false,
          canExport: true,
          canPrint: true,
          canDownload: true,
          canShare: false,
        },
      },
    };
    setAvailableUsers((prev) => [newUser, ...prev]);
    pushAudit('USER_CREATED', 'USER', newId, `Administrator created user ${newUser.name} (${newUser.role})`);
    pushNotification(
      'New User Provisioned',
      `Account created for ${newUser.name} [${newUser.role}].`,
      'SUCCESS',
      ['SUPER_ADMIN']
    );
    return newUser;
  };

  const updateUser = (updated: User) => {
    setAvailableUsers((prev) => prev.map((u) => (u.id === updated.id ? updated : u)));
    if (currentUser.id === updated.id) {
      setCurrentUser(updated);
      localStorage.setItem('procure_user', JSON.stringify(updated));
    }
    pushAudit('USER_UPDATED', 'USER', updated.id, `Profile/permissions updated for ${updated.name}`);
    pushNotification('User Updated', `Account details for ${updated.name} were updated.`, 'INFO', ['SUPER_ADMIN']);
  };

  const deleteUser = (id: string): { success: boolean; message: string } => {
    if (id === currentUser.id) {
      return { success: false, message: 'Cannot delete the currently logged-in user account.' };
    }
    const target = availableUsers.find((u) => u.id === id);
    if (!target) return { success: false, message: 'User not found.' };
    setAvailableUsers((prev) => prev.filter((u) => u.id !== id));
    pushAudit('USER_DELETED', 'USER', id, `Removed user account ${target.name} (${target.email})`);
    pushNotification('User Removed', `User ${target.name} was removed from the system.`, 'WARNING', ['SUPER_ADMIN']);
    return { success: true, message: `User ${target.name} removed successfully.` };
  };

  const toggleUserStatus = (id: string) => {
    setAvailableUsers((prev) =>
      prev.map((u) => {
        if (u.id === id) {
          const nextStatus = u.status === 'ACTIVE' ? 'INACTIVE' : 'ACTIVE';
          pushAudit('USER_STATUS_CHANGED', 'USER', id, `Changed status of ${u.name} to ${nextStatus}`);
          return { ...u, status: nextStatus };
        }
        return u;
      })
    );
  };

  const resetUserPassword = (id: string, tempPass = 'Mro@Temp2026') => {
    const target = availableUsers.find((u) => u.id === id);
    if (!target) return { success: false, message: 'User not found.', tempPass: '' };

    setAvailableUsers((prev) =>
      prev.map((u) => {
        if (u.id === id) {
          return {
            ...u,
            forcePasswordChange: true,
            passwordHash: tempPass,
            failedLoginAttempts: 0,
          };
        }
        return u;
      })
    );
    pushAudit('PASSWORD_RESET', 'USER', id, `Temporary password reset generated for ${target.name}`);
    pushNotification('Password Reset', `Password reset for ${target.name}. Temp password: ${tempPass}`, 'INFO', ['SUPER_ADMIN']);
    return { success: true, message: `Password reset successfully. Temporary password: ${tempPass}`, tempPass };
  };

  const changeUserPassword = (userId: string, currentPass: string, newPass: string) => {
    const user = availableUsers.find((u) => u.id === userId);
    if (!user) return { success: false, message: 'User not found.' };
    if (!newPass || newPass.length < 6) return { success: false, message: 'New password must be at least 6 characters.' };

    setAvailableUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          return {
            ...u,
            forcePasswordChange: false,
            passwordHash: newPass,
            failedLoginAttempts: 0,
          };
        }
        return u;
      })
    );
    pushAudit('PASSWORD_CHANGED', 'USER', userId, `User ${user.name} changed account password`);
    return { success: true, message: 'Password updated successfully!' };
  };

  const updateUserPermissions = (userId: string, permissions: NonNullable<User['permissions']>, approvalLimit?: number) => {
    setAvailableUsers((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const updated = {
            ...u,
            permissions,
            approvalLimit: approvalLimit !== undefined ? approvalLimit : u.approvalLimit,
          };
          if (currentUser.id === userId) {
            setCurrentUser(updated);
            localStorage.setItem('procure_user', JSON.stringify(updated));
          }
          return updated;
        }
        return u;
      })
    );
    pushAudit('PERMISSIONS_UPDATED', 'USER', userId, `Updated access permissions matrix`);
  };

  const syncBackendNow = async () => {
    try {
      setIsSyncing(true);
      const res = await fetchApi('/api/sync/state');
      if (!res.ok) {
        setIsSyncing(false);
        pushNotification('Sync Notice', 'Central database checked. Connection active.', 'INFO', ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']);
        return;
      }
      const data = await res.json();
      if (!data || !data.state) {
        setIsSyncing(false);
        return;
      }
      const serverState = data.state;
      const serverDeletedIds: string[] = Array.isArray(serverState.deletedRequirementIds)
        ? serverState.deletedRequirementIds
        : [];

      let reqCount = 0;
      if (Array.isArray(serverState.requirements)) {
        setRequirements((prevReqs) => {
          if (serverState.requirements.length === 0 && prevReqs.length > 0) {
            pushMutationToCloud({ requirements: prevReqs });
            reqCount = prevReqs.filter((r) => !r.isDeleted).length;
            return prevReqs;
          }

          const reqMap = new Map<string, CustomerRequirement>();
          serverState.requirements.forEach((sr: CustomerRequirement) => {
            if (sr && sr.id) {
              reqMap.set(sr.id, sr);
            }
          });

          prevReqs.forEach((lr) => {
            if (lr && lr.id) {
              const existing = reqMap.get(lr.id);
              if (!existing) {
                reqMap.set(lr.id, lr);
              } else if (
                lr.lastModifiedAt &&
                (!existing.lastModifiedAt || new Date(lr.lastModifiedAt) > new Date(existing.lastModifiedAt))
              ) {
                reqMap.set(lr.id, lr);
              }
            }
          });

          const uniqueMerged = Array.from(reqMap.values());
          reqCount = uniqueMerged.filter((r) => !r.isDeleted).length;
          try {
            localStorage.setItem('erp_live_requirements', JSON.stringify(uniqueMerged));
          } catch {}
          return uniqueMerged;
        });
      }
      if (Array.isArray(serverState.companies) && serverState.companies.length > 0) {
        setCompanies(serverState.companies);
        try {
          localStorage.setItem('erp_live_companies', JSON.stringify(serverState.companies));
        } catch {}
      }
      if (Array.isArray(serverState.purchaseExecutives) && serverState.purchaseExecutives.length > 0) {
        setPurchaseExecutives(serverState.purchaseExecutives);
        try {
          localStorage.setItem('erp_live_purchase_executives', JSON.stringify(serverState.purchaseExecutives));
        } catch {}
      }
      if (Array.isArray(serverState.customers) && serverState.customers.length > 0) {
        setCustomers(serverState.customers);
        try {
          localStorage.setItem('erp_live_customers', JSON.stringify(serverState.customers));
        } catch {}
      }
      if (Array.isArray(serverState.vendors) && serverState.vendors.length > 0) {
        setVendors(serverState.vendors);
        try {
          localStorage.setItem('erp_live_vendors', JSON.stringify(serverState.vendors));
        } catch {}
      }
      if (Array.isArray(serverState.products) && serverState.products.length > 0) {
        setProducts(serverState.products);
        try {
          localStorage.setItem('erp_live_products', JSON.stringify(serverState.products));
        } catch {}
      }
      if (Array.isArray(serverState.vendorQuotes)) setVendorQuotes(serverState.vendorQuotes);
      if (Array.isArray(serverState.quotations)) setCustomerQuotations(serverState.quotations);
      if (Array.isArray(serverState.customerPos)) setCustomerPOs(serverState.customerPos);
      if (Array.isArray(serverState.vendorPos)) setVendorPOs(serverState.vendorPos);
      if (Array.isArray(serverState.payments)) setPayments(serverState.payments);
      if (Array.isArray(serverState.dispatches)) setDispatches(serverState.dispatches);
      if (Array.isArray(serverState.vendorProductMappings) && serverState.vendorProductMappings.length > 0) {
        setVendorProductMappings(serverState.vendorProductMappings);
      }
      if (Array.isArray(serverState.productTypes) && serverState.productTypes.length > 0) {
        setProductTypes(serverState.productTypes);
      }

      setLastSyncTime(new Date());
      setIsSyncing(false);
      pushNotification(
        'Cloud Sync Updated',
        `Live cloud database synchronized successfully (${reqCount} active requirements loaded).`,
        'SUCCESS',
        ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']
      );
    } catch (err) {
      setIsSyncing(false);
      console.warn('syncBackendNow notice:', err);
    }
  };

  const exportTeamSyncSnapshot = (): string => {
    const snapshot = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      exportedBy: currentUser.name,
      requirements,
      companies,
      purchaseExecutives,
      customers,
      vendors,
      products,
      vendorQuotes,
      customerQuotations,
      customerPOs,
      vendorPOs,
      vendorProductMappings,
      productTypes,
    };
    return JSON.stringify(snapshot, null, 2);
  };

  const importTeamSyncSnapshot = (raw: string): { success: boolean; count: number; message: string } => {
    try {
      let data: any;
      const clean = raw.trim();
      if (clean.startsWith('{')) {
        data = JSON.parse(clean);
      } else {
        const decoded = atob(clean);
        data = JSON.parse(decoded);
      }

      let reqCount = 0;
      if (Array.isArray(data.requirements) && data.requirements.length > 0) {
        setRequirements(data.requirements);
        try {
          localStorage.setItem('erp_live_requirements', JSON.stringify(data.requirements));
        } catch {}
        reqCount = data.requirements.length;
      }
      if (Array.isArray(data.companies) && data.companies.length > 0) {
        setCompanies(data.companies);
        try {
          localStorage.setItem('erp_live_companies', JSON.stringify(data.companies));
        } catch {}
      }
      if (Array.isArray(data.purchaseExecutives) && data.purchaseExecutives.length > 0) {
        setPurchaseExecutives(data.purchaseExecutives);
        try {
          localStorage.setItem('erp_live_purchase_executives', JSON.stringify(data.purchaseExecutives));
        } catch {}
      }
      if (Array.isArray(data.customers) && data.customers.length > 0) {
        setCustomers(data.customers);
        try {
          localStorage.setItem('erp_live_customers', JSON.stringify(data.customers));
        } catch {}
      }
      if (Array.isArray(data.vendors) && data.vendors.length > 0) {
        setVendors(data.vendors);
        try {
          localStorage.setItem('erp_live_vendors', JSON.stringify(data.vendors));
        } catch {}
      }
      if (Array.isArray(data.products) && data.products.length > 0) {
        setProducts(data.products);
        try {
          localStorage.setItem('erp_live_products', JSON.stringify(data.products));
        } catch {}
      }
      if (Array.isArray(data.vendorQuotes) && data.vendorQuotes.length > 0) {
        setVendorQuotes(data.vendorQuotes);
      }
      if (Array.isArray(data.quotations) && data.quotations.length > 0) {
        setCustomerQuotations(data.quotations);
      }
      if (Array.isArray(data.customerPos) && data.customerPos.length > 0) {
        setCustomerPOs(data.customerPos);
      }
      if (Array.isArray(data.vendorPos) && data.vendorPos.length > 0) {
        setVendorPOs(data.vendorPos);
      }
      if (Array.isArray(data.vendorProductMappings) && data.vendorProductMappings.length > 0) {
        setVendorProductMappings(data.vendorProductMappings);
      }
      if (Array.isArray(data.productTypes) && data.productTypes.length > 0) {
        setProductTypes(data.productTypes);
      }

      pushMutationToCloud(data);
      setLastSyncTime(new Date());

      pushNotification(
        'Team Sync Complete',
        `Synchronized ${reqCount} requirements & company masters from team snapshot.`,
        'SUCCESS',
        ['SUPER_ADMIN', 'PROCUREMENT_EMPLOYEE']
      );

      return {
        success: true,
        count: reqCount,
        message: `Successfully synchronized ${reqCount} requirements & company master data!`,
      };
    } catch (err: any) {
      return {
        success: false,
        count: 0,
        message: `Import failed: ${err.message || 'Invalid sync data format'}`,
      };
    }
  };

  const pushDeviceDataToCentralDb = async () => {
    try {
      const payload = {
        requirements,
        companies,
        purchaseExecutives,
        vendors,
        products,
        quotations: customerQuotations,
        customerPos: customerPOs,
        vendorPos: vendorPOs,
        payments,
        dispatches,
        vendorProductMappings,
        productTypes,
      };
      const res = await fetchApi('/api/sync/full', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ state: payload, user: currentUser.name }),
      });
      if (res.ok) {
        return { success: true, message: 'All local business records successfully uploaded to central production database!' };
      }
      return { success: false, message: 'Failed to upload to central database.' };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Sync error' };
    }
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        availableUsers,
        isMobileView,
        setIsMobileView,
        activeTab,
        setActiveTab,
        selectedOrderId,
        setSelectedOrderId,
        customers,
        companies,
        purchaseExecutives,
        vendors,
        products,
        requirements,
        rfqs,
        vendorQuotes,
        customerQuotations,
        customerPOs,
        vendorPOs,
        proformaInvoices,
        payments,
        dispatches,
        deliveries,
        notifications,
        auditLogs,
        documents,
        addCustomer,
        addCompany,
        updateCompany,
        deleteCompany,
        addPurchaseExecutive,
        updatePurchaseExecutive,
        deletePurchaseExecutive,
        getExecutivesByCompany,
        updateRequirement,
        deleteRequirement,
        restoreRequirement,
        addVendor,
        addProduct,
        addRequirement,
        sendVendorEnquiry,
        submitVendorQuote,
        updateVendorQuote,
        deleteVendorQuote,
        getRateCompletionStatus,
        createCustomerQuotation,
        recordCustomerPO,
        createVendorPO,
        submitProformaInvoice,
        recordPayment,
        recordDispatch,
        updateDeliveryTracking,
        closeOrder,
        markNotificationRead,
        markAllNotificationsRead,
        pushNotification,
        addDocument,
        getLinkedOrderData,
        dataMode,
        setDataMode,
        copyDemoToLocalBusiness,
        resetCurrentModeData,
        exportFullBackup,
        restoreFullBackup,
        updateCustomer,
        deleteCustomer,
        importCustomersList,
        updateVendor,
        deleteVendor,
        restoreVendor,
        permanentlyDeleteVendor,
        purgeArchivedVendors,
        importVendorsList,
        updateProduct,
        deleteProduct,
        restoreProduct,
        importProductsList,
        lockQuotationCommercials,
        unlockQuotationCommercials,
        categories,
        addCategory,
        updateCategory,
        deleteCategory,
        toggleCategoryStatus,
        addKeywordToCategory,
        bulkImportRequirements,
        assignVendorToRequirementItem,
        brands,
        addBrand,
        updateBrand,
        deleteBrand,
        registerVendorBrands,
        aiActivityLogs,
        analyzeVendorCatalogFiles,
        approveVendorMaterialCategory,
        rejectVendorMaterialCategory,
        editVendorMaterialCategory,
        approveAllVendorMaterialCategories,
        approveVendorCatalogProduct,
        rejectVendorCatalogProduct,
        learnCategoryFromVendorQuotation,
        deleteVendorCatalogFile,
        saveCatalogAnalysisToVendor,
        vendorProductMappings,
        addVendorProductMapping,
        updateVendorProductMapping,
        deleteVendorProductMapping,
        bulkAddVendorProductMappings,
        productTypes,
        addProductTypeToMaster,
        addProductTypeToVendor,
        removeProductTypeFromVendor,
        backups,
        backupSettings,
        updateBackupSettings: updateBackupSettingsState,
        triggerManualBackup,
        restoreFromBackupRecord,
        testBackupRecord,
        backupFailureAlert,
        clearBackupFailureAlert,
        addUser,
        updateUser,
        deleteUser,
        toggleUserStatus,
        resetUserPassword,
        changeUserPassword,
        updateUserPermissions,
        syncBackendNow,
        pushDeviceDataToCentralDb,
        exportTeamSyncSnapshot,
        importTeamSyncSnapshot,
        isSyncing,
        lastSyncTime,
        isOnline,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
