import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { fetchApi, setApiBaseUrl } from './utils/apiClient';

// Dynamic production backend discovery
if (typeof window !== 'undefined') {
  fetchApi('/api/config')
    .then((res) => (res.ok ? res.json() : null))
    .then((data) => {
      if (data?.appUrl) {
        setApiBaseUrl(data.appUrl);
      }
    })
    .catch(() => {});
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);
