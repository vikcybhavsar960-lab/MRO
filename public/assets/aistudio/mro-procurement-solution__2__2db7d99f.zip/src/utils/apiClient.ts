// Universal Authoritative API Client for MRO Procurement ERP
// Ensures Cloudflare Workers, Google Cloud Run, and Localhost connect to the same central database

declare global {
  interface Window {
    __APP_URL__?: string;
  }
}

export const PRODUCTION_BACKEND_URL =
  'https://ais-dev-blsn7yeugffp2hqla4t7es-95715327985.asia-east1.run.app';

let activeBaseUrl = '';

export const getInjectedBackendUrl = (): string => {
  if (typeof window !== 'undefined' && window.__APP_URL__) {
    return window.__APP_URL__.trim().replace(/\/$/, '');
  }

  if (typeof document !== 'undefined') {
    const metaAppUrl = document.querySelector('meta[name="app-url"]')?.getAttribute('content');
    if (metaAppUrl) return metaAppUrl.trim().replace(/\/$/, '');
  }

  const viteAppUrl =
    (import.meta as any)?.env?.VITE_APP_URL ||
    (import.meta as any)?.env?.VITE_API_URL ||
    (import.meta as any)?.env?.VITE_BACKEND_URL;
  if (viteAppUrl) {
    return viteAppUrl.trim().replace(/\/$/, '');
  }

  return '';
};

export const getApiBaseUrl = (): string => {
  if (activeBaseUrl) return activeBaseUrl;
  if (typeof window === 'undefined') return '';

  const savedUrl = localStorage.getItem('mro_custom_backend_url');
  if (savedUrl && savedUrl.trim()) {
    return savedUrl.trim().replace(/\/$/, '');
  }

  const injected = getInjectedBackendUrl();
  const host = window.location.hostname;

  // If running directly on Cloudflare Worker (workers.dev), Google Cloud Run (ais-pre / ais-dev), or localhost:
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host.includes('workers.dev') ||
    host.includes('run.app')
  ) {
    return '';
  }

  // When running on Cloudflare Pages (*.pages.dev) or external static preview:
  return injected || PRODUCTION_BACKEND_URL;
};

export const setApiBaseUrl = (url: string) => {
  activeBaseUrl = url.trim().replace(/\/$/, '');
  if (typeof window !== 'undefined') {
    if (url) {
      localStorage.setItem('mro_custom_backend_url', activeBaseUrl);
    } else {
      localStorage.removeItem('mro_custom_backend_url');
    }
  }
};

export const fetchApi = async (path: string, options?: RequestInit): Promise<Response> => {
  const cleanPath = path.startsWith('/') ? path : `/${path}`;
  const base = getApiBaseUrl();
  const url = `${base}${cleanPath}`;

  try {
    const res = await fetch(url, options);

    const contentType = res.headers.get('content-type') || '';
    if (
      contentType.includes('text/html') &&
      typeof window !== 'undefined' &&
      PRODUCTION_BACKEND_URL &&
      url !== `${PRODUCTION_BACKEND_URL}${cleanPath}`
    ) {
      console.warn(
        `[ApiClient] Endpoint ${url} returned HTML SPA page instead of JSON. Redirecting to Authoritative Production Backend: ${PRODUCTION_BACKEND_URL}`
      );
      activeBaseUrl = PRODUCTION_BACKEND_URL;
      const fallbackUrl = `${PRODUCTION_BACKEND_URL}${cleanPath}`;
      return await fetch(fallbackUrl, options);
    }

    return res;
  } catch (err) {
    if (
      typeof window !== 'undefined' &&
      PRODUCTION_BACKEND_URL &&
      url !== `${PRODUCTION_BACKEND_URL}${cleanPath}`
    ) {
      console.warn(
        `[ApiClient] Network failure at ${url}. Switching to Authoritative Production Backend: ${PRODUCTION_BACKEND_URL}`,
        err
      );
      activeBaseUrl = PRODUCTION_BACKEND_URL;
      const fallbackUrl = `${PRODUCTION_BACKEND_URL}${cleanPath}`;
      return await fetch(fallbackUrl, options);
    }
    throw err;
  }
};

export const installApiInterceptor = () => {
  // Safe no-op
};

export const API_BASE_URL = '/api';
