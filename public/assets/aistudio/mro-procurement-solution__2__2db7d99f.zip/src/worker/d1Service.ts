import { D1Database } from './types';

// In-Memory Fallback State Store (active when Cloudflare D1 is pending binding)
const fallbackStore: Record<string, any> = {
  requirements: [],
  deletedRequirementIds: [],
  customers: [],
  vendors: [],
  products: [],
  brands: [],
  categories: [],
  rfqs: [],
  vendor_quotes: [],
  customer_quotations: [],
  customer_pos: [],
  vendor_pos: [],
  payments: [],
  dispatches: [],
  deliveries: [],
  companies: [],
  purchaseExecutives: [],
  productTypes: [],
  vendorProductMappings: [],
};

// Ensure tables exist automatically on first run
export async function initD1Schema(db?: D1Database): Promise<void> {
  if (!db) return;

  const schemaQueries = `
    CREATE TABLE IF NOT EXISTS requirements (
      id TEXT PRIMARY KEY,
      rfqNumber TEXT,
      customerId TEXT,
      customerName TEXT,
      department TEXT,
      priority TEXT DEFAULT 'MEDIUM',
      status TEXT DEFAULT 'PENDING',
      date TEXT,
      requiredByDate TEXT,
      deliveryLocation TEXT,
      estimatedBudget REAL DEFAULT 0,
      itemsCount INTEGER DEFAULT 0,
      itemsJson TEXT,
      dataJson TEXT,
      createdBy TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );

    CREATE TABLE IF NOT EXISTS deleted_requirements (
      id TEXT PRIMARY KEY,
      deletedAt TEXT NOT NULL,
      deletedBy TEXT,
      reason TEXT
    );

    CREATE TABLE IF NOT EXISTS customers (
      id TEXT PRIMARY KEY,
      companyName TEXT NOT NULL,
      contactPerson TEXT,
      email TEXT,
      mobile TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      pincode TEXT,
      gstin TEXT,
      pan TEXT,
      paymentTerms TEXT,
      dataJson TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );

    CREATE TABLE IF NOT EXISTS vendors (
      id TEXT PRIMARY KEY,
      companyName TEXT NOT NULL,
      contactPerson TEXT,
      email TEXT,
      mobile TEXT,
      address TEXT,
      city TEXT,
      state TEXT,
      gstin TEXT,
      pan TEXT,
      rating REAL DEFAULT 5.0,
      dataJson TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );

    CREATE TABLE IF NOT EXISTS products (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      partNumber TEXT,
      brand TEXT,
      category TEXT,
      uom TEXT DEFAULT 'NOS',
      unitPrice REAL DEFAULT 0,
      taxRate REAL DEFAULT 18,
      description TEXT,
      dataJson TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );

    CREATE TABLE IF NOT EXISTS rfqs (
      id TEXT PRIMARY KEY,
      rfqNumber TEXT NOT NULL,
      requirementId TEXT,
      customerName TEXT,
      title TEXT,
      status TEXT DEFAULT 'OPEN',
      dueDate TEXT,
      dataJson TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );

    CREATE TABLE IF NOT EXISTS vendor_quotes (
      id TEXT PRIMARY KEY,
      quoteNumber TEXT,
      rfqNumber TEXT,
      vendorId TEXT,
      vendorName TEXT,
      status TEXT DEFAULT 'RECEIVED',
      totalAmount REAL DEFAULT 0,
      dataJson TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );

    CREATE TABLE IF NOT EXISTS customer_quotations (
      id TEXT PRIMARY KEY,
      quotationNumber TEXT NOT NULL,
      rfqNumber TEXT,
      customerId TEXT,
      customerName TEXT,
      status TEXT DEFAULT 'DRAFT',
      subtotal REAL DEFAULT 0,
      taxAmount REAL DEFAULT 0,
      totalAmount REAL DEFAULT 0,
      dataJson TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );

    CREATE TABLE IF NOT EXISTS customer_pos (
      id TEXT PRIMARY KEY,
      poNumber TEXT NOT NULL,
      quotationNumber TEXT,
      customerName TEXT,
      orderDate TEXT,
      deliveryDate TEXT,
      status TEXT DEFAULT 'PENDING',
      totalAmount REAL DEFAULT 0,
      dataJson TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );

    CREATE TABLE IF NOT EXISTS vendor_pos (
      id TEXT PRIMARY KEY,
      poNumber TEXT NOT NULL,
      vendorName TEXT,
      customerPoReference TEXT,
      orderDate TEXT,
      status TEXT DEFAULT 'ISSUED',
      totalAmount REAL DEFAULT 0,
      dataJson TEXT,
      createdAt TEXT,
      updatedAt TEXT
    );

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      paymentNumber TEXT,
      partyType TEXT,
      partyName TEXT,
      amount REAL DEFAULT 0,
      paymentDate TEXT,
      paymentMode TEXT,
      referenceNumber TEXT,
      status TEXT DEFAULT 'COMPLETED',
      dataJson TEXT,
      createdAt TEXT
    );

    CREATE TABLE IF NOT EXISTS dispatches (
      id TEXT PRIMARY KEY,
      dispatchNumber TEXT,
      customerName TEXT,
      dispatchDate TEXT,
      status TEXT DEFAULT 'DISPATCHED',
      courierName TEXT,
      trackingNumber TEXT,
      dataJson TEXT,
      createdAt TEXT
    );

    CREATE TABLE IF NOT EXISTS deliveries (
      id TEXT PRIMARY KEY,
      deliveryNumber TEXT,
      customerName TEXT,
      receivedDate TEXT,
      status TEXT DEFAULT 'DELIVERED',
      dataJson TEXT,
      createdAt TEXT
    );

    CREATE TABLE IF NOT EXISTS erp_state_store (
      key TEXT PRIMARY KEY,
      valueJson TEXT NOT NULL,
      updatedAt TEXT NOT NULL
    );
  `;

  try {
    await db.exec(schemaQueries);
  } catch (err) {
    console.warn('[D1] Schema init notice:', err);
  }
}

// -------------------------------------------------------------
// REQUIREMENTS CRUD (SOFT DELETE & PERMANENT SAFEGUARDS)
// -------------------------------------------------------------
export async function getRequirements(
  db?: D1Database,
  includeDeleted = false
): Promise<{ requirements: any[]; deletedIds: string[] }> {
  if (!db) {
    const deletedIds = fallbackStore.deletedRequirementIds || [];
    const all = fallbackStore.requirements || [];
    const requirements = includeDeleted
      ? all
      : all.filter((r: any) => !r.isDeleted && !deletedIds.includes(r.id) && !deletedIds.includes(r.rfqNumber));
    return { requirements, deletedIds };
  }

  const deletedResult = await db.prepare('SELECT id FROM deleted_requirements').all<{ id: string }>();
  const deletedIds = (deletedResult.results || []).map((r) => r.id);

  const reqResult = await db.prepare('SELECT dataJson FROM requirements ORDER BY createdAt DESC').all<{ dataJson: string }>();
  const allRequirements = (reqResult.results || [])
    .map((r) => {
      try {
        return JSON.parse(r.dataJson);
      } catch {
        return null;
      }
    })
    .filter(Boolean);

  const requirements = includeDeleted
    ? allRequirements
    : allRequirements.filter((r: any) => !r.isDeleted && !deletedIds.includes(r.id) && !deletedIds.includes(r.rfqNumber));

  return { requirements, deletedIds };
}

export async function saveRequirement(db: D1Database | undefined, item: any, user = 'User'): Promise<any> {
  const now = new Date().toISOString();
  const id = item.id || `REQ-${Date.now()}`;
  const isDeleted = item.isDeleted === true;
  const payload = {
    ...item,
    id,
    isDeleted,
    dbSaveStatus: 'COMMITTED',
    cloudSyncStatus: 'SYNCED',
    updatedAt: now,
  };

  if (!db) {
    if (!fallbackStore.requirements) fallbackStore.requirements = [];
    const idx = fallbackStore.requirements.findIndex((r: any) => r.id === id || (r.rfqNumber && r.rfqNumber === payload.rfqNumber));
    if (idx !== -1) {
      fallbackStore.requirements[idx] = payload;
    } else {
      fallbackStore.requirements.unshift(payload);
    }
    if (!isDeleted) {
      fallbackStore.deletedRequirementIds = (fallbackStore.deletedRequirementIds || []).filter(
        (dId: string) => dId !== id && dId !== payload.rfqNumber
      );
    }
    return payload;
  }

  const query = `
    INSERT INTO requirements (
      id, rfqNumber, customerId, customerName, department, priority, status,
      date, requiredByDate, deliveryLocation, estimatedBudget, itemsCount,
      itemsJson, dataJson, createdBy, createdAt, updatedAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      rfqNumber = excluded.rfqNumber,
      customerName = excluded.customerName,
      department = excluded.department,
      priority = excluded.priority,
      status = excluded.status,
      date = excluded.date,
      requiredByDate = excluded.requiredByDate,
      deliveryLocation = excluded.deliveryLocation,
      estimatedBudget = excluded.estimatedBudget,
      itemsCount = excluded.itemsCount,
      itemsJson = excluded.itemsJson,
      dataJson = excluded.dataJson,
      updatedAt = excluded.updatedAt;
  `;

  await db
    .prepare(query)
    .bind(
      id,
      payload.rfqNumber || '',
      payload.customerId || '',
      payload.customerName || '',
      payload.department || '',
      payload.priority || 'MEDIUM',
      payload.status || 'PENDING',
      payload.date || now.split('T')[0],
      payload.requiredByDate || '',
      payload.deliveryLocation || '',
      payload.estimatedBudget || 0,
      Array.isArray(payload.items) ? payload.items.length : 0,
      JSON.stringify(payload.items || []),
      JSON.stringify(payload),
      user,
      payload.createdAt || now,
      now
    )
    .run();

  if (!isDeleted) {
    await db.prepare('DELETE FROM deleted_requirements WHERE id = ?').bind(id).run();
  }
  return payload;
}

export async function deleteRequirement(
  db: D1Database | undefined,
  id: string,
  user = 'Super Admin',
  reason = 'Customer Cancelled'
): Promise<{ success: boolean; deletedId: string; message: string }> {
  const now = new Date().toISOString();

  if (!db) {
    if (fallbackStore.requirements) {
      const target = fallbackStore.requirements.find((r: any) => r.id === id || r.rfqNumber === id);
      if (target) {
        target.isDeleted = true;
        target.deletedAt = now;
        target.deletedBy = user;
        target.deletedReason = reason;
      }
    }
    if (!fallbackStore.deletedRequirementIds) fallbackStore.deletedRequirementIds = [];
    if (!fallbackStore.deletedRequirementIds.includes(id)) {
      fallbackStore.deletedRequirementIds.push(id);
    }
    return {
      success: true,
      deletedId: id,
      message: `Requirement ${id} soft-deleted safely`,
    };
  }

  // Soft-delete in D1: fetch current record and flag as deleted
  const existing = await db.prepare('SELECT dataJson FROM requirements WHERE id = ?').bind(id).first<{ dataJson: string }>();
  if (existing?.dataJson) {
    try {
      const parsed = JSON.parse(existing.dataJson);
      parsed.isDeleted = true;
      parsed.deletedAt = now;
      parsed.deletedBy = user;
      parsed.deletedReason = reason;
      parsed.updatedAt = now;

      await db
        .prepare('UPDATE requirements SET dataJson = ?, updatedAt = ? WHERE id = ?')
        .bind(JSON.stringify(parsed), now, id)
        .run();
    } catch {
      // Continue to tombstone
    }
  }

  // Insert into soft deletion log
  await db
    .prepare('INSERT OR REPLACE INTO deleted_requirements (id, deletedAt, deletedBy, reason) VALUES (?, ?, ?, ?)')
    .bind(id, now, user, reason)
    .run();

  return {
    success: true,
    deletedId: id,
    message: `Requirement ${id} soft-deleted and archived safely`,
  };
}

export async function restoreRequirement(
  db: D1Database | undefined,
  id: string,
  user = 'Super Admin'
): Promise<{ success: boolean; restoredId: string; message: string }> {
  const now = new Date().toISOString();

  if (!db) {
    if (fallbackStore.requirements) {
      const target = fallbackStore.requirements.find((r: any) => r.id === id || r.rfqNumber === id);
      if (target) {
        target.isDeleted = false;
        delete target.deletedAt;
        delete target.deletedBy;
        delete target.deletedReason;
        target.updatedAt = now;
      }
    }
    fallbackStore.deletedRequirementIds = (fallbackStore.deletedRequirementIds || []).filter(
      (dId: string) => dId !== id
    );
    return {
      success: true,
      restoredId: id,
      message: `Requirement ${id} restored successfully`,
    };
  }

  // Update in DB
  const existing = await db.prepare('SELECT dataJson FROM requirements WHERE id = ?').bind(id).first<{ dataJson: string }>();
  if (existing?.dataJson) {
    try {
      const parsed = JSON.parse(existing.dataJson);
      parsed.isDeleted = false;
      delete parsed.deletedAt;
      delete parsed.deletedBy;
      delete parsed.deletedReason;
      parsed.updatedAt = now;

      await db
        .prepare('UPDATE requirements SET dataJson = ?, updatedAt = ? WHERE id = ?')
        .bind(JSON.stringify(parsed), now, id)
        .run();
    } catch {
      // ignore
    }
  }

  await db.prepare('DELETE FROM deleted_requirements WHERE id = ?').bind(id).run();

  return {
    success: true,
    restoredId: id,
    message: `Requirement ${id} restored to active register`,
  };
}

// -------------------------------------------------------------
// CUSTOMERS CRUD
// -------------------------------------------------------------
export async function getCustomers(db?: D1Database): Promise<any[]> {
  if (!db) return fallbackStore.customers || [];
  const result = await db.prepare('SELECT dataJson FROM customers ORDER BY companyName ASC').all<{ dataJson: string }>();
  return (result.results || []).map((r) => JSON.parse(r.dataJson)).filter(Boolean);
}

export async function saveCustomer(db: D1Database | undefined, item: any): Promise<any> {
  const now = new Date().toISOString();
  const id = item.id || `CUST-${Date.now()}`;
  const payload = { ...item, id, updatedAt: now };

  if (!db) {
    if (!fallbackStore.customers) fallbackStore.customers = [];
    const idx = fallbackStore.customers.findIndex((c: any) => c.id === id);
    if (idx !== -1) fallbackStore.customers[idx] = payload;
    else fallbackStore.customers.unshift(payload);
    return payload;
  }

  const query = `
    INSERT INTO customers (
      id, companyName, contactPerson, email, mobile, address, city, state,
      pincode, gstin, pan, paymentTerms, dataJson, createdAt, updatedAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      companyName = excluded.companyName,
      contactPerson = excluded.contactPerson,
      email = excluded.email,
      mobile = excluded.mobile,
      address = excluded.address,
      city = excluded.city,
      state = excluded.state,
      pincode = excluded.pincode,
      gstin = excluded.gstin,
      pan = excluded.pan,
      paymentTerms = excluded.paymentTerms,
      dataJson = excluded.dataJson,
      updatedAt = excluded.updatedAt;
  `;

  await db
    .prepare(query)
    .bind(
      id,
      payload.companyName || '',
      payload.contactPerson || '',
      payload.email || '',
      payload.mobile || '',
      payload.address || '',
      payload.city || '',
      payload.state || '',
      payload.pincode || '',
      payload.gstin || '',
      payload.pan || '',
      payload.paymentTerms || '',
      JSON.stringify(payload),
      payload.createdAt || now,
      now
    )
    .run();

  return payload;
}

export async function deleteCustomer(db: D1Database | undefined, id: string): Promise<boolean> {
  if (!db) {
    if (fallbackStore.customers) {
      fallbackStore.customers = fallbackStore.customers.filter((c: any) => c.id !== id);
    }
    return true;
  }
  await db.prepare('DELETE FROM customers WHERE id = ?').bind(id).run();
  return true;
}

// -------------------------------------------------------------
// VENDORS CRUD
// -------------------------------------------------------------
export async function getVendors(db?: D1Database): Promise<any[]> {
  if (!db) return fallbackStore.vendors || [];
  const result = await db.prepare('SELECT dataJson FROM vendors ORDER BY companyName ASC').all<{ dataJson: string }>();
  return (result.results || []).map((r) => JSON.parse(r.dataJson)).filter(Boolean);
}

export async function saveVendor(db: D1Database | undefined, item: any): Promise<any> {
  const now = new Date().toISOString();
  const id = item.id || `VEND-${Date.now()}`;
  const payload = { ...item, id, updatedAt: now };

  if (!db) {
    if (!fallbackStore.vendors) fallbackStore.vendors = [];
    const idx = fallbackStore.vendors.findIndex((v: any) => v.id === id);
    if (idx !== -1) fallbackStore.vendors[idx] = payload;
    else fallbackStore.vendors.unshift(payload);
    return payload;
  }

  const query = `
    INSERT INTO vendors (
      id, companyName, contactPerson, email, mobile, address, city, state,
      gstin, pan, rating, dataJson, createdAt, updatedAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      companyName = excluded.companyName,
      contactPerson = excluded.contactPerson,
      email = excluded.email,
      mobile = excluded.mobile,
      address = excluded.address,
      city = excluded.city,
      state = excluded.state,
      gstin = excluded.gstin,
      pan = excluded.pan,
      rating = excluded.rating,
      dataJson = excluded.dataJson,
      updatedAt = excluded.updatedAt;
  `;

  await db
    .prepare(query)
    .bind(
      id,
      payload.companyName || '',
      payload.contactPerson || '',
      payload.email || '',
      payload.mobile || '',
      payload.address || '',
      payload.city || '',
      payload.state || '',
      payload.gstin || '',
      payload.pan || '',
      payload.rating || 5.0,
      JSON.stringify(payload),
      payload.createdAt || now,
      now
    )
    .run();

  return payload;
}

export async function deleteVendor(db: D1Database | undefined, id: string): Promise<boolean> {
  if (!db) {
    if (fallbackStore.vendors) {
      fallbackStore.vendors = fallbackStore.vendors.filter((v: any) => v.id !== id);
    }
    return true;
  }
  await db.prepare('DELETE FROM vendors WHERE id = ?').bind(id).run();
  return true;
}

// -------------------------------------------------------------
// PRODUCTS CRUD
// -------------------------------------------------------------
export async function getProducts(db?: D1Database): Promise<any[]> {
  if (!db) return fallbackStore.products || [];
  const result = await db.prepare('SELECT dataJson FROM products ORDER BY name ASC').all<{ dataJson: string }>();
  return (result.results || []).map((r) => JSON.parse(r.dataJson)).filter(Boolean);
}

export async function saveProduct(db: D1Database | undefined, item: any): Promise<any> {
  const now = new Date().toISOString();
  const id = item.id || `PROD-${Date.now()}`;
  const payload = { ...item, id, updatedAt: now };

  if (!db) {
    if (!fallbackStore.products) fallbackStore.products = [];
    const idx = fallbackStore.products.findIndex((p: any) => p.id === id);
    if (idx !== -1) fallbackStore.products[idx] = payload;
    else fallbackStore.products.unshift(payload);
    return payload;
  }

  const query = `
    INSERT INTO products (
      id, name, partNumber, brand, category, uom, unitPrice, taxRate, description, dataJson, createdAt, updatedAt
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ON CONFLICT(id) DO UPDATE SET
      name = excluded.name,
      partNumber = excluded.partNumber,
      brand = excluded.brand,
      category = excluded.category,
      uom = excluded.uom,
      unitPrice = excluded.unitPrice,
      taxRate = excluded.taxRate,
      description = excluded.description,
      dataJson = excluded.dataJson,
      updatedAt = excluded.updatedAt;
  `;

  await db
    .prepare(query)
    .bind(
      id,
      payload.name || payload.productName || '',
      payload.partNumber || payload.sku || '',
      payload.brand || '',
      payload.category || '',
      payload.uom || 'NOS',
      payload.unitPrice || payload.price || 0,
      payload.taxRate || 18,
      payload.description || '',
      JSON.stringify(payload),
      payload.createdAt || now,
      now
    )
    .run();

  return payload;
}

export async function deleteProduct(db: D1Database | undefined, id: string): Promise<boolean> {
  if (!db) {
    if (fallbackStore.products) {
      fallbackStore.products = fallbackStore.products.filter((p: any) => p.id !== id);
    }
    return true;
  }
  await db.prepare('DELETE FROM products WHERE id = ?').bind(id).run();
  return true;
}

// -------------------------------------------------------------
// GENERIC TABLE CRUD (RFQs, Quotations, POs, Payments, etc.)
// -------------------------------------------------------------
export async function getGenericTable(db: D1Database | undefined, tableName: string): Promise<any[]> {
  if (!db) return fallbackStore[tableName] || [];
  try {
    const result = await db.prepare(`SELECT dataJson FROM ${tableName} ORDER BY createdAt DESC`).all<{ dataJson: string }>();
    return (result.results || []).map((r) => JSON.parse(r.dataJson)).filter(Boolean);
  } catch {
    return [];
  }
}

export async function saveGenericItem(db: D1Database | undefined, tableName: string, item: any, idPrefix = 'DOC'): Promise<any> {
  const now = new Date().toISOString();
  const id = item.id || `${idPrefix}-${Date.now()}`;
  const payload = { ...item, id, updatedAt: now };

  if (!db) {
    if (!fallbackStore[tableName]) fallbackStore[tableName] = [];
    const idx = fallbackStore[tableName].findIndex((x: any) => x.id === id);
    if (idx !== -1) fallbackStore[tableName][idx] = payload;
    else fallbackStore[tableName].unshift(payload);
    return payload;
  }

  try {
    await db
      .prepare(`INSERT OR REPLACE INTO ${tableName} (id, dataJson, createdAt) VALUES (?, ?, ?)`)
      .bind(id, JSON.stringify(payload), payload.createdAt || now)
      .run();
  } catch (err) {
    console.warn(`[D1] Error saving into ${tableName}:`, err);
  }

  return payload;
}

export async function deleteGenericItem(db: D1Database | undefined, tableName: string, id: string): Promise<boolean> {
  if (!db) {
    if (fallbackStore[tableName]) {
      fallbackStore[tableName] = fallbackStore[tableName].filter((x: any) => x.id !== id);
    }
    return true;
  }
  await db.prepare(`DELETE FROM ${tableName} WHERE id = ?`).bind(id).run();
  return true;
}

// -------------------------------------------------------------
// STATE STORE (Unified State Sync for Multi-User Real-time Sync)
// -------------------------------------------------------------
export async function getStateValue(db: D1Database | undefined, key: string): Promise<any | null> {
  if (!db) return fallbackStore[key] || null;
  try {
    const row = await db.prepare('SELECT valueJson FROM erp_state_store WHERE key = ?').bind(key).first<{ valueJson: string }>();
    return row?.valueJson ? JSON.parse(row.valueJson) : null;
  } catch {
    return null;
  }
}

export async function setStateValue(db: D1Database | undefined, key: string, value: any): Promise<void> {
  if (!db) {
    fallbackStore[key] = value;
    return;
  }
  const now = new Date().toISOString();
  await db
    .prepare('INSERT OR REPLACE INTO erp_state_store (key, valueJson, updatedAt) VALUES (?, ?, ?)')
    .bind(key, JSON.stringify(value), now)
    .run();
}

// -------------------------------------------------------------
// FULL STATE SYNC AGGREGATOR
// -------------------------------------------------------------
export async function getFullStateFromD1(db?: D1Database): Promise<any> {
  if (!db) {
    return {
      requirements: fallbackStore.requirements || [],
      deletedRequirementIds: fallbackStore.deletedRequirementIds || [],
      customers: fallbackStore.customers || [],
      vendors: fallbackStore.vendors || [],
      products: fallbackStore.products || [],
      rfqs: fallbackStore.rfqs || [],
      vendorQuotes: fallbackStore.vendor_quotes || [],
      quotations: fallbackStore.customer_quotations || [],
      customerPos: fallbackStore.customer_pos || [],
      vendorPos: fallbackStore.vendor_pos || [],
      payments: fallbackStore.payments || [],
      dispatches: fallbackStore.dispatches || [],
      deliveries: fallbackStore.deliveries || [],
      companies: fallbackStore.companies || [],
      purchaseExecutives: fallbackStore.purchaseExecutives || [],
      categories: fallbackStore.categories || [],
      brands: fallbackStore.brands || [],
      productTypes: fallbackStore.productTypes || [],
      vendorProductMappings: fallbackStore.vendorProductMappings || [],
      lastSyncTime: new Date().toISOString(),
    };
  }

  const [
    reqsData,
    customers,
    vendors,
    products,
    rfqs,
    vendorQuotes,
    quotations,
    customerPos,
    vendorPos,
    payments,
    dispatches,
    deliveries,
    companies,
    purchaseExecutives,
    categories,
    brands,
    productTypes,
    vendorProductMappings,
  ] = await Promise.all([
    getRequirements(db),
    getCustomers(db),
    getVendors(db),
    getProducts(db),
    getGenericTable(db, 'rfqs'),
    getGenericTable(db, 'vendor_quotes'),
    getGenericTable(db, 'customer_quotations'),
    getGenericTable(db, 'customer_pos'),
    getGenericTable(db, 'vendor_pos'),
    getGenericTable(db, 'payments'),
    getGenericTable(db, 'dispatches'),
    getGenericTable(db, 'deliveries'),
    getStateValue(db, 'companies'),
    getStateValue(db, 'purchaseExecutives'),
    getStateValue(db, 'categories'),
    getStateValue(db, 'brands'),
    getStateValue(db, 'productTypes'),
    getStateValue(db, 'vendorProductMappings'),
  ]);

  return {
    requirements: reqsData.requirements,
    deletedRequirementIds: reqsData.deletedIds,
    customers,
    vendors,
    products,
    rfqs,
    vendorQuotes,
    quotations,
    customerPos,
    vendorPos,
    payments,
    dispatches,
    deliveries,
    companies: companies || [],
    purchaseExecutives: purchaseExecutives || [],
    categories: categories || [],
    brands: brands || [],
    productTypes: productTypes || [],
    vendorProductMappings: vendorProductMappings || [],
    lastSyncTime: new Date().toISOString(),
  };
}

export async function persistFullStateToD1(db: D1Database | undefined, state: any): Promise<void> {
  if (!state || typeof state !== 'object') return;

  // Persist requirements safely: NEVER overwrite with an empty array
  if (Array.isArray(state.requirements) && state.requirements.length > 0) {
    for (const req of state.requirements) {
      await saveRequirement(db, req);
    }
  }

  // Persist deleted tombstones
  if (Array.isArray(state.deletedRequirementIds) && state.deletedRequirementIds.length > 0) {
    if (!db) {
      if (!fallbackStore.deletedRequirementIds) fallbackStore.deletedRequirementIds = [];
      for (const delId of state.deletedRequirementIds) {
        if (!fallbackStore.deletedRequirementIds.includes(delId)) {
          fallbackStore.deletedRequirementIds.push(delId);
        }
      }
    } else {
      const now = new Date().toISOString();
      for (const delId of state.deletedRequirementIds) {
        await db
          .prepare('INSERT OR REPLACE INTO deleted_requirements (id, deletedAt, deletedBy, reason) VALUES (?, ?, ?, ?)')
          .bind(delId, now, 'Sync', 'Tombstone Sync')
          .run();
      }
    }
  }

  // Persist customers
  if (Array.isArray(state.customers)) {
    for (const c of state.customers) {
      await saveCustomer(db, c);
    }
  }

  // Persist vendors
  if (Array.isArray(state.vendors)) {
    for (const v of state.vendors) {
      await saveVendor(db, v);
    }
  }

  // Persist products
  if (Array.isArray(state.products)) {
    for (const p of state.products) {
      await saveProduct(db, p);
    }
  }

  // Persist other array collections in state_store
  const stateKeys = [
    'companies',
    'purchaseExecutives',
    'rfqs',
    'vendorQuotes',
    'quotations',
    'customerPos',
    'vendorPos',
    'payments',
    'dispatches',
    'deliveries',
    'categories',
    'brands',
    'productTypes',
    'vendorProductMappings',
  ];

  for (const key of stateKeys) {
    if (Array.isArray(state[key])) {
      await setStateValue(db, key, state[key]);
    }
  }
}
