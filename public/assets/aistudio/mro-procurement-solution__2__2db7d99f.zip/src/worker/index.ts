import { Env } from './types';
import * as d1 from './d1Service';

// Ensure CORS & Anti-Caching Headers are set on all API responses
function jsonResponse(data: any, status = 200, origin = '*'): Response {
  const headers = new Headers();
  headers.set('Content-Type', 'application/json; charset=utf-8');
  headers.set('Access-Control-Allow-Origin', origin);
  headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-requested-with');

  // Strict anti-caching headers for real-time synchronization
  headers.set('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  headers.set('Pragma', 'no-cache');
  headers.set('Expires', '0');

  return new Response(JSON.stringify(data), { status, headers });
}

function handleCorsPreflight(origin = '*'): Response {
  const headers = new Headers();
  headers.set('Access-Control-Allow-Origin', origin);
  headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization, x-requested-with');
  headers.set('Access-Control-Max-Age', '86400');
  return new Response(null, { status: 204, headers });
}

let isDbInitialized = false;

async function handleApi(request: Request, env: Env): Promise<Response> {
  const url = new URL(request.url);
  const path = url.pathname;
  const method = request.method;
  const origin = request.headers.get('origin') || '*';

  if (method === 'OPTIONS') {
    return handleCorsPreflight(origin);
  }

  // Dual-Deployment Unified Database Sync Bridge
  // Forwards API mutations and reads to central live ERP database so both Cloudflare and Cloud Run share live data
  const centralBase = env.CENTRAL_API_URL || 'https://ais-pre-blsn7yeugffp2hqla4t7es-95715327985.asia-east1.run.app';
  if (centralBase && !request.headers.get('x-internal-loop')) {
    try {
      const centralUrl = `${centralBase}${path}${url.search}`;
      const forwardHeaders = new Headers();
      forwardHeaders.set('Content-Type', request.headers.get('content-Type') || 'application/json');
      forwardHeaders.set('x-forwarded-from', 'mro-cloudflare-worker');
      forwardHeaders.set('x-internal-loop', '1');
      if (request.headers.get('authorization')) {
        forwardHeaders.set('Authorization', request.headers.get('authorization')!);
      }

      let requestBody: ArrayBuffer | undefined = undefined;
      if (method !== 'GET' && method !== 'HEAD') {
        requestBody = await request.clone().arrayBuffer();
      }

      const centralRes = await fetch(centralUrl, {
        method,
        headers: forwardHeaders,
        body: requestBody,
      });

      if (centralRes.ok) {
        const json = await centralRes.json();
        // Optional asynchronous mirror to local D1 for offline redundancy
        if (env.DB && method === 'POST' && path === '/api/requirements') {
          try {
            if (json && json.requirement) {
              await d1.saveRequirement(env.DB, json.requirement);
            }
          } catch (e) {
            // Ignore background mirror error
          }
        }
        return jsonResponse(json, centralRes.status, origin);
      }
    } catch (centralErr) {
      console.warn('[Worker] Central Database proxy fallback to local D1:', centralErr);
    }
  }

  // If D1 is bound, ensure schema exists
  if (env.DB && !isDbInitialized) {
    try {
      await d1.initD1Schema(env.DB);
      isDbInitialized = true;
    } catch (e) {
      console.warn('[Worker] Schema init deferred:', e);
    }
  }

  // 1. Health & Database Status
  if (path === '/api/health') {
    return jsonResponse({
      status: 'UP',
      engine: 'Cloudflare Workers + Unified Cloud Run Bridge',
      centralSyncTarget: centralBase,
      d1Connected: !!env.DB,
      timestamp: new Date().toISOString(),
    }, 200, origin);
  }

  if (path === '/api/db/status') {
    return jsonResponse({
      success: true,
      mode: 'UNIFIED_ENTERPRISE_DUAL_SYNC',
      centralSyncTarget: centralBase,
      d1Connected: !!env.DB,
      database: 'Live Enterprise Central Database + D1 Resilient Failover',
      timestamp: new Date().toISOString(),
    }, 200, origin);
  }

  try {
    // 2. Full State Synchronization (Multi-User Multi-Device Sync Engine)
    if (path === '/api/sync/state' && method === 'GET') {
      const state = await d1.getFullStateFromD1(env.DB);
      return jsonResponse({ success: true, state }, 200, origin);
    }

    if (path === '/api/sync/full' && method === 'POST') {
      const body: any = await request.json().catch(() => ({}));
      if (body.state) {
        await d1.persistFullStateToD1(env.DB, body.state);
      }
      return jsonResponse({ success: true, message: 'D1 State updated', timestamp: new Date().toISOString() }, 200, origin);
    }

    // 3. Requirements CRUD
    if (path === '/api/requirements') {
      if (method === 'GET') {
        const includeDeleted = url.searchParams.get('includeDeleted') === 'true';
        const { requirements, deletedIds } = await d1.getRequirements(env.DB, includeDeleted);
        return jsonResponse({ success: true, requirements, deletedRequirementIds: deletedIds }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        if (Array.isArray(body)) {
          const results = [];
          for (const item of body) {
            results.push(await d1.saveRequirement(env.DB, item));
          }
          return jsonResponse({ success: true, count: results.length, requirements: results }, 201, origin);
        }
        const saved = await d1.saveRequirement(env.DB, body);
        return jsonResponse({ success: true, requirement: saved, dbSaveStatus: 'COMMITTED' }, 201, origin);
      }
    }

    const restoreMatch = path.match(/^\/api\/requirements\/([^/]+)\/restore$/);
    if (restoreMatch && method === 'POST') {
      const id = decodeURIComponent(restoreMatch[1]);
      const result = await d1.restoreRequirement(env.DB, id, 'Super Admin');
      return jsonResponse(result, 200, origin);
    }

    const reqMatch = path.match(/^\/api\/requirements\/([^/]+)$/);
    if (reqMatch) {
      const id = decodeURIComponent(reqMatch[1]);
      if (method === 'PUT') {
        const body: any = await request.json();
        const saved = await d1.saveRequirement(env.DB, { ...body, id });
        return jsonResponse({ success: true, requirement: saved, dbSaveStatus: 'COMMITTED' }, 200, origin);
      }
      if (method === 'DELETE') {
        const body: any = await request.json().catch(() => ({}));
        const reason = body.reason || url.searchParams.get('reason') || 'User Deletion';
        const result = await d1.deleteRequirement(env.DB, id, 'Super Admin', reason);
        return jsonResponse(result, 200, origin);
      }
    }

    // 4. Customers CRUD
    if (path === '/api/customers') {
      if (method === 'GET') {
        const customers = await d1.getCustomers(env.DB);
        return jsonResponse({ success: true, customers }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        if (Array.isArray(body)) {
          const list = [];
          for (const c of body) {
            list.push(await d1.saveCustomer(env.DB, c));
          }
          return jsonResponse({ success: true, count: list.length, customers: list }, 201, origin);
        }
        const saved = await d1.saveCustomer(env.DB, body);
        return jsonResponse({ success: true, customer: saved }, 201, origin);
      }
    }

    const custMatch = path.match(/^\/api\/customers\/([^/]+)$/);
    if (custMatch) {
      const id = decodeURIComponent(custMatch[1]);
      if (method === 'PUT') {
        const body: any = await request.json();
        const saved = await d1.saveCustomer(env.DB, { ...body, id });
        return jsonResponse({ success: true, customer: saved }, 200, origin);
      }
      if (method === 'DELETE') {
        await d1.deleteCustomer(env.DB, id);
        return jsonResponse({ success: true, message: `Customer ${id} deleted from D1` }, 200, origin);
      }
    }

    // 5. Vendors CRUD
    if (path === '/api/vendors') {
      if (method === 'GET') {
        const vendors = await d1.getVendors(env.DB);
        return jsonResponse({ success: true, vendors }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        if (Array.isArray(body)) {
          const list = [];
          for (const v of body) {
            list.push(await d1.saveVendor(env.DB, v));
          }
          return jsonResponse({ success: true, count: list.length, vendors: list }, 201, origin);
        }
        const saved = await d1.saveVendor(env.DB, body);
        return jsonResponse({ success: true, vendor: saved }, 201, origin);
      }
    }

    const vendMatch = path.match(/^\/api\/vendors\/([^/]+)$/);
    if (vendMatch) {
      const id = decodeURIComponent(vendMatch[1]);
      if (method === 'PUT') {
        const body: any = await request.json();
        const saved = await d1.saveVendor(env.DB, { ...body, id });
        return jsonResponse({ success: true, vendor: saved }, 200, origin);
      }
      if (method === 'DELETE') {
        await d1.deleteVendor(env.DB, id);
        return jsonResponse({ success: true, message: `Vendor ${id} deleted from D1` }, 200, origin);
      }
    }

    // 6. Products CRUD
    if (path === '/api/products') {
      if (method === 'GET') {
        const products = await d1.getProducts(env.DB);
        return jsonResponse({ success: true, products }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        if (Array.isArray(body)) {
          const list = [];
          for (const p of body) {
            list.push(await d1.saveProduct(env.DB, p));
          }
          return jsonResponse({ success: true, count: list.length, products: list }, 201, origin);
        }
        const saved = await d1.saveProduct(env.DB, body);
        return jsonResponse({ success: true, product: saved }, 201, origin);
      }
    }

    const prodMatch = path.match(/^\/api\/products\/([^/]+)$/);
    if (prodMatch) {
      const id = decodeURIComponent(prodMatch[1]);
      if (method === 'PUT') {
        const body: any = await request.json();
        const saved = await d1.saveProduct(env.DB, { ...body, id });
        return jsonResponse({ success: true, product: saved }, 200, origin);
      }
      if (method === 'DELETE') {
        await d1.deleteProduct(env.DB, id);
        return jsonResponse({ success: true, message: `Product ${id} deleted from D1` }, 200, origin);
      }
    }

    // 7. RFQs CRUD
    if (path === '/api/rfqs') {
      if (method === 'GET') {
        const rfqs = await d1.getGenericTable(env.DB, 'rfqs');
        return jsonResponse({ success: true, rfqs }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        const saved = await d1.saveGenericItem(env.DB, 'rfqs', body, 'RFQ');
        return jsonResponse({ success: true, rfq: saved }, 201, origin);
      }
    }

    // 8. Quotations CRUD
    if (path === '/api/quotations') {
      if (method === 'GET') {
        const quotations = await d1.getGenericTable(env.DB, 'customer_quotations');
        return jsonResponse({ success: true, quotations }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        const saved = await d1.saveGenericItem(env.DB, 'customer_quotations', body, 'QUOT');
        return jsonResponse({ success: true, quotation: saved }, 201, origin);
      }
    }

    // 9. Customer POs CRUD
    if (path === '/api/customer-pos') {
      if (method === 'GET') {
        const customerPos = await d1.getGenericTable(env.DB, 'customer_pos');
        return jsonResponse({ success: true, customerPos }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        const saved = await d1.saveGenericItem(env.DB, 'customer_pos', body, 'CPO');
        return jsonResponse({ success: true, customerPo: saved }, 201, origin);
      }
    }

    // 10. Vendor POs CRUD
    if (path === '/api/vendor-pos') {
      if (method === 'GET') {
        const vendorPos = await d1.getGenericTable(env.DB, 'vendor_pos');
        return jsonResponse({ success: true, vendorPos }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        const saved = await d1.saveGenericItem(env.DB, 'vendor_pos', body, 'VPO');
        return jsonResponse({ success: true, vendorPo: saved }, 201, origin);
      }
    }

    // 11. Payments CRUD
    if (path === '/api/payments') {
      if (method === 'GET') {
        const payments = await d1.getGenericTable(env.DB, 'payments');
        return jsonResponse({ success: true, payments }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        const saved = await d1.saveGenericItem(env.DB, 'payments', body, 'PAY');
        return jsonResponse({ success: true, payment: saved }, 201, origin);
      }
    }

    // 12. Dispatches CRUD
    if (path === '/api/dispatches') {
      if (method === 'GET') {
        const dispatches = await d1.getGenericTable(env.DB, 'dispatches');
        return jsonResponse({ success: true, dispatches }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        const saved = await d1.saveGenericItem(env.DB, 'dispatches', body, 'DISP');
        return jsonResponse({ success: true, dispatch: saved }, 201, origin);
      }
    }

    // 13. Deliveries CRUD
    if (path === '/api/deliveries') {
      if (method === 'GET') {
        const deliveries = await d1.getGenericTable(env.DB, 'deliveries');
        return jsonResponse({ success: true, deliveries }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        const saved = await d1.saveGenericItem(env.DB, 'deliveries', body, 'DEL');
        return jsonResponse({ success: true, delivery: saved }, 201, origin);
      }
    }

    // 14. Master Collections (Categories, Brands, Product Types, Vendor Mappings)
    if (path === '/api/categories') {
      if (method === 'GET') {
        const categories = (await d1.getStateValue(env.DB, 'categories')) || [];
        return jsonResponse({ success: true, categories }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        await d1.setStateValue(env.DB, 'categories', body);
        return jsonResponse({ success: true, categories: body }, 200, origin);
      }
    }

    if (path === '/api/brands') {
      if (method === 'GET') {
        const brands = (await d1.getStateValue(env.DB, 'brands')) || [];
        return jsonResponse({ success: true, brands }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        const existing: any[] = (await d1.getStateValue(env.DB, 'brands')) || [];
        const items = Array.isArray(body) ? body : [body];
        const merged = [...existing];
        for (const item of items) {
          if (!item || !item.name) continue;
          const idx = merged.findIndex((b: any) => b.name?.toLowerCase().trim() === item.name?.toLowerCase().trim());
          if (idx !== -1) {
            merged[idx] = { ...merged[idx], ...item };
          } else {
            merged.push(item);
          }
        }
        await d1.setStateValue(env.DB, 'brands', merged);
        return jsonResponse({ success: true, count: merged.length, brands: merged }, 200, origin);
      }
    }

    const brandMatch = path.match(/^\/api\/brands\/([^/]+)$/);
    if (brandMatch && method === 'DELETE') {
      const id = decodeURIComponent(brandMatch[1]);
      const existing: any[] = (await d1.getStateValue(env.DB, 'brands')) || [];
      const filtered = existing.filter((b: any) => b.id !== id);
      await d1.setStateValue(env.DB, 'brands', filtered);
      return jsonResponse({ success: true, message: `Brand ${id} removed` }, 200, origin);
    }

    if (path === '/api/product-types') {
      if (method === 'GET') {
        const productTypes = (await d1.getStateValue(env.DB, 'productTypes')) || [];
        return jsonResponse({ success: true, productTypes }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        await d1.setStateValue(env.DB, 'productTypes', body);
        return jsonResponse({ success: true, productTypes: body }, 200, origin);
      }
    }

    if (path === '/api/vendor-products') {
      if (method === 'GET') {
        const vendorProductMappings = (await d1.getStateValue(env.DB, 'vendorProductMappings')) || [];
        return jsonResponse({ success: true, vendorProductMappings }, 200, origin);
      }
      if (method === 'POST') {
        const body: any = await request.json();
        await d1.setStateValue(env.DB, 'vendorProductMappings', body);
        return jsonResponse({ success: true, vendorProductMappings: body }, 200, origin);
      }
    }

    // Fallback for unmatched API routes
    return jsonResponse({ error: `API route ${method} ${path} not found` }, 404, origin);
  } catch (err: any) {
    return jsonResponse({ error: err.message || 'Internal D1 Server Error' }, 500, origin);
  }
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);

    // 1. API Route Handler (Direct D1 SQL Database)
    if (url.pathname.startsWith('/api/')) {
      return handleApi(request, env);
    }

    // 2. Static Asset Delivery via Cloudflare Workers Assets
    if (env.ASSETS) {
      return env.ASSETS.fetch(request);
    }

    return new Response('MRO ERP Worker Online', { status: 200 });
  },
};
