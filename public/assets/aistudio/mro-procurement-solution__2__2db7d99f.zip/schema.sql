-- =========================================================================
-- Cloudflare D1 SQL Schema for MRO Procurement ERP
-- Run with: wrangler d1 execute mro-erp-db --remote --file=./schema.sql
-- =========================================================================

-- 1. Requirements Table
CREATE TABLE IF NOT EXISTS requirements (
  id TEXT PRIMARY KEY,
  rfqNumber TEXT,
  customerId TEXT,
  customerName TEXT,
  department TEXT,
  priority TEXT DEFAULT 'MEDIUM',
  status TEXT DEFAULT 'PENDING',
  date TEXT,
  requiredByDate TEXT,
  deliveryLocation TEXT,
  estimatedBudget REAL DEFAULT 0,
  itemsCount INTEGER DEFAULT 0,
  itemsJson TEXT,
  dataJson TEXT,
  createdBy TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

CREATE INDEX IF NOT EXISTS idx_requirements_status ON requirements(status);
CREATE INDEX IF NOT EXISTS idx_requirements_customer ON requirements(customerName);
CREATE INDEX IF NOT EXISTS idx_requirements_rfq ON requirements(rfqNumber);

-- 2. Requirement Tombstones (Authoritative sync deletion tracking)
CREATE TABLE IF NOT EXISTS deleted_requirements (
  id TEXT PRIMARY KEY,
  deletedAt TEXT NOT NULL,
  deletedBy TEXT,
  reason TEXT
);

-- 3. Customers Master Table
CREATE TABLE IF NOT EXISTS customers (
  id TEXT PRIMARY KEY,
  companyName TEXT NOT NULL,
  contactPerson TEXT,
  email TEXT,
  mobile TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  pincode TEXT,
  gstin TEXT,
  pan TEXT,
  paymentTerms TEXT,
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

CREATE INDEX IF NOT EXISTS idx_customers_name ON customers(companyName);
CREATE INDEX IF NOT EXISTS idx_customers_gstin ON customers(gstin);

-- 4. Vendors Master Table
CREATE TABLE IF NOT EXISTS vendors (
  id TEXT PRIMARY KEY,
  companyName TEXT NOT NULL,
  contactPerson TEXT,
  email TEXT,
  mobile TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  gstin TEXT,
  pan TEXT,
  rating REAL DEFAULT 5.0,
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

CREATE INDEX IF NOT EXISTS idx_vendors_name ON vendors(companyName);

-- 5. Products Master Table
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  partNumber TEXT,
  brand TEXT,
  category TEXT,
  uom TEXT DEFAULT 'NOS',
  unitPrice REAL DEFAULT 0,
  taxRate REAL DEFAULT 18,
  description TEXT,
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

CREATE INDEX IF NOT EXISTS idx_products_name ON products(name);
CREATE INDEX IF NOT EXISTS idx_products_brand ON products(brand);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);

-- 6. RFQs / Enquiries Table
CREATE TABLE IF NOT EXISTS rfqs (
  id TEXT PRIMARY KEY,
  rfqNumber TEXT NOT NULL,
  requirementId TEXT,
  customerName TEXT,
  title TEXT,
  status TEXT DEFAULT 'OPEN',
  dueDate TEXT,
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

CREATE INDEX IF NOT EXISTS idx_rfqs_number ON rfqs(rfqNumber);

-- 7. Vendor Quotes Table
CREATE TABLE IF NOT EXISTS vendor_quotes (
  id TEXT PRIMARY KEY,
  quoteNumber TEXT,
  rfqNumber TEXT,
  vendorId TEXT,
  vendorName TEXT,
  status TEXT DEFAULT 'RECEIVED',
  totalAmount REAL DEFAULT 0,
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

-- 8. Customer Quotations Table
CREATE TABLE IF NOT EXISTS customer_quotations (
  id TEXT PRIMARY KEY,
  quotationNumber TEXT NOT NULL,
  rfqNumber TEXT,
  customerId TEXT,
  customerName TEXT,
  status TEXT DEFAULT 'DRAFT',
  subtotal REAL DEFAULT 0,
  taxAmount REAL DEFAULT 0,
  totalAmount REAL DEFAULT 0,
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

-- 9. Customer Purchase Orders (POs) Table
CREATE TABLE IF NOT EXISTS customer_pos (
  id TEXT PRIMARY KEY,
  poNumber TEXT NOT NULL,
  quotationNumber TEXT,
  customerName TEXT,
  orderDate TEXT,
  deliveryDate TEXT,
  status TEXT DEFAULT 'PENDING',
  totalAmount REAL DEFAULT 0,
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

-- 10. Vendor Purchase Orders (POs) Table
CREATE TABLE IF NOT EXISTS vendor_pos (
  id TEXT PRIMARY KEY,
  poNumber TEXT NOT NULL,
  vendorName TEXT,
  customerPoReference TEXT,
  orderDate TEXT,
  status TEXT DEFAULT 'ISSUED',
  totalAmount REAL DEFAULT 0,
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

-- 11. Payments Table
CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  paymentNumber TEXT,
  partyType TEXT, -- CUSTOMER or VENDOR
  partyName TEXT,
  amount REAL DEFAULT 0,
  paymentDate TEXT,
  paymentMode TEXT,
  referenceNumber TEXT,
  status TEXT DEFAULT 'COMPLETED',
  dataJson TEXT,
  createdAt TEXT
);

-- 12. Dispatches Table
CREATE TABLE IF NOT EXISTS dispatches (
  id TEXT PRIMARY KEY,
  dispatchNumber TEXT,
  customerName TEXT,
  dispatchDate TEXT,
  status TEXT DEFAULT 'DISPATCHED',
  courierName TEXT,
  trackingNumber TEXT,
  dataJson TEXT,
  createdAt TEXT
);

-- 13. Deliveries Table
CREATE TABLE IF NOT EXISTS deliveries (
  id TEXT PRIMARY KEY,
  deliveryNumber TEXT,
  customerName TEXT,
  receivedDate TEXT,
  status TEXT DEFAULT 'DELIVERED',
  dataJson TEXT,
  createdAt TEXT
);

-- 14. Users Table (Role-based access & auth)
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  username TEXT UNIQUE NOT NULL,
  email TEXT,
  name TEXT,
  role TEXT DEFAULT 'Procurement Specialist',
  department TEXT,
  passwordHash TEXT,
  passwordSalt TEXT,
  status TEXT DEFAULT 'ACTIVE',
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

-- 15. Approvals Table
CREATE TABLE IF NOT EXISTS approvals (
  id TEXT PRIMARY KEY,
  requestType TEXT,
  requestNumber TEXT,
  requestDate TEXT,
  requestorName TEXT,
  department TEXT,
  vendorOrCustomer TEXT,
  amount REAL DEFAULT 0,
  status TEXT DEFAULT 'PENDING',
  approvalLevel TEXT DEFAULT 'LEVEL_1',
  details TEXT,
  dataJson TEXT,
  createdAt TEXT,
  updatedAt TEXT
);

-- 16. Audit Logs Table
CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  timestamp TEXT NOT NULL,
  userName TEXT,
  role TEXT,
  action TEXT NOT NULL,
  module TEXT NOT NULL,
  recordNumber TEXT,
  remarks TEXT,
  ipAddress TEXT,
  createdAt TEXT
);

CREATE INDEX IF NOT EXISTS idx_audit_module ON audit_logs(module);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_logs(timestamp);

-- 17. Master Sync Store (Unified State Sync Key-Value table for collections, companies, brands, settings)
CREATE TABLE IF NOT EXISTS erp_state_store (
  key TEXT PRIMARY KEY,
  valueJson TEXT NOT NULL,
  updatedAt TEXT NOT NULL
);
